import { StateMachine } from '../core/StateMachine.js';

const SPEED = 72;            // px/s (4.5 tiles/s)
const DODGE_SPEED = 190;
const DODGE_TIME = 0.16;
const DODGE_COOLDOWN = 0.6;
const HALF_W = 5;            // collision box (feet): 10 wide
const BOX_H = 6;             // and 6 tall
const DIRS = ['down', 'up', 'left', 'right']; // row order in player.png

export class Player {
  /**
   * @param scene       Phaser scene
   * @param chunks      ChunkManager (collision lookups)
   * @param input       InputManager
   */
  constructor(scene, chunks, input, x, y) {
    this.scene = scene;
    this.chunks = chunks;
    this.input = input;
    this.facing = 'down';
    this.dodgeTimer = 0;
    this.dodgeCooldown = 0;
    this.dodgeVec = { x: 0, y: 1 };

    Player.createAnims(scene.anims);
    // Character art is 48x48 cells with the feet at y=32, so origin = (0.5, 32/48).
    this.sprite = scene.add.sprite(x, y, 'player', 0).setOrigin(0.5, 32 / 48);

    this.fsm = new StateMachine(this, {
      idle: {
        enter: (p) => p.showIdle(),
        update: (p) => {
          if (p.wantsDodge()) return p.fsm.set('dodge');
          const m = p.input.getMove();
          if (m.x !== 0 || m.y !== 0) p.fsm.set('walk');
        },
      },
      walk: {
        update: (p, dt) => {
          if (p.wantsDodge()) return p.fsm.set('dodge');
          const m = p.input.getMove();
          const mag = Math.hypot(m.x, m.y);
          if (mag === 0) return p.fsm.set('idle');
          p.setFacing(m.x, m.y);
          p.sprite.anims.play('walk_' + p.facing, true);
          p.sprite.anims.timeScale = 0.5 + 0.5 * mag;
          p.moveBy(m.x * SPEED * dt, m.y * SPEED * dt);
        },
      },
      dodge: {
        enter: (p) => {
          const m = p.input.getMove();
          p.dodgeVec = Math.hypot(m.x, m.y) > 0.1 ? { x: m.x, y: m.y } : p.facingVector();
          const len = Math.hypot(p.dodgeVec.x, p.dodgeVec.y) || 1;
          p.dodgeVec = { x: p.dodgeVec.x / len, y: p.dodgeVec.y / len };
          p.dodgeTimer = DODGE_TIME;
          p.sprite.setAlpha(0.6);
        },
        update: (p, dt) => {
          p.moveBy(p.dodgeVec.x * DODGE_SPEED * dt, p.dodgeVec.y * DODGE_SPEED * dt);
          p.dodgeTimer -= dt;
          if (p.dodgeTimer <= 0) p.fsm.set('idle');
        },
        exit: (p) => {
          p.sprite.setAlpha(1);
          p.dodgeCooldown = DODGE_COOLDOWN;
        },
      },
      // Tool swing: frozen in place, 2 frames from actions.png (wind-up, strike). cfg = {anim, hitTime, duration, onHit}
      use: {
        enter: (p, cfg) => {
          p.useCfg = cfg;
          p.useT = 0;
          p.useHit = false;
          p.sprite.anims.stop();
          p.setActionFrame(0);
        },
        update: (p, dt) => {
          p.useT += dt;
          if (!p.useHit && p.useT >= p.useCfg.hitTime) {
            p.useHit = true;
            p.setActionFrame(1);
            if (p.useCfg.onHit) p.useCfg.onHit();
          }
          if (p.useT >= p.useCfg.duration) p.fsm.set('idle');
        },
        exit: (p) => { p.sprite.setTexture('player', DIRS.indexOf(p.facing) * 4); },
      },
    }, 'idle');
  }

  static createAnims(anims) {
    DIRS.forEach((d, row) => {
      const key = 'walk_' + d;
      if (anims.exists(key)) return;
      anims.create({
        key,
        frames: anims.generateFrameNumbers('player', { start: row * 4, end: row * 4 + 3 }),
        frameRate: 8,
        repeat: -1,
      });
    });
  }

  get x() { return this.sprite.x; }
  get y() { return this.sprite.y; }

  setPosition(x, y) { this.sprite.setPosition(x, y); this.sprite.setDepth(y); }

  wantsDodge() { return this.dodgeCooldown <= 0 && this.input.justPressed('dodge'); }

  setFacing(dx, dy) {
    if (Math.abs(dx) > Math.abs(dy)) this.facing = dx < 0 ? 'left' : 'right';
    else if (dy !== 0) this.facing = dy < 0 ? 'up' : 'down';
  }

  facingVector() {
    switch (this.facing) {
      case 'up': return { x: 0, y: -1 };
      case 'left': return { x: -1, y: 0 };
      case 'right': return { x: 1, y: 0 };
      default: return { x: 0, y: 1 };
    }
  }

  showIdle() {
    this.sprite.anims.stop();
    this.sprite.setTexture('player', DIRS.indexOf(this.facing) * 4);
  }

  /** actions.png: 2 columns x 12 rows. Each tool owns 4 rows (down, up, left, right) starting at cfg.anim. */
  setActionFrame(col) {
    const row = this.useCfg.anim + DIRS.indexOf(this.facing);
    this.sprite.setTexture('actions', row * 2 + col);
  }

  get busy() { return this.fsm.current === 'use'; }

  /** Starts a tool swing (only from idle/walk). Returns true if it started. */
  startUse(cfg) {
    if (this.fsm.current !== 'idle' && this.fsm.current !== 'walk') return false;
    this.fsm.set('use', cfg);
    return true;
  }

  collides(x, y) {
    const l = x - HALF_W + 0.01, r = x + HALF_W - 0.01, t = y - BOX_H, b = y - 0.01;
    const c = this.chunks;
    return c.isBlockedPx(l, t) || c.isBlockedPx(r, t) || c.isBlockedPx(l, b) || c.isBlockedPx(r, b);
  }

  moveBy(dx, dy) {
    let x = this.sprite.x, y = this.sprite.y;
    if (dx !== 0 && !this.collides(x + dx, y)) x += dx;
    if (dy !== 0 && !this.collides(x, y + dy)) y += dy;
    this.setPosition(x, y);
  }

  update(dtSeconds) {
    if (this.frozen) return; // during the sleep fade
    if (this.dodgeCooldown > 0) this.dodgeCooldown -= dtSeconds;
    this.fsm.update(dtSeconds);
  }
}
