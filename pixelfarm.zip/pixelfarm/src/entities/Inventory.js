import { ItemDB } from '../core/ItemDB.js';

/**
 * Fixed-size slot inventory. A slot is null or {id, count}.
 * `version` goes up on every change so UI can redraw only when needed.
 */
export class Inventory {
  constructor(size) {
    this.size = size;
    this.slots = new Array(size).fill(null);
    this.version = 0;
  }

  /** Adds items (q = quality 0-2), returns how many did NOT fit. Different qualities never share a stack. */
  add(id, count = 1, q = 0) {
    const max = ItemDB.get(id).stack || 1;
    for (let i = 0; i < this.size && count > 0; i++) {
      const s = this.slots[i];
      if (s && s.id === id && (s.q || 0) === q && s.count < max) {
        const n = Math.min(max - s.count, count);
        s.count += n;
        count -= n;
      }
    }
    for (let i = 0; i < this.size && count > 0; i++) {
      if (!this.slots[i]) {
        const n = Math.min(max, count);
        this.slots[i] = q ? { id, count: n, q } : { id, count: n };
        count -= n;
      }
    }
    this.version++;
    return count;
  }

  /** Removes up to n from one slot. Returns how many were removed. */
  removeAt(i, n = 1) {
    const s = this.slots[i];
    if (!s) return 0;
    const k = Math.min(n, s.count);
    s.count -= k;
    if (s.count <= 0) this.slots[i] = null;
    this.version++;
    return k;
  }

  /** How many of `id` would fit right now. */
  room(id, q = 0) {
    const max = ItemDB.get(id).stack || 1;
    let r = 0;
    for (const s of this.slots) {
      if (!s) r += max;
      else if (s.id === id && (s.q || 0) === q) r += max - s.count;
    }
    return r;
  }

  canAdd(id, count = 1, q = 0) { return this.room(id, q) >= count; }

  countOf(id) {
    let n = 0;
    for (const s of this.slots) if (s && s.id === id) n += s.count;
    return n;
  }

  /** Removes up to `count`, returns how many were removed. */
  remove(id, count = 1) {
    let left = count;
    for (let i = this.size - 1; i >= 0 && left > 0; i--) {
      const s = this.slots[i];
      if (s && s.id === id) {
        const n = Math.min(s.count, left);
        s.count -= n;
        left -= n;
        if (s.count <= 0) this.slots[i] = null;
      }
    }
    this.version++;
    return count - left;
  }

  /** Moves the stack in slot `from` into `toInv[toIdx]`: merges same items, otherwise swaps. */
  move(from, toInv, toIdx) {
    const a = this.slots[from];
    if (!a || (toInv === this && from === toIdx)) return false;
    const b = toInv.slots[toIdx];
    if (b && b.id === a.id && (b.q || 0) === (a.q || 0)) {
      const max = ItemDB.get(a.id).stack || 1;
      const n = Math.min(max - b.count, a.count);
      if (n <= 0) return false;
      b.count += n;
      a.count -= n;
      if (a.count <= 0) this.slots[from] = null;
    } else {
      this.slots[from] = b || null;
      toInv.slots[toIdx] = a;
    }
    this.version++;
    if (toInv !== this) toInv.version++;
    return true;
  }

  /** Merges stacks and orders items by type then name, from slot `start` onward (keeps the hotbar). */
  sort(start = 0) {
    const total = new Map(); // "id|q" -> count
    for (let i = start; i < this.size; i++) {
      const s = this.slots[i];
      if (s) {
        const k = s.id + '|' + (s.q || 0);
        total.set(k, (total.get(k) || 0) + s.count);
        this.slots[i] = null;
      }
    }
    const keys = [...total.keys()].sort((ka, kb) => {
      const [a, qa] = ka.split('|'), [b, qb] = kb.split('|');
      const A = ItemDB.get(a), B = ItemDB.get(b);
      return (A.type || '').localeCompare(B.type || '') || A.name.localeCompare(B.name) || Number(qb) - Number(qa);
    });
    let i = start;
    for (const k of keys) {
      const [id, qs] = k.split('|');
      const q = Number(qs);
      const max = ItemDB.get(id).stack || 1;
      let left = total.get(k);
      while (left > 0 && i < this.size) {
        const n = Math.min(max, left);
        this.slots[i++] = q ? { id, count: n, q } : { id, count: n };
        left -= n;
      }
    }
    this.version++;
  }

  toJSON() { return this.slots.map((s) => (s ? (s.q ? [s.id, s.count, s.q] : [s.id, s.count]) : null)); }

  static fromJSON(arr) {
    const inv = new Inventory(arr.length);
    arr.forEach((s, i) => { if (s) inv.slots[i] = s[2] ? { id: s[0], count: s[1], q: s[2] } : { id: s[0], count: s[1] }; });
    return inv;
  }
}
