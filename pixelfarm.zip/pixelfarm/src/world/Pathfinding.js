/** Breadth-first search on the tile grid. Returns [{x,y}...] excluding the start, or null. */
export function findPath(isBlocked, sx, sy, tx, ty, maxNodes = 2500) {
  if (sx === tx && sy === ty) return [];
  if (isBlocked(tx, ty)) return null;
  const key = (x, y) => x + ',' + y;
  const prev = new Map([[key(sx, sy), null]]);
  const queue = [[sx, sy]];
  const dirs = [[1, 0], [-1, 0], [0, 1], [0, -1]];
  for (let qi = 0; qi < queue.length && qi < maxNodes; qi++) {
    const [x, y] = queue[qi];
    for (const [dx, dy] of dirs) {
      const nx = x + dx, ny = y + dy, k = key(nx, ny);
      if (prev.has(k) || isBlocked(nx, ny)) continue;
      prev.set(k, [x, y]);
      if (nx === tx && ny === ty) {
        const path = [];
        let cur = [nx, ny];
        while (cur && !(cur[0] === sx && cur[1] === sy)) { path.push({ x: cur[0], y: cur[1] }); cur = prev.get(key(cur[0], cur[1])); }
        return path.reverse();
      }
      queue.push([nx, ny]);
    }
  }
  return null;
}
