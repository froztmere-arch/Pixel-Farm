export const TILE = 16;                 // pixels per tile
export const CHUNK = 16;                // tiles per chunk side
export const CHUNK_PX = TILE * CHUNK;   // 256

// Layout of grass.png (11 columns x 7 rows of 16px tiles). Index = row * 11 + col.
export const TILESET_COLS = 11;
export const GRASS_FILL = 1 * TILESET_COLS + 1;                              // plain grass
export const GRASS_VARIANTS = [55, 56, 57, 58, 59, 60, 66, 67, 68, 69, 70, 71]; // opaque grass with details

// Edge pieces: the 3x3 rounded block in the top-left of grass.png. Transparent edges show water below.
export function edgeTile(waterW, waterE, waterN, waterS) {
  const tx = waterW ? 0 : waterE ? 2 : 1;
  const ty = waterN ? 0 : waterS ? 2 : 1;
  return ty * TILESET_COLS + tx;
}
