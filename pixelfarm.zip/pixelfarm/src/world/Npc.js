import { TILE } from './constants.js';

const SPEED = 38;
const DIRS = ['down', 'up', 'left', 'right'];

/** A villager. Walks tile to tile along a path computed by the NpcManager. */
export class Npc {
  constructor(scene, id, def, x, y) {
    this.id = id;
    this.def = def;
    this.path = [];
    this.target = null;
    this.facing = 'down';
    this.moving = false;
    this.sprite = scene.add.sprite(x, y, def.sheet, 0).setOrigin(0.5, 32 / 48);
    for (let row = 0; row < 4; row++) {
      const key = def.sheet + '_walk_' + DIRS[row];
      if (!scene.anims.exists(key)) {
        scene.anims.create({ key, frames: scene.anims.generateFrameNumbers(def.sheet, { start: row * 4, end: row * 4 + 3 }), frameRate: 6, repeat: -1 });
      }
    }
    this.place(x, y);
  }

  get x() { return this.sprite.x; }
  get y() { return this.sprite.y; }

  place(x, y) { this.sprite.setPosition(x, y); this.sprite.setDepth(y); }

  /** Moves toward the next waypoint. Returns true while still walking. */
  walk(dt) {
    if (!this.path.length) { this.stop(); return false; }
    const next = this.path[0];
    const tx = next.x * TILE + TILE / 2, ty = next.y * TILE + TILE - 2;
    const dx = tx - this.x, dy = ty - this.y;
    const dist = Math.hypot(dx, dy);
    const step = SPEED * dt;
    if (Math.abs(dx) > Math.abs(dy)) this.facing = dx < 0 ? 'left' : 'right';
    else if (dy !== 0) this.facing = dy < 0 ? 'up' : 'down';
    if (dist <= step) { this.place(tx, ty); this.path.shift(); }
    else this.place(this.x + (dx / dist) * step, this.y + (dy / dist) * step);
    this.moving = true;
    this.sprite.anims.play(this.def.sheet + '_walk_' + this.facing, true);
    return true;
  }

  stop() {
    if (!this.moving && this.sprite.anims.isPlaying === false) return;
    this.moving = false;
    this.sprite.anims.stop();
    this.sprite.setFrame(DIRS.indexOf(this.facing) * 4);
  }

  face(dx, dy) {
    if (Math.abs(dx) > Math.abs(dy)) this.facing = dx < 0 ? 'left' : 'right';
    else this.facing = dy < 0 ? 'up' : 'down';
    this.stop();
    this.sprite.setFrame(DIRS.indexOf(this.facing) * 4);
  }
}
