import { bus } from '../core/services.js';

const MAX_DROPS = 150;
const LIFETIME = 300;   // seconds before an uncollected drop disappears
const PICKUP_RANGE = 24;
const MAGNET_SPEED = 170;

/**
 * Item drops lying on the ground. Pooled: sprites and drop records are reused.
 * Walk near a drop and it flies to you (if the backpack has room).
 */
export class DropManager {
  constructor(scene, state, player) {
    this.scene = scene;
    this.state = state;
    this.player = player;
    this.active = [];
    this.free = [];
  }

  /** Spawns `count` of an item as individual little pickups popping out around (x, y). */
  spawn(id, count, x, y, iconFrame, q = 0) {
    // Many units become a few bigger stacks, so we never spam hundreds of sprites.
    const pieces = Math.min(count, 6);
    const per = Math.floor(count / pieces);
    let extra = count - per * pieces;
    for (let i = 0; i < pieces; i++) {
      const n = per + (extra-- > 0 ? 1 : 0);
      this.spawnOne(id, n, x, y, iconFrame, q);
    }
  }

  spawnOne(id, count, x, y, iconFrame, q = 0) {
    if (this.active.length >= MAX_DROPS) this.remove(0);
    const d = this.free.pop() || { sprite: this.scene.add.image(0, 0, 'items') };
    const a = Math.random() * Math.PI * 2;
    const sp = 25 + Math.random() * 35;
    d.id = id;
    d.q = q;
    d.count = count;
    d.x = x;
    d.y = y;
    d.vx = Math.cos(a) * sp;
    d.vy = Math.sin(a) * sp * 0.6;
    d.z = 0;
    d.vz = 70 + Math.random() * 30;
    d.age = 0;
    d.landed = false;
    d.sprite.setFrame(iconFrame).setVisible(true).setActive(true);
    d.sprite.setOrigin(0.5, 1);
    this.active.push(d);
    this.place(d);
  }

  place(d) {
    d.sprite.setPosition(Math.round(d.x), Math.round(d.y - d.z));
    d.sprite.setDepth(d.y);
  }

  remove(i) {
    const d = this.active[i];
    d.sprite.setVisible(false).setActive(false);
    this.free.push(d);
    this.active.splice(i, 1);
  }

  update(dt) {
    const p = this.player, inv = this.state.inventory;
    const px = p.x, py = p.y - 6;
    for (let i = this.active.length - 1; i >= 0; i--) {
      const d = this.active[i];
      d.age += dt;
      if (d.age > LIFETIME) { this.remove(i); continue; }

      if (!d.landed) {
        d.x += d.vx * dt;
        d.y += d.vy * dt;
        d.vx *= 0.94;
        d.vy *= 0.94;
        d.vz -= 260 * dt;
        d.z += d.vz * dt;
        if (d.z <= 0) { d.z = 0; d.landed = true; }
      } else {
        d.z = 1 + Math.sin(d.age * 4) * 1.2; // gentle bob
      }

      if (d.age > 0.45 && inv.room(d.id, d.q) > 0) {
        const dx = px - d.x, dy = py - d.y;
        const dist = Math.hypot(dx, dy);
        if (dist < PICKUP_RANGE) {
          const step = Math.min(dist, MAGNET_SPEED * dt);
          d.x += (dx / (dist || 1)) * step;
          d.y += (dy / (dist || 1)) * step;
          if (dist < 7) {
            const left = inv.add(d.id, d.count, d.q);
            const got = d.count - left;
            if (got > 0) bus.emit('ui:pickup', d.id, got, d.q);
            if (left > 0) d.count = left; else { this.remove(i); continue; }
          }
        }
      }
      this.place(d);
    }
  }
}
