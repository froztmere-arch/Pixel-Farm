import { Npc } from './Npc.js';
import { TILE } from './constants.js';
import { scheduleTarget, findShore } from '../core/Schedule.js';
import { findPath } from './Pathfinding.js';
import { festivalToday } from '../core/Economy.js';

const FAR = 40 * TILE;       // beyond this from the player: no walking, just teleport to the scheduled spot
const THINK = 1.0;           // seconds between schedule checks (tick-based, not per frame)

export class NpcManager {
  constructor(scene, { gen, chunks, state, seed, npcDefs, events }) {
    this.scene = scene;
    Object.assign(this, { gen, chunks, state, seed, events });
    const blocked = (x, y) => gen.isBlockedAt(x, y);
    this.blocked = blocked;
    this.shore = findShore(blocked, (x, y) => gen.isWater(x, y));
    this.npcs = {};
    this.thinkT = 0;
    for (const [id, def] of Object.entries(npcDefs)) {
      const t = this.targetFor(id, def);
      this.npcs[id] = new Npc(scene, id, def, t.x * TILE + TILE / 2, t.y * TILE + TILE - 2);
      this.npcs[id].target = { x: t.x, y: t.y };
    }
  }

  targetFor(id, def) {
    return scheduleTarget(id, def, this.state.clock.minutes, {
      seed: this.seed, shore: this.shore, isBlocked: this.blocked, festival: this.festival(),
    });
  }

  festival() { return festivalToday(this.events, this.state.clock); }

  /** The NPC standing near a world point (the tile the player is facing/aiming at). */
  at(wx, wy) {
    for (const n of Object.values(this.npcs)) if (Math.hypot(n.x - wx, n.y - 6 - wy) < 13) return n;
    return null;
  }

  /** After sleeping: everyone starts the day at their first scheduled place. */
  resetDay() {
    for (const [id, n] of Object.entries(this.npcs)) {
      const t = this.targetFor(id, n.def);
      n.path = [];
      n.place(t.x * TILE + TILE / 2, t.y * TILE + TILE - 2);
      n.target = { x: t.x, y: t.y };
    }
  }

  update(dt, player) {
    this.thinkT -= dt;
    const think = this.thinkT <= 0;
    if (think) this.thinkT = THINK;

    for (const [id, n] of Object.entries(this.npcs)) {
      if (think) {
        const t = this.targetFor(id, n.def);
        if (!n.target || n.target.x !== t.x || n.target.y !== t.y) {
          n.target = { x: t.x, y: t.y };
          const far = Math.hypot(n.x - player.x, n.y - player.y) > FAR;
          const sx = Math.floor(n.x / TILE), sy = Math.floor((n.y - 1) / TILE);
          const path = far ? null : findPath(this.blocked, sx, sy, t.x, t.y);
          if (path) n.path = path;
          else { n.path = []; n.place(t.x * TILE + TILE / 2, t.y * TILE + TILE - 2); } // far away or unreachable: just be there
        }
      }
      n.walk(dt);
      const visible = this.chunks.active.has(Math.floor(n.x / (16 * TILE)) + ',' + Math.floor(n.y / (16 * TILE)));
      n.sprite.setVisible(visible);
    }
  }
}
