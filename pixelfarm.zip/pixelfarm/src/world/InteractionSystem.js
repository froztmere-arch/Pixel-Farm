import { bus, services } from '../core/services.js';
import { ItemDB } from '../core/ItemDB.js';
import { WATER_MAX } from '../core/GameState.js';
import { TILE } from './constants.js';

const REACH = 2.5 * TILE;       // mouse aiming range
const SWING_TIME = 0.4;         // seconds between swings
const HIT_TIME = 0.16;          // when in the swing the tool actually connects
const PLANT_TIME = 0.25;
const TOOL_NAMES = { axe: 'an axe', pickaxe: 'a pickaxe', water: 'a watering can', hoe: 'a hoe' };

/** Quality of a harvested crop: 0 normal, 1 silver, 2 gold. Skills will raise the odds later (Phase 7). */
export function rollQuality(r = Math.random()) { return r < 0.05 ? 2 : r < 0.25 ? 1 : 0; }

/**
 * Targeting + tools + interacting. Reads the selected hotbar item and the tile the player aims at:
 *   - tile in front of the player (keyboard / touch / gamepad), or the tile under the mouse cursor
 *   - 'interact': harvest ripe crops, pick flowers/mushrooms, open chests, use the bed
 *   - 'tool': swing the selected tool (axe, pickaxe, hoe, watering can) or plant the selected seeds
 * Object behaviour comes from objects.json, items from items.json, crops from crops.json.
 */
export class InteractionSystem {
  constructor(scene, deps, objectDefs, cropDefs) {
    this.scene = scene;
    Object.assign(this, deps); // chunks, gen, farm, state, player, drops, input, mouse (+ npcs, fishing set later)
    this.defs = objectDefs;
    this.crops = cropDefs;
    this.hp = new Map();       // "tx,ty" -> remaining hit points of a damaged object
    this.cooldown = 0;
    this.suppressTool = false;
    this.lastToast = '';
    this.lastToastAt = -1e9;
    this.aim = { x: 0, y: 1 };
    this.tx = 0;
    this.ty = 0;
    this.highlight = scene.add.rectangle(0, 0, TILE, TILE, 0xffffff, 0.14)
      .setOrigin(0, 0).setStrokeStyle(1, 0xffffff, 0.9).setDepth(1e8);
  }

  toast(msg) {
    const now = performance.now();
    if (msg === this.lastToast && now - this.lastToastAt < 1500) return;
    this.lastToast = msg;
    this.lastToastAt = now;
    bus.emit('ui:toast', msg);
  }

  computeTarget() {
    const p = this.player;
    const ox = p.x, oy = p.y - 6;
    const m = this.mouse;
    if (m && m.active) {
      const wp = this.scene.cameras.main.getWorldPoint(m.x, m.y);
      let dx = wp.x - ox, dy = wp.y - oy;
      const d = Math.hypot(dx, dy);
      if (d > REACH) { dx *= REACH / d; dy *= REACH / d; }
      this.aim.x = dx;
      this.aim.y = dy;
      this.tx = Math.floor((ox + dx) / TILE);
      this.ty = Math.floor((oy + dy) / TILE);
    } else {
      const f = p.facingVector();
      this.aim.x = f.x;
      this.aim.y = f.y;
      this.tx = Math.floor((ox + f.x * 14) / TILE);
      this.ty = Math.floor((oy + f.y * 14) / TILE);
    }
  }

  /** Can the hoe turn this tile into farmland? Grass only: no water, objects or existing soil. */
  canTill(tx, ty) {
    return !this.gen.isWater(tx, ty) && !this.farm.isTilled(tx, ty) && !this.gen.objectOnLand(tx, ty);
  }

  /** Does the current target make sense for what the player is holding? (drives the highlight colour) */
  isUseful(tx, ty, obj, def, item) {
    if (this.farm.isRipe(tx, ty)) return true;
    if (def && (def.gather || def.interact)) return true;
    if (this.npcs && this.npcs.at((tx + 0.5) * TILE, (ty + 0.5) * TILE)) return true;
    if (!item) return false;
    if (item.tool === 'rod') return this.gen.isWater(tx, ty);
    if (def && def.tool && item.tool === def.tool) return true;
    if (item.tool === 'hoe') return this.canTill(tx, ty);
    if (item.tool === 'water') return this.farm.isTilled(tx, ty) || this.gen.isWater(tx, ty);
    if (item.type === 'seed') { const t = this.farm.get(tx, ty); return !!(t && !t.c); }
    return false;
  }

  update(dt) {
    this.cooldown = Math.max(0, this.cooldown - dt);
    const input = this.input;
    if (input.blocked || this.frozen) { this.highlight.setVisible(false); return; }

    this.computeTarget();
    const { tx, ty } = this;
    const obj = this.chunks.getObject(tx, ty);
    const def = obj ? this.defs[obj.frame] : null;
    const item = this.state.selectedItem();

    const useful = this.isUseful(tx, ty, obj, def, item);
    this.highlight.setPosition(tx * TILE, ty * TILE).setVisible(true);
    this.highlight.setFillStyle(useful ? 0xffe066 : 0xffffff, useful ? 0.28 : 0.1);
    this.highlight.setStrokeStyle(1, useful ? 0xffe066 : 0xffffff, 0.9);

    if (this.suppressTool && !input.isDown('tool')) this.suppressTool = false;
    if (this.player.busy || services.uiHover) return;

    if (input.justPressed('interact') && this.tryInteract(tx, ty, obj, def)) {
      this.suppressTool = true; // the touch USE button presses both: do not also swing
      return;
    }
    if (!this.suppressTool && this.cooldown <= 0 && (input.justPressed('tool') || input.isDown('tool'))) {
      this.tryTool(tx, ty, item, input.justPressed('tool'));
    }
  }

  // ---- interact ----------------------------------------------------------------------------

  tryInteract(tx, ty, obj, def) {
    const npc = this.npcs && this.npcs.at((tx + 0.5) * TILE, (ty + 0.5) * TILE);
    if (npc) {
      npc.face(this.player.x - npc.x, this.player.y - npc.y);
      bus.emit('npc:talk', npc.id);
      return true;
    }
    if (this.farm.isRipe(tx, ty)) return this.harvest(tx, ty);
    if (!def) return false;

    if (def.gather) {
      const n = def.count || 1;
      const left = this.state.inventory.add(def.gather, n);
      if (left === n) { bus.emit('ui:toast', 'Backpack is full'); return true; }
      bus.emit('ui:pickup', def.gather, n - left, 0);
      if (left > 0) this.drops.spawn(def.gather, left, (tx + 0.5) * TILE, (ty + 0.7) * TILE, ItemDB.get(def.gather).icon);
      this.removeObject(tx, ty);
      return true;
    }

    if (def.interact === 'chest') {
      const key = tx + ',' + ty;
      const inv = this.state.container(key);
      this.gen.setObject(tx, ty, { ...obj, frame: 'chest_open' });
      this.chunks.refreshTile(tx, ty);
      bus.emit('ui:openContainer', {
        inv, title: 'Chest',
        onClose: () => {
          this.gen.setObject(tx, ty, { ...obj, frame: 'chest_closed' });
          this.chunks.refreshTile(tx, ty);
        },
      });
      return true;
    }

    if (def.interact === 'bin') {
      const inv = this.state.container('bin', 9);
      this.gen.setObject(tx, ty, { ...obj, frame: 'bin_open' });
      this.chunks.refreshTile(tx, ty);
      bus.emit('ui:openContainer', {
        inv, title: 'Shipping Bin (sold when you sleep)',
        onClose: () => {
          this.gen.setObject(tx, ty, { ...obj, frame: 'bin_closed' });
          this.chunks.refreshTile(tx, ty);
        },
      });
      return true;
    }

    if (def.interact === 'bed') {
      bus.emit('ui:confirm', { text: 'Go to sleep and start a new day?', onYes: () => bus.emit('game:sleep', false) });
      return true;
    }
    return false;
  }

  harvest(tx, ty) {
    const cropId = this.farm.get(tx, ty).c.id;
    const itemId = this.crops[cropId].item;
    const q = ItemDB.get(itemId).quality ? rollQuality() : 0;
    if (!this.state.inventory.canAdd(itemId, 1, q)) { bus.emit('ui:toast', 'Backpack is full'); return true; }
    this.farm.harvest(tx, ty);
    this.state.inventory.add(itemId, 1, q);
    this.chunks.refreshFarm(tx, ty);
    bus.emit('ui:pickup', itemId, 1, q);
    return true;
  }

  removeObject(tx, ty, replacement = null) {
    this.gen.setObject(tx, ty, replacement);
    this.chunks.refreshTile(tx, ty);
    this.hp.delete(tx + ',' + ty);
  }

  // ---- tools & seeds -----------------------------------------------------------------------

  tryTool(tx, ty, item, fresh) {
    if (!item) return;
    if (item.type === 'seed') { this.plantSeed(tx, ty, item, fresh); return; }
    if (item.type !== 'tool') return;
    this.cooldown = SWING_TIME;
    this.player.setFacing(this.aim.x, this.aim.y);
    this.player.startUse({
      anim: item.anim, hitTime: HIT_TIME, duration: SWING_TIME,
      onHit: () => this.applyTool(item, tx, ty),
    });
  }

  plantSeed(tx, ty, item, fresh) {
    this.cooldown = PLANT_TIME;
    const crop = this.crops[item.plants];
    const tile = this.farm.get(tx, ty);
    if (!tile) { if (fresh) this.toast('Plant seeds on tilled soil (use the hoe)'); return; }
    if (tile.c) return;
    const season = this.state.clock.season;
    if (!crop.seasons.includes(season)) { this.toast(crop.name + ' will not grow in ' + season); return; }
    this.state.inventory.removeAt(this.state.selected, 1);
    this.farm.plant(tx, ty, item.plants);
    this.chunks.refreshFarm(tx, ty);
  }

  applyTool(item, tx, ty) {
    if (item.tool === 'rod') { this.castRod(); return; }
    if (item.tool === 'hoe') { this.till(tx, ty); return; }
    if (item.tool === 'water') { this.waterTile(tx, ty); return; }

    const obj = this.chunks.getObject(tx, ty);
    const def = obj ? this.defs[obj.frame] : null;
    if (!def || !def.tool) return; // swung at nothing
    if (def.tool !== item.tool) {
      this.toast('You need ' + (TOOL_NAMES[def.tool] || 'another tool') + ' for that');
      return;
    }

    const key = tx + ',' + ty;
    const hp = (this.hp.has(key) ? this.hp.get(key) : def.hp) - (item.power || 1);
    if (hp > 0) {
      this.hp.set(key, hp);
      this.shake(tx, ty);
      return;
    }

    for (const d of def.drops || []) {
      const n = d.min + Math.floor(Math.random() * (d.max - d.min + 1));
      if (n > 0) this.drops.spawn(d.item, n, (tx + 0.5) * TILE, (ty + 0.6) * TILE, ItemDB.get(d.item).icon);
    }
    this.removeObject(tx, ty, def.leaves ? { frame: def.leaves, blocks: true, kind: 'blocker' } : null);
  }

  /** Finds the water in front of the player (up to 3 tiles) - or under the mouse - and casts. */
  castRod() {
    const m = this.mouse;
    if (m && m.active) {
      if (this.gen.isWater(this.tx, this.ty)) this.fishing.cast(this.tx, this.ty);
      else this.toast('Aim at the water to fish');
      return;
    }
    const p = this.player, f = p.facingVector();
    for (let i = 1; i <= 3; i++) {
      const x = Math.floor((p.x + f.x * i * TILE) / TILE), y = Math.floor((p.y - 6 + f.y * i * TILE) / TILE);
      if (this.gen.isWater(x, y)) { this.fishing.cast(x, y); return; }
    }
    this.toast('Face the water to fish');
  }

  till(tx, ty) {
    if (this.farm.isTilled(tx, ty)) return;
    if (!this.canTill(tx, ty)) { if (!this.gen.isWater(tx, ty)) this.toast('Clear the tile first'); return; }
    this.farm.till(tx, ty);
    this.chunks.refreshFarm(tx, ty);
  }

  waterTile(tx, ty) {
    const st = this.state;
    if (this.gen.isWater(tx, ty)) {
      st.water = WATER_MAX;
      st.inventory.version++; // makes the hotbar redraw the can level
      this.toast('Watering can refilled');
      return;
    }
    if (!this.farm.isTilled(tx, ty)) return;
    if (st.water <= 0) { this.toast('The can is empty - refill it at the water'); return; }
    if (this.farm.water(tx, ty)) {
      st.water--;
      st.inventory.version++;
      this.chunks.refreshFarm(tx, ty);
    }
  }

  shake(tx, ty) {
    const s = this.chunks.getSprite(tx, ty);
    if (!s) return;
    const bx = tx * TILE + TILE / 2;
    this.scene.tweens.killTweensOf(s);
    s.x = bx;
    this.scene.tweens.add({
      targets: s, x: bx + 2, duration: 40, yoyo: true, repeat: 2,
      onComplete: () => { s.x = bx; },
    });
  }
}
