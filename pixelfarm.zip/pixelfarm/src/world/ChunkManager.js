import { TILE, CHUNK, CHUNK_PX } from './constants.js';

const GROUND_DEPTH = -1e9;   // tile layers
const FARM_DEPTH = -9e8;     // soil + crops, above grass
const FLAT_DEPTH = -1e8;     // flowers/mushrooms: always under characters and trees

/**
 * Streams the world: only chunks near the player exist. Tile layers and sprites are pooled, so
 * walking around creates no garbage and no new GPU textures after the first few chunks.
 */
export class ChunkManager {
  constructor(scene, gen, farm) {
    this.scene = scene;
    this.gen = gen;
    this.farm = farm;
    this.active = new Map();
    this.layerPool = [];
    this.spritePool = [];
    this.radiusX = 1;
    this.radiusY = 1;
    this.loadBudget = 1; // chunks built per frame while walking
    this._lastCx = null;
    this._lastCy = null;
    this._pending = true;
  }

  /** viewW/viewH: visible world pixels. Radius is enough chunks to cover the screen from any spot. */
  setView(viewW, viewH) {
    this.radiusX = Math.max(1, Math.ceil(viewW / 2 / CHUNK_PX));
    this.radiusY = Math.max(1, Math.ceil(viewH / 2 / CHUNK_PX));
    this._pending = true;
  }

  update(px, py, budget = this.loadBudget) {
    const pcx = Math.floor(px / CHUNK_PX), pcy = Math.floor(py / CHUNK_PX);
    const rx = this.radiusX, ry = this.radiusY;
    // Nothing to do unless the player changed chunk or chunks are still queued.
    if (pcx === this._lastCx && pcy === this._lastCy && !this._pending && budget !== Infinity) return;
    this._lastCx = pcx;
    this._lastCy = pcy;

    for (const [key, ch] of this.active) {
      if (Math.abs(ch.cx - pcx) > rx + 1 || Math.abs(ch.cy - pcy) > ry + 1) this.release(key, ch);
    }

    const missing = [];
    for (let dy = -ry; dy <= ry; dy++) {
      for (let dx = -rx; dx <= rx; dx++) {
        const cx = pcx + dx, cy = pcy + dy;
        if (!this.active.has(cx + ',' + cy)) missing.push({ cx, cy, d: dx * dx + dy * dy });
      }
    }
    this._pending = missing.length > budget;
    if (!missing.length) return;
    missing.sort((a, b) => a.d - b.d);
    for (let i = 0; i < Math.min(budget, missing.length); i++) this.load(missing[i].cx, missing[i].cy);
  }

  /** Builds everything around the player immediately (used once at start). */
  loadAllAround(px, py) { this.update(px, py, Infinity); }

  isBlocked(tx, ty) {
    const cx = Math.floor(tx / CHUNK), cy = Math.floor(ty / CHUNK);
    const ch = this.active.get(cx + ',' + cy);
    if (ch) return ch.blocked[(ty - cy * CHUNK) * CHUNK + (tx - cx * CHUNK)] === 1;
    return this.gen.isBlockedAt(tx, ty);
  }

  isBlockedPx(x, y) { return this.isBlocked(Math.floor(x / TILE), Math.floor(y / TILE)); }

  get count() { return this.active.size; }

  /** One pair per chunk: grass/water edges, and soil + crops on top (separate tilemaps: separate tilesets). */
  makeLayer() {
    const mk = (key, name, depth) => {
      const map = this.scene.make.tilemap({ tileWidth: TILE, tileHeight: TILE, width: CHUNK, height: CHUNK });
      const tileset = map.addTilesetImage(key, key, TILE, TILE, 0, 0);
      return map.createBlankLayer(name, tileset, 0, 0, CHUNK, CHUNK).setDepth(depth);
    };
    return { ground: mk('grass', 'ground', GROUND_DEPTH), farm: mk('farm', 'farm', FARM_DEPTH) };
  }

  /** Redraws one soil/crop tile after the farm changed. */
  refreshFarm(tx, ty) {
    const cx = Math.floor(tx / CHUNK), cy = Math.floor(ty / CHUNK);
    const ch = this.active.get(cx + ',' + cy);
    if (!ch) return;
    const lx = tx - cx * CHUNK, ly = ty - cy * CHUNK;
    const idx = this.farm.tileIndex(tx, ty);
    if (idx >= 0) { ch.layers.farm.putTileAt(idx, lx, ly, false); ch.farmIdx.add(ly * CHUNK + lx); }
    else { ch.layers.farm.removeTileAt(lx, ly, true, false); ch.farmIdx.delete(ly * CHUNK + lx); }
  }

  /** The decoration on a land tile (null for water/empty). Includes player changes. */
  getObject(tx, ty) {
    if (this.gen.isWater(tx, ty)) return null;
    return this.gen.objectOnLand(tx, ty);
  }

  getSprite(tx, ty) {
    const cx = Math.floor(tx / CHUNK), cy = Math.floor(ty / CHUNK);
    const ch = this.active.get(cx + ',' + cy);
    return ch ? ch.sprites.get((ty - cy * CHUNK) * CHUNK + (tx - cx * CHUNK)) : undefined;
  }

  /** Re-reads one tile's decoration after the world changed (tree felled, flower picked...). */
  refreshTile(tx, ty) {
    const cx = Math.floor(tx / CHUNK), cy = Math.floor(ty / CHUNK);
    const ch = this.active.get(cx + ',' + cy);
    if (!ch) return;
    const idx = (ty - cy * CHUNK) * CHUNK + (tx - cx * CHUNK);
    const old = ch.sprites.get(idx);
    if (old) { this.recycleSprite(old); ch.sprites.delete(idx); }
    const o = this.gen.objectOnLand(tx, ty);
    if (o) {
      ch.sprites.set(idx, this.acquireSprite({ frame: o.frame, px: tx * TILE + TILE / 2, py: ty * TILE + TILE, blocks: o.blocks }));
      ch.blocked[idx] = o.blocks ? 1 : 0;
    } else {
      ch.blocked[idx] = 0;
    }
  }

  recycleSprite(s) {
    this.scene.tweens.killTweensOf(s);
    s.setVisible(false).setActive(false);
    this.spritePool.push(s);
  }

  acquireSprite(o) {
    let img = this.spritePool.pop();
    if (!img) {
      img = this.scene.add.image(0, 0, 'objects');
      img.setOrigin(0.5, 1);
    }
    img.setFrame(o.frame);
    img.setPosition(o.px, o.py);
    img.setDepth(o.blocks ? o.py : FLAT_DEPTH);
    img.setVisible(true).setActive(true);
    return img;
  }

  load(cx, cy) {
    const data = this.gen.generateChunk(cx, cy);
    const layers = this.layerPool.pop() || this.makeLayer();
    const layer = layers.ground;
    for (const l of [layers.ground, layers.farm]) {
      l.setPosition(cx * CHUNK_PX, cy * CHUNK_PX);
      l.setVisible(true).setActive(true);
    }
    for (let ly = 0; ly < CHUNK; ly++) {
      for (let lx = 0; lx < CHUNK; lx++) {
        const idx = data.tiles[ly * CHUNK + lx];
        if (idx >= 0) layer.putTileAt(idx, lx, ly, false);
        else layer.removeTileAt(lx, ly, true, false);
      }
    }
    const sprites = new Map();
    for (const o of data.objects) sprites.set(o.idx, this.acquireSprite(o));
    const farmIdx = new Set();
    const ch = { cx, cy, layers, sprites, blocked: data.blocked, farmIdx };
    this.active.set(cx + ',' + cy, ch);
    const keys = this.farm.tilesInChunk(cx, cy);
    if (keys) for (const k of keys) { const [x, y] = k.split(',').map(Number); this.refreshFarm(x, y); }
  }

  release(key, ch) {
    for (const i of ch.farmIdx) ch.layers.farm.removeTileAt(i % CHUNK, Math.floor(i / CHUNK), true, false);
    ch.layers.ground.setVisible(false).setActive(false);
    ch.layers.farm.setVisible(false).setActive(false);
    this.layerPool.push(ch.layers);
    for (const s of ch.sprites.values()) this.recycleSprite(s);
    this.active.delete(key);
  }
}
