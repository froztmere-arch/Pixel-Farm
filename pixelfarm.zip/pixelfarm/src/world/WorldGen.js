import { CHUNK, TILE, GRASS_FILL, GRASS_VARIANTS, edgeTile } from './constants.js';

/** Deterministic integer hash -> [0,1). Same inputs always give the same output (seeded worlds). */
export function hash(seed, x, y, salt) {
  let h = seed ^ Math.imul(x, 0x27d4eb2d) ^ Math.imul(y, 0x165667b1) ^ Math.imul(salt, 0x9e3779b1);
  h = Math.imul(h ^ (h >>> 15), 0x85ebca6b);
  h = Math.imul(h ^ (h >>> 13), 0xc2b2ae35);
  h ^= h >>> 16;
  return (h >>> 0) / 4294967296;
}

function valueNoise(seed, x, y, salt) {
  const x0 = Math.floor(x), y0 = Math.floor(y);
  const fx = x - x0, fy = y - y0;
  const u = fx * fx * (3 - 2 * fx), v = fy * fy * (3 - 2 * fy);
  const a = hash(seed, x0, y0, salt), b = hash(seed, x0 + 1, y0, salt);
  const c = hash(seed, x0, y0 + 1, salt), d = hash(seed, x0 + 1, y0 + 1, salt);
  return a + (b - a) * u + (c - a) * v + (a - b - c + d) * u * v;
}

function fbm(seed, x, y, salt) {
  return (
    valueNoise(seed, x, y, salt) * 0.5 +
    valueNoise(seed, x * 2, y * 2, salt + 1) * 0.3 +
    valueNoise(seed, x * 4, y * 4, salt + 2) * 0.2
  );
}

function makePicker(list) {
  const total = list.reduce((s, e) => s + e.weight, 0);
  return (r) => {
    let t = r * total;
    for (const e of list) { t -= e.weight; if (t < 0) return e.frame; }
    return list[list.length - 1].frame;
  };
}

/**
 * Pure world generator (no Phaser). Everything is a function of (seed, tile x, tile y), so chunks can be
 * created, thrown away and recreated at any time, and only player *changes* ever need saving.
 */
export class WorldGen {
  constructor(seed, decor) {
    this.seed = seed | 0;
    this.d = decor;
    this.pickTree = makePicker(decor.trees);
    this.pickBlocker = makePicker(decor.blockers);
    this.pickMeadow = makePicker(decor.meadow);
    this.pickWoodland = makePicker(decor.woodland);
    this.blockerFrames = new Set(decor.blockers.map((b) => b.frame));
    // Player changes to the world ("delta"): key "x,y" -> object replacing the generated one, or null = removed.
    // Only this map ever needs saving; everything else is re-generated from the seed.
    this.mods = new Map();
    this.modVersion = 0;
  }

  setObject(x, y, obj) { this.mods.set(x + ',' + y, obj); this.modVersion++; }
  exportMods() { return [...this.mods.entries()]; }
  importMods(entries) { this.mods = new Map(entries); this.modVersion++; }

  baseWater(x, y) {
    let n = fbm(this.seed, x / 28, y / 28, 100);
    const dist = Math.hypot(x, y);
    n += Math.max(0, 1 - dist / 18) * 0.6;           // keep the spawn area dry
    return n < this.d.waterLevel;
  }

  /** Water, minus 1-tile-wide land slivers (they cannot be drawn with the edge tiles). */
  isWater(x, y) {
    const b = (px, py) => this.baseWater(px, py);
    if (b(x, y)) return true;
    return (b(x - 1, y) && b(x + 1, y)) || (b(x, y - 1) && b(x, y + 1));
  }

  forest(x, y) { return fbm(this.seed ^ 0x5bd1e995, x / 14, y / 14, 200); }

  /** Decoration on a land tile: null, or {frame, blocks, kind}. */
  objectOnLand(x, y) {
    const mod = this.mods.get(x + ',' + y);
    if (mod !== undefined) return mod;
    const d = this.d;
    if (x * x + y * y < d.spawnClearRadius * d.spawnClearRadius) return null;
    const inForest = this.forest(x, y) > d.forestThreshold;
    const s = this.seed;
    if (hash(s, x, y, 21) < (inForest ? d.treeChanceInForest : d.treeChanceOutside)) {
      return { frame: this.pickTree(hash(s, x, y, 22)), blocks: true, kind: 'tree' };
    }
    if (hash(s, x, y, 23) < d.blockerChance) {
      return { frame: this.pickBlocker(hash(s, x, y, 24)), blocks: true, kind: 'blocker' };
    }
    if (hash(s, x, y, 25) < d.plantChance) {
      const f = inForest ? this.pickWoodland(hash(s, x, y, 26)) : this.pickMeadow(hash(s, x, y, 26));
      return { frame: f, blocks: false, kind: 'plant' };
    }
    return null;
  }

  isBlockedAt(x, y) {
    if (this.isWater(x, y)) return true;
    const o = this.objectOnLand(x, y);
    return !!(o && o.blocks);
  }

  /**
   * Builds the data for one chunk:
   *  tiles:   Int16Array(CHUNK*CHUNK) tileset indices, -1 = water (the animated water layer shows through)
   *  blocked: Uint8Array(CHUNK*CHUNK) 1 = cannot walk
   *  objects: [{frame, px, py, blocks}] world-pixel positions (bottom-centre of the tile)
   */
  generateChunk(cx, cy) {
    const N = CHUNK + 4;
    const base = new Uint8Array(N * N);
    const ox = cx * CHUNK - 2, oy = cy * CHUNK - 2;
    for (let j = 0; j < N; j++) {
      for (let i = 0; i < N; i++) base[j * N + i] = this.baseWater(ox + i, oy + j) ? 1 : 0;
    }
    const b = (lx, ly) => base[(ly + 2) * N + (lx + 2)];
    const water = (lx, ly) => !!(b(lx, ly) || (b(lx - 1, ly) && b(lx + 1, ly)) || (b(lx, ly - 1) && b(lx, ly + 1)));

    const tiles = new Int16Array(CHUNK * CHUNK);
    const blocked = new Uint8Array(CHUNK * CHUNK);
    const objects = [];

    for (let ly = 0; ly < CHUNK; ly++) {
      for (let lx = 0; lx < CHUNK; lx++) {
        const i = ly * CHUNK + lx;
        const wx = cx * CHUNK + lx, wy = cy * CHUNK + ly;
        if (water(lx, ly)) { tiles[i] = -1; blocked[i] = 1; continue; }

        const wW = water(lx - 1, ly), wE = water(lx + 1, ly), wN = water(lx, ly - 1), wS = water(lx, ly + 1);
        if (wW || wE || wN || wS) {
          tiles[i] = edgeTile(wW, wE, wN, wS);
        } else {
          const h = hash(this.seed, wx, wy, 11);
          tiles[i] = h < 0.16 ? GRASS_VARIANTS[Math.floor((h / 0.16) * GRASS_VARIANTS.length)] : GRASS_FILL;
        }

        const o = this.objectOnLand(wx, wy);
        if (o) {
          if (o.blocks) blocked[i] = 1;
          objects.push({ idx: i, frame: o.frame, px: wx * TILE + TILE / 2, py: wy * TILE + TILE, blocks: o.blocks });
        }
      }
    }
    return { tiles, blocked, objects };
  }
}
