import { CHUNK } from './constants.js';

export const FARM_COLS = 6; // columns of farm.png

/**
 * Tilled soil and crops. A tile is {w: watered 0|1, c: null | {id, d: days grown}}.
 * Crops grow at dawn, and only if the tile was watered the day before (or it rained).
 */
export class Farm {
  constructor(crops) {
    this.crops = crops;
    this.tiles = new Map();
    this.byChunk = new Map();
    this.version = 0;
  }

  static chunkKey(x, y) { return Math.floor(x / CHUNK) + ',' + Math.floor(y / CHUNK); }

  get(x, y) { return this.tiles.get(x + ',' + y); }
  isTilled(x, y) { return this.tiles.has(x + ',' + y); }

  add(x, y, tile) {
    const k = x + ',' + y;
    this.tiles.set(k, tile);
    const ck = Farm.chunkKey(x, y);
    let set = this.byChunk.get(ck);
    if (!set) { set = new Set(); this.byChunk.set(ck, set); }
    set.add(k);
  }

  till(x, y) {
    if (this.isTilled(x, y)) return false;
    this.add(x, y, { w: 0, c: null });
    this.version++;
    return true;
  }

  water(x, y) {
    const t = this.get(x, y);
    if (!t || t.w) return false;
    t.w = 1;
    this.version++;
    return true;
  }

  plant(x, y, cropId) {
    const t = this.get(x, y);
    if (!t || t.c) return false;
    t.c = { id: cropId, d: 0 };
    this.version++;
    return true;
  }

  stageOf(crop) {
    let stage = 0, acc = 0;
    for (const n of this.crops[crop.id].stageDays) {
      acc += n;
      if (crop.d >= acc) stage++; else break;
    }
    return stage;
  }

  isRipe(x, y) {
    const t = this.get(x, y);
    return !!(t && t.c && this.stageOf(t.c) >= this.crops[t.c.id].stageDays.length);
  }

  /** Removes a ripe crop and returns the harvested item id (or null). */
  harvest(x, y) {
    if (!this.isRipe(x, y)) return null;
    const t = this.get(x, y);
    const item = this.crops[t.c.id].item;
    t.c = null;
    this.version++;
    return item;
  }

  /** Tile index in farm.png: row 0 soil (dry, wet); rows 1-2 crops on dry soil; rows 3-4 on wet soil. */
  tileIndex(x, y) {
    const t = this.get(x, y);
    if (!t) return -1;
    if (!t.c) return t.w ? 1 : 0;
    return (1 + this.crops[t.c.id].row + (t.w ? 2 : 0)) * FARM_COLS + 1 + this.stageOf(t.c);
  }

  tilesInChunk(cx, cy) { return this.byChunk.get(cx + ',' + cy); }

  /** New morning. Returns {changed: ["x,y"...], withered: n}. */
  advanceDay(newSeason, raining) {
    const changed = [];
    let withered = 0;
    for (const [key, t] of this.tiles) {
      let touched = false;
      if (t.c) {
        if (!this.crops[t.c.id].seasons.includes(newSeason)) { t.c = null; withered++; touched = true; }
        else if (t.w) { t.c.d++; touched = true; }
      }
      const nw = raining ? 1 : 0;
      if (t.w !== nw) { t.w = nw; touched = true; }
      if (touched) changed.push(key);
    }
    this.version++;
    return { changed, withered };
  }

  toJSON() { return [...this.tiles].map(([k, t]) => [k, t.w, t.c ? [t.c.id, t.c.d] : 0]); }

  static fromJSON(arr, crops) {
    const f = new Farm(crops);
    for (const [k, w, c] of arr) {
      const [x, y] = k.split(',').map(Number);
      f.add(x, y, { w, c: c ? { id: c[0], d: c[1] } : null });
    }
    return f;
  }
}
