import { bus } from '../core/services.js';
import { ItemDB } from '../core/ItemDB.js';
import { pickFish, fishQuality } from '../core/Fishing.js';
import { TILE } from './constants.js';

/**
 * Cast -> wait for a bite -> reeling mini-game (UI scene) -> catch.
 * What bites depends on season, time of day, weather and whether the water is shallow or deep (fish.json).
 */
export class FishingSystem {
  constructor(scene, { gen, state, player, interaction, input, social, drops, fishDefs }) {
    Object.assign(this, { scene, gen, state, player, interaction, input, social, drops, fishDefs });
    this.phase = 'idle';
    this.timer = 0;
    this.fishId = null;
    this.bobber = null;
    this.onResult = (r) => this.finish(r);
    bus.on('fishing:result', this.onResult);
  }

  destroy() {
    bus.off('fishing:result', this.onResult);
    this.cleanup();
  }

  get active() { return this.phase !== 'idle'; }

  /** Deep water = mostly water all around (a 5x5 area). */
  isDeep(tx, ty) {
    let n = 0;
    for (let y = -2; y <= 2; y++) for (let x = -2; x <= 2; x++) if (this.gen.isWater(tx + x, ty + y)) n++;
    return n >= 22;
  }

  cast(tx, ty) {
    if (this.active) return;
    const st = this.state;
    const cond = {
      season: st.clock.season, hour: st.clock.minutes / 60, weather: st.weather,
      location: this.isDeep(tx, ty) ? 'deep' : 'shore',
    };
    const legendary = new Set(Object.keys(st.stats.caught).filter((id) => this.fishDefs[id] && this.fishDefs[id].legendary));
    this.fishId = pickFish(this.fishDefs, cond, Math.random, legendary);
    if (!this.fishId) { bus.emit('ui:toast', 'Nothing seems to be biting...'); return; }

    this.phase = 'waiting';
    this.timer = 2 + Math.random() * 5;
    this.player.frozen = true;
    this.interaction.frozen = true;
    const x = (tx + 0.5) * TILE, y = (ty + 0.5) * TILE;
    this.bobber = this.scene.add.circle(x, y, 2.5, 0xe84a4a).setStrokeStyle(1, 0xffffff, 1).setDepth(1e7);
    this.scene.tweens.add({ targets: this.bobber, y: y + 1.5, duration: 500, yoyo: true, repeat: -1 });
  }

  update(dt) {
    if (this.phase !== 'waiting') return;
    if (this.input.justPressed('dodge')) { this.cancel('You reel the line back in.'); return; }
    this.timer -= dt;
    if (this.timer > 0) return;
    this.phase = 'minigame';
    const def = this.fishDefs[this.fishId];
    this.scene.tweens.killTweensOf(this.bobber);
    this.scene.tweens.add({ targets: this.bobber, scale: 2, duration: 120, yoyo: true, repeat: 2 });
    bus.emit('ui:toast', 'A bite! Hold USE to reel it in');
    bus.emit('fishing:start', { id: this.fishId, def, icon: ItemDB.get(def.item).icon });
  }

  cancel(msg) {
    if (msg) bus.emit('ui:toast', msg);
    this.cleanup();
  }

  finish({ win, perfect }) {
    if (this.phase !== 'minigame') return;
    if (win) {
      const def = this.fishDefs[this.fishId];
      const q = fishQuality(perfect);
      const inv = this.state.inventory;
      if (inv.canAdd(def.item, 1, q)) inv.add(def.item, 1, q);
      else this.drops.spawn(def.item, 1, this.player.x, this.player.y, ItemDB.get(def.item).icon, q);
      bus.emit('ui:pickup', def.item, 1, q);
      const isNew = this.social.recordCatch(this.fishId, q);
      if (isNew) bus.emit('ui:toast', 'New fish for the aquarium: ' + def.name + '!');
      if (def.legendary) bus.emit('discovery', { type: 'legendary_fish', id: this.fishId });
    } else {
      bus.emit('ui:toast', 'It got away...');
    }
    this.cleanup();
  }

  cleanup() {
    if (this.bobber) { this.scene.tweens.killTweensOf(this.bobber); this.bobber.destroy(); this.bobber = null; }
    this.phase = 'idle';
    this.player.frozen = false;
    this.interaction.frozen = false;
  }
}
