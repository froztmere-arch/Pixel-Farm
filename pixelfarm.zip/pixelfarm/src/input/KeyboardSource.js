const MOVE_KEYS = {
  KeyW: [0, -1], ArrowUp: [0, -1],
  KeyS: [0, 1], ArrowDown: [0, 1],
  KeyA: [-1, 0], ArrowLeft: [-1, 0],
  KeyD: [1, 0], ArrowRight: [1, 0],
};

const ACTION_KEYS = {
  KeyE: 'interact',
  Space: 'tool', KeyJ: 'tool',
  KeyQ: 'swap',
  ShiftLeft: 'dodge', ShiftRight: 'dodge', KeyK: 'dodge',
  KeyI: 'inventory', Tab: 'inventory',
  Escape: 'menu',
  KeyL: 'journal',
  Digit1: 'hotbar1', Digit2: 'hotbar2', Digit3: 'hotbar3', Digit4: 'hotbar4', Digit5: 'hotbar5',
  Digit6: 'hotbar6', Digit7: 'hotbar7', Digit8: 'hotbar8', Digit9: 'hotbar9',
};

/** Keyboard via native DOM events, so it works no matter which scene is active. */
export class KeyboardSource {
  constructor() {
    this.keys = new Set();
    this.latched = new Set(); // keys tapped between two frames still count for one poll
    window.addEventListener('keydown', (e) => {
      if (MOVE_KEYS[e.code] || ACTION_KEYS[e.code]) e.preventDefault();
      this.keys.add(e.code);
      this.latched.add(e.code);
    });
    window.addEventListener('keyup', (e) => this.keys.delete(e.code));
    window.addEventListener('blur', () => this.keys.clear());
  }

  poll(out) {
    let x = 0, y = 0;
    for (const code of this.keys) {
      const m = MOVE_KEYS[code];
      if (m) { x += m[0]; y += m[1]; }
      const a = ACTION_KEYS[code];
      if (a) out.down.add(a);
    }
    for (const code of this.latched) {
      const a = ACTION_KEYS[code];
      if (a) out.down.add(a);
    }
    this.latched.clear();
    const len = Math.hypot(x, y);
    if (len > 1) { x /= len; y /= len; }
    out.x = x;
    out.y = y;
  }
}
