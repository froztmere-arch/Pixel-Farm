/**
 * The ONLY thing gameplay code uses to read input.
 *
 *   input.getMove()           -> {x, y}  analog vector, length <= 1
 *   input.isDown('tool')      -> held this frame
 *   input.justPressed('use')  -> went down this frame
 *   input.justReleased(...)
 *
 * Sources (keyboard, mouse, gamepad, touch) just report their state each frame; gameplay never
 * knows which one is active. Sources implement poll(out) where out = {x, y, down:Set}.
 *
 * Actions: interact, tool, swap, dodge, inventory, menu, hotbarPrev, hotbarNext, hotbar1..hotbar9
 * The touch "USE" button presses interact AND tool: handle it as
 *   if (justPressed('interact') && tryInteract()) return; if (justPressed('tool')) useTool();
 */
export const Action = {
  INTERACT: 'interact',
  TOOL: 'tool',
  SWAP: 'swap',
  DODGE: 'dodge',
  INVENTORY: 'inventory',
  MENU: 'menu',
  HOTBAR_PREV: 'hotbarPrev',
  HOTBAR_NEXT: 'hotbarNext',
};

export class InputManager {
  /** @param {{on:Function}|null} events  emitter that fires 'prestep' once per frame (game.events) */
  constructor(events) {
    this.sources = [];
    this.move = { x: 0, y: 0 };
    this.blocked = false;
    this.down = new Set();
    this._last = new Set();
    this._pressed = new Set();
    this._released = new Set();
    this._out = { x: 0, y: 0, down: new Set() };
    if (events) events.on('prestep', this.update, this);
  }

  addSource(src) { this.sources.push(src); return src; }

  /** While blocked (menus open) gameplay sees no input except 'menu' and 'inventory' (to close). */
  setBlocked(v) { this.blocked = !!v; }

  update() {
    let bx = 0, by = 0, bm = 0;
    this.down.clear();
    const o = this._out;
    for (const src of this.sources) {
      o.x = 0; o.y = 0; o.down.clear();
      src.poll(o);
      const m = Math.hypot(o.x, o.y);
      if (m > bm) { bm = m; bx = o.x; by = o.y; }
      for (const a of o.down) this.down.add(a);
    }
    if (bm > 1) { bx /= bm; by /= bm; }

    if (this.blocked) {
      const keepMenu = this.down.has(Action.MENU);
      const keepInv = this.down.has(Action.INVENTORY);
      this.down.clear();
      if (keepMenu) this.down.add(Action.MENU);
      if (keepInv) this.down.add(Action.INVENTORY);
      bx = 0; by = 0;
    }
    this.move.x = bx;
    this.move.y = by;

    this._pressed.clear();
    this._released.clear();
    for (const a of this.down) if (!this._last.has(a)) this._pressed.add(a);
    for (const a of this._last) if (!this.down.has(a)) this._released.add(a);
    this._last.clear();
    for (const a of this.down) this._last.add(a);
  }

  getMove() { return this.move; }
  isDown(a) { return this.down.has(a); }
  justPressed(a) { return this._pressed.has(a); }
  justReleased(a) { return this._released.has(a); }
}
