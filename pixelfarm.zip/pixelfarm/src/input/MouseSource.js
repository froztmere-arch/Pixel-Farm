/**
 * Desktop mouse: left button = use tool, right button = interact.
 * Only real mice (pointerType 'mouse'); finger touches are handled by the on-screen controls.
 * The screen position is kept in .x/.y for aiming/tile targeting in later phases.
 */
export class MouseSource {
  constructor(target = window) {
    this.buttons = 0;
    this.latched = 0; // clicks shorter than one frame still register
    this.x = 0;
    this.y = 0;
    this.lastMove = -1e9;
    target.addEventListener('pointerdown', (e) => {
      if (e.pointerType === 'mouse') { this.buttons = e.buttons; this.latched |= e.buttons; }
    });
    target.addEventListener('pointerup', (e) => { if (e.pointerType === 'mouse') this.buttons = e.buttons; });
    target.addEventListener('pointermove', (e) => {
      if (e.pointerType === 'mouse') { this.x = e.clientX; this.y = e.clientY; this.lastMove = performance.now(); }
    });
    target.addEventListener('blur', () => { this.buttons = 0; });
    target.addEventListener('contextmenu', (e) => e.preventDefault());
  }

  /** True while the mouse was used recently: tools then aim at the tile under the cursor. */
  get active() { return performance.now() - this.lastMove < 3000; }

  poll(out) {
    const b = this.buttons | this.latched;
    this.latched = 0;
    if (b & 1) out.down.add('tool');
    if (b & 2) out.down.add('interact');
  }
}
