const DEADZONE = 0.2;

/** Standard-mapping gamepad. Left stick / d-pad move; A interact, X tool, Y swap, B dodge. */
export class GamepadSource {
  poll(out) {
    if (typeof navigator === 'undefined' || !navigator.getGamepads) return;
    const pads = navigator.getGamepads();
    for (const pad of pads) {
      if (!pad || !pad.connected) continue;
      const b = (i) => !!(pad.buttons[i] && pad.buttons[i].pressed);

      let x = pad.axes[0] || 0;
      let y = pad.axes[1] || 0;
      if (Math.hypot(x, y) < DEADZONE) { x = 0; y = 0; }
      if (b(14)) x -= 1;
      if (b(15)) x += 1;
      if (b(12)) y -= 1;
      if (b(13)) y += 1;
      if (Math.hypot(x, y) > Math.hypot(out.x, out.y)) { out.x = x; out.y = y; }

      if (b(0)) out.down.add('interact');
      if (b(2)) out.down.add('tool');
      if (b(3)) out.down.add('swap');
      if (b(1)) out.down.add('dodge');
      if (b(4)) out.down.add('hotbarPrev');
      if (b(5)) out.down.add('hotbarNext');
      if (b(8)) out.down.add('inventory');
      if (b(9)) out.down.add('menu');
    }
  }
}
