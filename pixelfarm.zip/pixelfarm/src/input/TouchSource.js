/**
 * Fed by the on-screen TouchControls (UI scene). InputManager polls it like any other source.
 * Presses are latched for one poll, so a very short tap is never lost between frames.
 */
export class TouchSource {
  constructor() {
    this.x = 0;
    this.y = 0;
    this.down = new Set();
    this.latched = new Set();
  }

  press(action) { this.down.add(action); this.latched.add(action); }
  release(action) { this.down.delete(action); }

  clear() {
    this.x = 0;
    this.y = 0;
    this.down.clear();
    this.latched.clear();
  }

  poll(out) {
    out.x = this.x;
    out.y = this.y;
    for (const a of this.down) out.down.add(a);
    for (const a of this.latched) out.down.add(a);
    this.latched.clear();
  }
}
