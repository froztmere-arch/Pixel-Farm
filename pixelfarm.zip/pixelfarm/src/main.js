import Phaser from 'phaser';
import { BootScene } from './scenes/BootScene.js';
import { PreloadScene } from './scenes/PreloadScene.js';
import { MainMenuScene } from './scenes/MainMenuScene.js';
import { WorldScene } from './scenes/WorldScene.js';
import { UIScene } from './scenes/UIScene.js';

const config = {
  type: Phaser.AUTO,
  parent: 'game',
  backgroundColor: '#1b2a1f',
  // Pixel-perfect: nearest-neighbour sampling, no antialiasing, whole-pixel rendering.
  pixelArt: true,
  render: { pixelArt: true, antialias: false, roundPixels: true, powerPreference: 'high-performance' },
  scale: {
    mode: Phaser.Scale.RESIZE, // canvas always fills the screen; each scene picks an integer camera zoom
    width: '100%',
    height: '100%',
  },
  input: { activePointers: 4, touch: { capture: true } }, // multi-touch: joystick + 2-3 buttons at once
  disableContextMenu: true,
  fps: { target: 60 },
  scene: [BootScene, PreloadScene, MainMenuScene, WorldScene, UIScene],
};

new Phaser.Game(config);
