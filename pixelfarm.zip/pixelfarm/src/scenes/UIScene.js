import Phaser from 'phaser';
import { bus, services } from '../core/services.js';
import { wantsTouchUI } from '../core/Platform.js';
import { TouchControls } from '../ui/TouchControls.js';
import { SettingsPanel } from '../ui/SettingsPanel.js';
import { Hotbar } from '../ui/Hotbar.js';
import { InventoryPanel } from '../ui/InventoryPanel.js';
import { ToastFeed } from '../ui/ToastFeed.js';
import { DayTint } from '../ui/DayTint.js';
import { ConfirmDialog } from '../ui/ConfirmDialog.js';
import { DialoguePanel } from '../ui/DialoguePanel.js';
import { ShopPanel } from '../ui/ShopPanel.js';
import { JournalPanel } from '../ui/JournalPanel.js';
import { FishingGame } from '../ui/FishingGame.js';

/** Runs in parallel on top of World: tint, touch controls, hotbar, menus, clock. */
export class UIScene extends Phaser.Scene {
  constructor() { super('UI'); }

  create() {
    this.settings = services.settings;
    const state = this.state = services.state;

    this.tint = new DayTint(this);
    this.touch = new TouchControls(this, services.touch, this.settings);
    this.panel = new SettingsPanel(this, this.settings, {
      onEditLayout: () => {
        this.touch.setVisible(true);
        this.touch.beginEdit();
      },
    });
    this.hotbar = new Hotbar(this, state);
    this.inventory = new InventoryPanel(this, state);
    this.toasts = new ToastFeed(this);
    this.dialog = new ConfirmDialog(this);
    this.dialogue = new DialoguePanel(this);
    this.shop = new ShopPanel(this);
    this.journal = new JournalPanel(this);
    this.fishing = new FishingGame(this);
    this.coin = this.add.image(14, 54, 'items', 'coin').setDepth(1500);
    this.goldText = this.add.text(28, 46, '', {
      fontFamily: 'monospace', fontStyle: 'bold', fontSize: '13px', color: '#ffd24a', stroke: '#000000', strokeThickness: 3,
    }).setDepth(1500);

    this.hud = this.add.text(8, 6, '', {
      fontFamily: 'monospace', fontStyle: 'bold', fontSize: '13px', color: '#fff6d0',
      stroke: '#000000', strokeThickness: 3, lineSpacing: 2,
    }).setDepth(1500);
    this.hudTimer = 0;
    this.debugText = this.add.text(8, 70, '', {
      fontFamily: 'monospace', fontSize: '12px', color: '#ffffff', backgroundColor: '#00000088',
      padding: { x: 4, y: 2 },
    }).setDepth(3000).setVisible(false);
    this.debugTimer = 0;
    this.blocking = null;

    this.layoutHud();
    this.applyControlMode();

    this.onPickup = (id, n, q) => this.toasts.pickup(id, n, q);
    this.onToast = (msg) => this.toasts.message(msg);
    this.onOpenContainer = (data) => this.inventory.show(data);
    this.onConfirm = (d) => this.dialog.show(d.text, d.onYes);
    bus.on('ui:pickup', this.onPickup);
    bus.on('ui:toast', this.onToast);
    bus.on('ui:openContainer', this.onOpenContainer);
    this.onTalk = (id) => this.dialogue.start(id);
    this.onShop = (id) => this.shop.show(id);
    this.onJournal = () => this.journal.show();
    bus.on('ui:confirm', this.onConfirm);
    bus.on('npc:talk', this.onTalk);
    bus.on('ui:openShop', this.onShop);
    bus.on('ui:openJournal', this.onJournal);
    bus.on('settings:changed', this.onSettings, this);
    this.scale.on('resize', this.onResize, this);
    this.input.on('wheel', (p, objs, dx, dy) => {
      if (this.blocking) return;
      state.select(state.selected + (dy > 0 ? 1 : -1));
      bus.emit('hotbar:select');
    });

    this.events.once('shutdown', () => {
      bus.off('ui:pickup', this.onPickup);
      bus.off('ui:toast', this.onToast);
      bus.off('ui:openContainer', this.onOpenContainer);
      bus.off('ui:confirm', this.onConfirm);
      bus.off('npc:talk', this.onTalk);
      bus.off('ui:openShop', this.onShop);
      bus.off('ui:openJournal', this.onJournal);
      this.fishing.destroy();
      bus.off('settings:changed', this.onSettings, this);
      this.scale.off('resize', this.onResize, this);
      this.hotbar.destroy();
      this.touch.destroy();
      services.input.setBlocked(false);
    });
  }

  layoutHud() {
    const { width: W, height: H } = this.scale;
    const touch = wantsTouchUI(this.settings.get('controlMode'));
    this.hotbar.layout(W, H, touch);
    this.toasts.layout(W, H);
    this.tint.layout(W, H);
    if (this.inventory.open) this.inventory.build();
  }

  onSettings(key) {
    if (key === 'controlMode') { this.applyControlMode(); this.layoutHud(); }
    if (key === 'layout') this.touch.layout();
  }

  onResize() {
    this.touch.layout();
    this.layoutHud();
    if (this.panel.open) this.panel.build();
  }

  applyControlMode() {
    this.touch.setVisible(wantsTouchUI(this.settings.get('controlMode')));
  }

  hotbarControls(input) {
    const st = this.state;
    for (let i = 1; i <= 9; i++) {
      if (input.justPressed('hotbar' + i)) { st.select(i - 1); bus.emit('hotbar:select'); }
    }
    if (input.justPressed('hotbarNext') || input.justPressed('swap')) { st.select(st.selected + 1); bus.emit('hotbar:select'); }
    if (input.justPressed('hotbarPrev')) { st.select(st.selected - 1); bus.emit('hotbar:select'); }
  }

  update(time, delta) {
    const input = services.input;

    if (input.justPressed('menu')) {
      if (this.dialog.open) this.dialog.hide();
      else if (this.dialogue.open) this.dialogue.close();
      else if (this.shop.open) this.shop.close();
      else if (this.journal.open) this.journal.close();
      else if (this.touch.editing) this.touch.endEdit();
      else if (this.inventory.open) this.inventory.hide();
      else this.panel.toggle();
    }
    const modal = this.dialog.open || this.dialogue.open || this.shop.open || this.journal.open;
    if (input.justPressed('inventory') && !this.panel.open && !this.touch.editing && !modal) this.inventory.toggle();
    if (input.justPressed('journal') && !this.panel.open && !this.touch.editing && !this.inventory.open && !modal) this.journal.show();

    // While a menu, the inventory, a dialog or the layout editor is open the game sees no input (and time stops).
    const blocking = this.panel.open || this.touch.editing || this.inventory.open || this.dialog.open || this.dialogue.open || this.shop.open || this.journal.open;
    if (blocking !== this.blocking) {
      this.blocking = blocking;
      input.setBlocked(blocking);
    }
    this.touch.setEnabled(!blocking || this.touch.editing);
    this.touch.update();

    services.uiHover = this.input.hitTestPointer(this.input.activePointer).length > 0;
    if (!blocking) this.hotbarControls(input);
    this.hotbar.update();
    this.inventory.update();
    this.toasts.update(delta / 1000);
    this.fishing.update(delta / 1000);

    const st = this.state;
    this.tint.update(st.clock, st.weather);
    this.hudTimer -= delta;
    if (this.hudTimer <= 0) {
      this.hudTimer = 300;
      const weather = st.weather === 'rain' ? 'Rain' : st.weather === 'snow' ? 'Snow' : 'Sunny';
      this.goldText.setText(String(st.gold));
      this.hud.setText(st.clock.dateString() + '\n' + st.clock.timeString() + '  ' + weather);
    }

    const show = this.settings.get('showDebug');
    this.debugText.setVisible(show);
    if (show) {
      this.debugTimer -= delta;
      if (this.debugTimer <= 0) {
        this.debugTimer = 250;
        const d = services.debug;
        this.debugText.setText(
          Math.round(this.game.loop.actualFps) + ' fps  tile ' + d.pos + '  chunks ' + d.chunks +
          '  zoom ' + this.scene.get('World').cameras.main.zoom + 'x');
      }
    }
  }
}
