import Phaser from 'phaser';
import { services } from '../core/services.js';
import { wantsTouchUI } from '../core/Platform.js';

export class MainMenuScene extends Phaser.Scene {
  constructor() { super('MainMenu'); }

  create() {
    this.started = false;
    this.armedNew = false;
    this.hasSave = false;
    const { width, height } = this.scale;
    const s = Math.min(width, height);
    this.fs = Math.round(Math.max(16, s * 0.06));

    this.add.text(width / 2, height * 0.24, 'PIXEL FARM', {
      fontFamily: 'monospace', fontStyle: 'bold', fontSize: Math.round(s * 0.14) + 'px', color: '#e8f5c8',
    }).setOrigin(0.5);
    this.status = this.add.text(width / 2, height * 0.42, 'Loading...', {
      fontFamily: 'monospace', fontSize: Math.round(s * 0.04) + 'px', color: '#9fc27a',
    }).setOrigin(0.5);
    this.add.text(width / 2, height * 0.94, 'Art: Sprout Lands by Cup Nooble', {
      fontFamily: 'monospace', fontSize: Math.round(s * 0.032) + 'px', color: '#6f8f5a',
    }).setOrigin(0.5);

    this.buttons = [];
    services.save.hasSave().then((has) => {
      if (!this.scene.isActive('MainMenu')) return;
      this.hasSave = has;
      this.status.setText(wantsTouchUI(services.settings.get('controlMode')) ? 'Tap a button' : 'Click a button, or press Enter');
      this.buildButtons();
    });

    this.input.keyboard.on('keydown-ENTER', () => (this.hasSave ? this.continueGame() : this.newGame()));
    this.input.keyboard.on('keydown-SPACE', () => (this.hasSave ? this.continueGame() : this.newGame()));
  }

  buildButtons() {
    for (const b of this.buttons) b.destroy();
    this.buttons = [];
    const { width, height } = this.scale;
    const items = this.hasSave
      ? [['Continue', () => this.continueGame(), '#4a6a3a'],
         [this.armedNew ? 'Tap again to ERASE save' : 'New Game', () => this.newGame(), this.armedNew ? '#8a3a3a' : '#5a4a2a']]
      : [['New Game', () => this.newGame(), '#4a6a3a']];
    items.forEach(([label, fn, color], i) => {
      const t = this.add.text(width / 2, height * (0.55 + i * 0.17), label, {
        fontFamily: 'monospace', fontStyle: 'bold', fontSize: this.fs + 'px', color: '#ffffff',
        backgroundColor: color, padding: { x: this.fs, y: this.fs * 0.5 },
      }).setOrigin(0.5).setInteractive({ useHandCursor: true });
      t.on('pointerdown', fn);
      this.buttons.push(t);
    });
  }

  async continueGame() {
    if (this.started) return;
    this.started = true;
    const data = await services.save.load();
    this.scene.start('World', { load: data });
  }

  async newGame() {
    if (this.started) return;
    if (this.hasSave && !this.armedNew) {      // second tap confirms, so a stray tap never erases a save
      this.armedNew = true;
      this.buildButtons();
      return;
    }
    this.started = true;
    await services.save.wipe();
    this.scene.start('World', {});
  }
}
