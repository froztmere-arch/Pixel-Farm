import Phaser from 'phaser';
import { services } from '../core/services.js';
import { Settings } from '../core/Settings.js';
import { InputManager } from '../input/InputManager.js';
import { KeyboardSource } from '../input/KeyboardSource.js';
import { MouseSource } from '../input/MouseSource.js';
import { GamepadSource } from '../input/GamepadSource.js';
import { TouchSource } from '../input/TouchSource.js';
import { ItemDB } from '../core/ItemDB.js';
import { createStorage } from '../core/Storage.js';
import { SaveManager } from '../core/SaveManager.js';
import items from '../data/items.json';

/** Creates the global services once, then hands over to Preload. */
export class BootScene extends Phaser.Scene {
  constructor() { super('Boot'); }

  async create() {
    ItemDB.init(items);
    services.save = new SaveManager(await createStorage());
    services.settings = new Settings();

    const input = new InputManager(this.game.events);
    input.addSource(new KeyboardSource());
    services.mouse = input.addSource(new MouseSource());
    input.addSource(new GamepadSource());
    services.touch = input.addSource(new TouchSource());
    services.input = input;

    this.scene.start('Preload');
  }
}
