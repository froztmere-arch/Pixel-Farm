import Phaser from 'phaser';
import { bus, services } from '../core/services.js';
import { WorldGen } from '../world/WorldGen.js';
import { ChunkManager } from '../world/ChunkManager.js';
import { Player } from '../entities/Player.js';
import { TILE } from '../world/constants.js';
import { DropManager } from '../world/DropManager.js';
import { InteractionSystem } from '../world/InteractionSystem.js';
import { Farm } from '../world/Farm.js';
import { GameState } from '../core/GameState.js';
import { weatherFor } from '../core/Clock.js';
import { RECORDS } from '../core/SaveManager.js';
import { Social } from '../core/Social.js';
import { NpcManager } from '../world/NpcManager.js';
import { FishingSystem } from '../world/FishingSystem.js';
import { ItemDB } from '../core/ItemDB.js';
import { sellPrice, festivalToday } from '../core/Economy.js';
import npcDefs from '../data/npcs.json';
import questDefs from '../data/quests.json';
import fishDefs from '../data/fish.json';
import eventDefs from '../data/events.json';
import decor from '../data/decor.json';
import objectDefs from '../data/objects.json';
import cropDefs from '../data/crops.json';

const AUTOSAVE_SECONDS = 45;

export class WorldScene extends Phaser.Scene {
  constructor() { super('World'); }

  /** data.load = records from SaveManager.load(), or nothing for a new game. */
  init(data) { this.loadData = (data && data.load) || null; }

  create() {
    const load = this.loadData;
    this.save = services.save;
    this.seed = load ? load.meta.seed : Math.floor(Math.random() * 0x7fffffff);
    this.gen = new WorldGen(this.seed, decor);
    this.farm = load && load.farm ? Farm.fromJSON(load.farm, cropDefs) : new Farm(cropDefs);

    if (load) {
      this.gen.importMods(load.mods || []);
      this.state = GameState.fromSave(load);
    } else {
      this.state = new GameState();
      // Starter props near the spawn point, stored as world changes so they are saved like any other.
      this.gen.setObject(3, -2, { frame: 'chest_closed', blocks: true, kind: 'chest' });
      this.gen.setObject(-3, -2, { frame: 'bed_green', blocks: true, kind: 'bed' });
      this.gen.setObject(-1, -5, { frame: 'bin_closed', blocks: true, kind: 'bin' });
      this.state.container('3,-2', 27, [['wood', 12], ['stone', 8], ['apple', 3]]);
    }
    services.state = this.state;
    this.state.seed = this.seed;
    this.social = services.social = new Social(this.state, npcDefs, questDefs);
    const clock = this.state.clock;
    this.state.weather = weatherFor(this.seed, clock.day, clock.season);

    this.chunks = new ChunkManager(this, this.gen, this.farm);

    // Animated water: 4 tile sprites (one per frame), only one visible. Land tiles have transparent
    // edges, so the water shows through along shores. One draw call, no per-tile animation cost.
    this.waterFrame = 0;
    this.water = [0, 1, 2, 3].map((i) =>
      this.add.tileSprite(0, 0, 64, 64, 'water', i).setOrigin(0, 0).setDepth(-2e9).setVisible(i === 0));
    this.time.addEvent({
      delay: 350, loop: true,
      callback: () => {
        this.waterFrame = (this.waterFrame + 1) % 4;
        this.water.forEach((t, i) => t.setVisible(i === this.waterFrame));
      },
    });

    const spawn = load && load.meta.px != null ? { x: load.meta.px, y: load.meta.py } : this.findSpawn();
    this.player = new Player(this, this.chunks, services.input, spawn.x, spawn.y);
    this.player.setPosition(spawn.x, spawn.y);

    this.drops = new DropManager(this, this.state, this.player);
    this.interaction = new InteractionSystem(this, {
      chunks: this.chunks, gen: this.gen, farm: this.farm, state: this.state, player: this.player,
      drops: this.drops, input: services.input, mouse: services.mouse,
    }, objectDefs, cropDefs);

    this.npcs = new NpcManager(this, { gen: this.gen, chunks: this.chunks, state: this.state, seed: this.seed, npcDefs, events: eventDefs });
    this.fishing = new FishingSystem(this, {
      gen: this.gen, state: this.state, player: this.player, interaction: this.interaction, input: services.input,
      social: this.social, drops: this.drops, fishDefs,
    });
    this.interaction.npcs = this.npcs;
    this.interaction.fishing = this.fishing;

    const cam = this.cameras.main;
    cam.setBackgroundColor('#1b2a1f');
    cam.roundPixels = true;
    this.applyZoom();
    this.chunks.loadAllAround(this.player.x, this.player.y);
    cam.startFollow(this.player.sprite, true, 0.2, 0.2, 0, 8);
    cam.centerOn(this.player.x, this.player.y - 8);

    // ---- saving ----
    this.sleeping = false;
    this.autoTimer = 0;
    this.saveChain = Promise.resolve();
    this.seen = { prog: this.state.progressVersion, inv: this.state.inventory.version, farm: this.farm.version, mods: this.gen.modVersion, cont: this.state.containerVersion() };
    if (!load) this.save.mark(...RECORDS);   // new game: write everything once

    this.handlers = {
      'game:sleep': (passedOut) => this.startSleep(passedOut),
      'game:save': () => this.saveNow(true).then(() => bus.emit('ui:toast', 'Game saved')),
      'game:export': () => this.exportSave(),
      'game:import': () => this.importSave(),
      'game:quit': () => this.quitToTitle(),
    };
    for (const [ev, fn] of Object.entries(this.handlers)) bus.on(ev, fn);
    this.onHidden = () => { if (document.hidden) this.saveNow(); };
    document.addEventListener('visibilitychange', this.onHidden);
    window.addEventListener('pagehide', this.onHidden);

    this.scale.on('resize', this.applyZoom, this);
    this.events.once('shutdown', () => {
      for (const [ev, fn] of Object.entries(this.handlers)) bus.off(ev, fn);
      document.removeEventListener('visibilitychange', this.onHidden);
      window.removeEventListener('pagehide', this.onHidden);
      this.scale.off('resize', this.applyZoom, this);
      this.fishing.destroy();
      this.scene.stop('UI');
    });

    this.scene.launch('UI');
    if (!load) this.saveNow(true);
  }

  /** Integer zoom only (pixel-perfect). About 200 world pixels tall: 2x on phones, 5x on 1080p. */
  applyZoom() {
    const cam = this.cameras.main;
    const zoom = Math.max(2, Math.round(this.scale.height / 200));
    cam.setZoom(zoom);
    const viewW = this.scale.width / zoom;
    const viewH = this.scale.height / zoom;
    this.chunks.setView(viewW, viewH);
    const w = Math.ceil(viewW / TILE) * TILE + TILE * 4;
    const h = Math.ceil(viewH / TILE) * TILE + TILE * 4;
    this.water.forEach((t) => t.setSize(w, h));
    if (this.player) this.chunks.update(this.player.x, this.player.y, Infinity);
  }

  findSpawn() {
    for (let r = 0; r < 12; r++) {
      for (let dy = -r; dy <= r; dy++) {
        for (let dx = -r; dx <= r; dx++) {
          if (!this.gen.isBlockedAt(dx, dy)) return { x: dx * TILE + TILE / 2, y: dy * TILE + TILE - 2 };
        }
      }
    }
    return { x: 8, y: 14 };
  }

  // ---- day cycle ---------------------------------------------------------------------------

  startSleep(passedOut) {
    if (this.sleeping) return;
    this.sleeping = true;
    this.player.frozen = true;
    this.interaction.frozen = true;
    const cam = this.cameras.main;
    cam.fadeOut(600, 0, 0, 0);
    cam.once('camerafadeoutcomplete', () => {
      this.shipBin();
      this.advanceDay();
      if (passedOut) bus.emit('ui:toast', 'You passed out...');
      this.saveNow(true);
      cam.fadeIn(700, 0, 0, 0);
      cam.once('camerafadeincomplete', () => {
        this.sleeping = false;
        this.player.frozen = false;
        this.interaction.frozen = false;
        const c = this.state.clock;
        bus.emit('ui:toast', c.dateString() + ' - ' + this.state.weather);
      });
    });
  }

  /** The shipping bin is emptied and paid out every night, at that day's market prices. */
  shipBin() {
    const bin = this.state.container('bin', 9);
    let total = 0, n = 0;
    for (const st of bin.slots) {
      if (!st) continue;
      total += sellPrice(ItemDB.get(st.id), st.q || 0, this.seed, this.state.clock.day) * st.count;
      n += st.count;
    }
    if (!n) return;
    bin.slots.fill(null);
    bin.version++;
    this.state.gold += total;
    bus.emit('ui:toast', 'Shipped ' + n + ' item(s): +' + total + ' gold');
  }

  advanceDay() {
    const c = this.state.clock;
    c.nextDay();
    this.state.weather = weatherFor(this.seed, c.day, c.season);
    const res = this.farm.advanceDay(c.season, this.state.weather === 'rain');
    for (const k of res.changed) {
      const [x, y] = k.split(',').map(Number);
      this.chunks.refreshFarm(x, y);
    }
    if (res.withered > 0) bus.emit('ui:toast', res.withered + ' crop(s) withered in the ' + c.season + ' weather');
    if (this.state.weather === 'rain') bus.emit('ui:toast', 'It is raining - crops are watered');
    this.npcs.resetDay();
    const fest = festivalToday(eventDefs, c);
    if (fest) bus.emit('ui:toast', fest.name + ' today! Gather at the village, ' + fest.from + ':00-' + fest.to + ':00 (shop discount)');
  }

  // ---- saving ------------------------------------------------------------------------------

  records() {
    const s = this.state, c = s.clock;
    return {
      meta: () => ({ v: 1, seed: this.seed, gold: s.gold, day: c.day, minutes: Math.floor(c.minutes), selected: s.selected, water: s.water, px: this.player.x, py: this.player.y }),
      inventory: () => s.inventory.toJSON(),
      containers: () => [...s.containers].map(([k, inv]) => [k, inv.toJSON()]),
      mods: () => this.gen.exportMods(),
      farm: () => this.farm.toJSON(),
      progress: () => ({ npc: s.npc, quests: s.quests, stats: s.stats }),
    };
  }

  trackDirty() {
    const s = this.state, seen = this.seen;
    if (s.inventory.version !== seen.inv) { seen.inv = s.inventory.version; this.save.mark('inventory'); }
    const cv = s.containerVersion();
    if (cv !== seen.cont) { seen.cont = cv; this.save.mark('containers'); }
    if (s.progressVersion !== seen.prog) { seen.prog = s.progressVersion; this.save.mark('progress'); }
    if (this.farm.version !== seen.farm) { seen.farm = this.farm.version; this.save.mark('farm'); }
    if (this.gen.modVersion !== seen.mods) { seen.mods = this.gen.modVersion; this.save.mark('mods'); }
  }

  /** Writes only changed records (all=true writes everything). Writes are queued so they never overlap. */
  saveNow(all = false) {
    this.trackDirty();
    this.save.mark('meta');
    const build = this.records();
    this.saveChain = this.saveChain.then(() => this.save.flush(build, all)).catch(() => {});
    return this.saveChain;
  }

  async exportSave() {
    await this.saveNow(true);
    const text = await this.save.exportText();
    let copied = false;
    try { await navigator.clipboard.writeText(text); copied = true; } catch (e) { /* not allowed here */ }
    try {
      const a = document.createElement('a');
      a.href = URL.createObjectURL(new Blob([text], { type: 'application/json' }));
      a.download = 'pixelfarm-save.json';
      document.body.appendChild(a);
      a.click();
      a.remove();
      setTimeout(() => URL.revokeObjectURL(a.href), 4000);
    } catch (e) { /* download blocked */ }
    bus.emit('ui:toast', copied ? 'Save copied to clipboard and downloaded' : 'Save file downloaded');
  }

  importSave() {
    const input = document.createElement('input');
    input.type = 'file';
    input.accept = '.json,application/json,text/plain';
    input.onchange = async () => {
      const file = input.files && input.files[0];
      if (!file) return;
      const ok = await this.save.importText(await file.text());
      if (!ok) { bus.emit('ui:toast', 'That is not a valid Pixel Farm save'); return; }
      this.scene.restart({ load: await this.save.load() });
    };
    input.click();
  }

  async quitToTitle() {
    await this.saveNow(true);
    this.scene.start('MainMenu');
  }

  // ---- frame -------------------------------------------------------------------------------

  update(time, delta) {
    const dt = Math.min(delta, 50) / 1000;
    this.player.update(dt);
    this.interaction.update(dt);
    this.drops.update(dt);
    this.npcs.update(dt, this.player);
    this.fishing.update(dt);
    this.chunks.update(this.player.x, this.player.y);

    // Time only passes while no menu is open.
    if (!services.input.blocked && !this.sleeping) {
      if (this.state.clock.tick(dt)) this.startSleep(true);
    }

    this.autoTimer += dt;
    if (this.autoTimer >= AUTOSAVE_SECONDS) { this.autoTimer = 0; this.saveNow(); }

    const wv = this.cameras.main.worldView;
    const x0 = Math.floor(wv.x / TILE) * TILE - TILE * 2;
    const y0 = Math.floor(wv.y / TILE) * TILE - TILE * 2;
    for (const t of this.water) t.setPosition(x0, y0);

    const d = services.debug;
    d.pos = Math.floor(this.player.x / TILE) + ',' + Math.floor(this.player.y / TILE);
    d.chunks = this.chunks.count;
  }
}
