import Phaser from 'phaser';

export class PreloadScene extends Phaser.Scene {
  constructor() { super('Preload'); }

  preload() {
    const { width, height } = this.scale;
    const bar = this.add.graphics();
    const label = this.add.text(width / 2, height / 2 - 24, 'Loading...', {
      fontFamily: 'monospace', fontSize: '18px', color: '#e8f5c8',
    }).setOrigin(0.5);
    this.load.on('progress', (p) => {
      bar.clear();
      bar.fillStyle(0x2d4a36, 1).fillRect(width / 2 - 100, height / 2, 200, 10);
      bar.fillStyle(0xb8d86a, 1).fillRect(width / 2 - 100, height / 2, 200 * p, 10);
    });
    this.load.on('complete', () => { bar.destroy(); label.destroy(); });

    this.load.image('grass', 'assets/grass.png');
    this.load.image('farm', 'assets/farm.png');
    this.load.spritesheet('water', 'assets/water.png', { frameWidth: 16, frameHeight: 16 });
    this.load.spritesheet('player', 'assets/player.png', { frameWidth: 48, frameHeight: 48 });
    this.load.spritesheet('actions', 'assets/actions.png', { frameWidth: 48, frameHeight: 48 });
    this.load.atlas('items', 'assets/items.png', 'assets/items.json');
    this.load.atlas('objects', 'assets/objects.png', 'assets/objects.json');
  }

  create() {
    this.scene.start('MainMenu');
  }
}
