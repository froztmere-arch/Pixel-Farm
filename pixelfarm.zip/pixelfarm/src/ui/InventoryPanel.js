import { ItemDB } from '../core/ItemDB.js';
import { HOTBAR_SIZE } from '../core/GameState.js';

const COLS = 9;
const clamp = (v, a, b) => Math.max(a, Math.min(b, v));

/**
 * Backpack screen (and chest screen: pass `other` = {inv, title, onClose}).
 * Two-tap moving works with finger or mouse: tap a stack, tap where it should go
 * (empty slot = move, same item = merge, other item = swap). Tap the same slot again to cancel.
 */
export class InventoryPanel {
  constructor(scene, state) {
    this.scene = scene;
    this.state = state;
    this.open = false;
    this.other = null;
    this.sel = null;
    this.info = null;
    this.objs = [];
    this.slots = [];
    this.versions = [-1, -1];
  }

  toggle() { this.open ? this.hide() : this.show(); }

  show(other = null) {
    if (this.open) this.hide();
    this.open = true;
    this.other = other;
    this.sel = null;
    this.info = null;
    this.build();
  }

  hide() {
    if (!this.open) return;
    this.open = false;
    for (const o of this.objs) o.destroy();
    this.objs = [];
    this.slots = [];
    const other = this.other;
    this.other = null;
    if (other && other.onClose) other.onClose();
  }

  add(o) { this.objs.push(o); return o; }

  build() {
    for (const o of this.objs) o.destroy();
    this.objs = [];
    this.slots = [];
    const scene = this.scene;
    const { width: W, height: H } = scene.scale;
    const other = this.other;
    const main = this.state.inventory;

    const fs = Math.round(clamp(Math.min(W, H) * 0.04, 11, 18));
    const lineH = fs + 6, pad = 8, gap = other ? 6 : 0;
    const rowsMain = Math.ceil(main.size / COLS);
    const rowsOther = other ? Math.ceil(other.inv.size / COLS) : 0;
    const totalRows = rowsMain + rowsOther;
    const fixed = pad * 2 + lineH * (other ? 2 : 1) + lineH + gap;
    let cell = Math.min(16 * clamp(Math.round(Math.min(W, H) / 170), 2, 5) + 10,
      Math.floor((H - fixed) / totalRows), Math.floor((W - pad * 2) / COLS));
    cell = Math.max(cell, 20);
    const iconScale = Math.max(1, Math.floor((cell - 6) / 16));
    this.cell = cell;
    this.iconScale = iconScale;

    const panelW = COLS * cell + pad * 2;
    const panelH = totalRows * cell + fixed;
    const x0 = Math.round((W - panelW) / 2), y0 = Math.round((H - panelH) / 2);
    this.layoutInfo = { x0, y0, panelW, panelH, fs, lineH, pad };

    // dimmer: swallows taps; tapping it deselects, or closes when nothing is selected
    const dim = this.add(scene.add.rectangle(W / 2, H / 2, W, H, 0x000000, 0.55).setDepth(2000).setInteractive());
    dim.on('pointerdown', () => { if (this.sel) { this.sel = null; this.render(); } else this.hide(); });
    this.add(scene.add.rectangle(x0 + panelW / 2, y0 + panelH / 2, panelW, panelH, 0x241a10, 0.97)
      .setStrokeStyle(2, 0x8a6a3b, 1).setDepth(2001).setInteractive());

    this.g = this.add(scene.add.graphics().setDepth(2002));
    this.g2 = this.add(scene.add.graphics().setDepth(2004)); // quality markers above icons
    const style = { fontFamily: 'monospace', fontSize: fs + 'px', color: '#f3e3b8' };
    let y = y0 + pad;
    const gx = x0 + pad;

    const addGrid = (inv, rows, which) => {
      for (let r = 0; r < rows; r++) {
        for (let c = 0; c < COLS; c++) {
          const idx = r * COLS + c;
          if (idx >= inv.size) break;
          this.slots.push({ inv, idx, which, x: gx + c * cell, y: y + r * cell, hot: which === 1 && idx < HOTBAR_SIZE });
        }
      }
      y += rows * cell;
    };

    if (other) {
      this.add(scene.add.text(gx, y, other.title || 'Chest', style).setDepth(2003));
      y += lineH;
      addGrid(other.inv, rowsOther, 0);
      y += gap;
    }
    this.add(scene.add.text(gx, y, 'Backpack', style).setDepth(2003));
    const mk = (label, fn, right) => {
      const t = this.add(scene.add.text(0, y - 1, label, {
        fontFamily: 'monospace', fontStyle: 'bold', fontSize: fs + 'px', color: '#ffffff',
        backgroundColor: '#4a6a3a', padding: { x: 6, y: 2 },
      }).setDepth(2004).setInteractive({ useHandCursor: true }));
      t.setPosition(x0 + panelW - pad - right - t.width, y - 1);
      t.on('pointerdown', fn);
      return t;
    };
    const closeBtn = mk('Close', () => this.hide(), 0);
    mk('Sort', () => { main.sort(HOTBAR_SIZE); this.sel = null; this.render(); }, closeBtn.width + 8);
    y += lineH;
    addGrid(main, rowsMain, 1);

    this.footer = this.add(scene.add.text(gx, y + 2, '', {
      fontFamily: 'monospace', fontSize: fs + 'px', color: '#ffe9a8',
    }).setDepth(2003));

    // icons + counts + tap zones, one set per slot
    for (const sl of this.slots) {
      sl.icon = this.add(scene.add.image(sl.x + cell / 2, sl.y + cell / 2, 'items').setScale(iconScale).setDepth(2003).setVisible(false));
      sl.count = this.add(scene.add.text(sl.x + cell - 3, sl.y + cell - 2, '', {
        fontFamily: 'monospace', fontStyle: 'bold', fontSize: Math.round(2.6 * iconScale + 7) + 'px',
        color: '#ffffff', stroke: '#000000', strokeThickness: 3,
      }).setOrigin(1, 1).setDepth(2004));
      const z = this.add(scene.add.zone(sl.x, sl.y, cell, cell).setOrigin(0, 0).setInteractive().setDepth(2005));
      z.on('pointerdown', () => this.tap(sl));
    }
    this.render();
  }

  tap(sl) {
    const st = sl.inv.slots[sl.idx];
    if (!this.sel) {
      if (st) { this.sel = sl; this.info = st.id; }
    } else if (this.sel === sl) {
      this.sel = null;
    } else {
      const from = this.sel;
      from.inv.move(from.idx, sl.inv, sl.idx);
      this.sel = null;
      const now = sl.inv.slots[sl.idx];
      this.info = now ? now.id : null;
    }
    this.render();
  }

  render() {
    if (!this.open) return;
    const g = this.g, c = this.cell;
    g.clear();
    this.g2.clear();
    for (const sl of this.slots) {
      const st = sl.inv.slots[sl.idx];
      const isSel = this.sel === sl;
      const equipped = sl.hot && sl.idx === this.state.selected;
      g.fillStyle(sl.hot ? 0x3a2b18 : 0x2e2114, 1).fillRect(sl.x + 1, sl.y + 1, c - 2, c - 2);
      g.lineStyle(isSel ? 3 : 2, isSel ? 0xffe066 : equipped ? 0x9be36b : 0x6a5130, 1).strokeRect(sl.x + 1, sl.y + 1, c - 2, c - 2);
      if (st) {
        sl.icon.setFrame(ItemDB.get(st.id).icon).setVisible(true);
        sl.count.setText(st.count > 1 ? String(st.count) : '');
        if (st.q) this.g2.fillStyle(st.q === 2 ? 0xffd24a : 0xcfd8e6, 1).fillRect(sl.x + 4, sl.y + 4, 3 * this.iconScale, 3 * this.iconScale)
          .lineStyle(1, 0x000000, 0.7).strokeRect(sl.x + 4, sl.y + 4, 3 * this.iconScale, 3 * this.iconScale);
      } else {
        sl.icon.setVisible(false);
        sl.count.setText('');
      }
    }
    const id = this.sel ? this.sel.inv.slots[this.sel.idx].id : this.info;
    if (id && ItemDB.has(id)) {
      const it = ItemDB.get(id);
      const q = this.sel ? this.sel.inv.slots[this.sel.idx].q : 0;
      this.footer.setText(it.name + (q ? ' (' + (q === 2 ? 'Gold' : 'Silver') + ')' : '') + ' - ' + (it.desc || ''));
    } else {
      this.footer.setText(this.sel ? '' : 'Tap a stack, then tap where to put it');
    }
    this.versions = [this.other ? this.other.inv.version : 0, this.state.inventory.version];
  }

  /** Redraws if the inventory changed underneath (e.g. a pickup while open). */
  update() {
    if (!this.open) return;
    const v = [this.other ? this.other.inv.version : 0, this.state.inventory.version];
    if (v[0] !== this.versions[0] || v[1] !== this.versions[1]) this.render();
  }
}
