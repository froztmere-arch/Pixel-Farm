/** Small Yes / No box. show(text, onYes). */
export class ConfirmDialog {
  constructor(scene) {
    this.scene = scene;
    this.open = false;
    this.objs = [];
  }

  show(text, onYes) {
    this.hide();
    this.open = true;
    const sc = this.scene;
    const { width: W, height: H } = sc.scale;
    const fs = Math.round(Math.max(14, Math.min(26, Math.min(W, H) * 0.05)));
    const w = Math.min(W * 0.8, fs * 22), h = fs * 6.5;
    const add = (o) => { this.objs.push(o); return o; };
    add(sc.add.rectangle(W / 2, H / 2, W, H, 0x000000, 0.55).setDepth(2400).setInteractive());
    add(sc.add.rectangle(W / 2, H / 2, w, h, 0x241a10, 0.98).setStrokeStyle(2, 0x8a6a3b, 1).setDepth(2401));
    add(sc.add.text(W / 2, H / 2 - h * 0.22, text, {
      fontFamily: 'monospace', fontSize: fs + 'px', color: '#f3e3b8', align: 'center', wordWrap: { width: w - fs * 2 },
    }).setOrigin(0.5).setDepth(2402));
    const btn = (label, dx, color, fn) => {
      const t = add(sc.add.text(W / 2 + dx, H / 2 + h * 0.25, label, {
        fontFamily: 'monospace', fontStyle: 'bold', fontSize: fs + 'px', color: '#ffffff',
        backgroundColor: color, padding: { x: fs, y: fs * 0.4 },
      }).setOrigin(0.5).setDepth(2402).setInteractive({ useHandCursor: true }));
      t.on('pointerdown', fn);
    };
    btn('Yes', -fs * 3.5, '#4a6a3a', () => { this.hide(); onYes(); });
    btn('No', fs * 3.5, '#6a3a3a', () => this.hide());
  }

  hide() {
    for (const o of this.objs) o.destroy();
    this.objs = [];
    this.open = false;
  }
}
