import { bus } from '../core/services.js';

const MODES = ['auto', 'touch', 'keyboard'];
const MODE_LABEL = { auto: 'Auto', touch: 'Touch', keyboard: 'Keyboard' };

/** Pause/settings menu, drawn in the UI scene. Pointer-driven (mouse or finger). */
export class SettingsPanel {
  constructor(scene, settings, hooks) {
    this.scene = scene;
    this.settings = settings;
    this.hooks = hooks; // { onEditLayout }
    this.open = false;
    this.items = [];
  }

  toggle() { this.open ? this.close() : this.show(); }

  show() {
    this.open = true;
    this.build();
  }

  close() {
    this.open = false;
    this.clear();
  }

  clear() {
    for (const o of this.items) o.destroy();
    this.items = [];
  }

  build() {
    this.clear();
    const { width: W, height: H } = this.scene.scale;
    const fs = Math.round(Math.max(14, Math.min(28, Math.min(W, H) * 0.052)));
    const rowH = Math.round(fs * 2.1);
    const mode = this.settings.get('controlMode');
    const rows = [
      ['Resume', () => this.close()],
      ['Journal', () => { this.close(); bus.emit('ui:openJournal'); }],
      ['Save game', () => { this.close(); bus.emit('game:save'); }],
      ['Export save', () => { this.close(); bus.emit('game:export'); }],
      ['Import save', () => { this.close(); bus.emit('game:import'); }],
      ['Controls: ' + MODE_LABEL[mode], () => {
        this.settings.set('controlMode', MODES[(MODES.indexOf(mode) + 1) % MODES.length]);
        this.build();
      }],
      ['Edit touch layout', () => { this.close(); this.hooks.onEditLayout(); }],
      ['Reset touch layout', () => { this.settings.resetLayout(); }],
      ['Debug overlay: ' + (this.settings.get('showDebug') ? 'On' : 'Off'), () => {
        this.settings.set('showDebug', !this.settings.get('showDebug'));
        this.build();
      }],
      ['Save and quit to title', () => { this.close(); bus.emit('game:quit'); }],
    ];

    const colW = Math.min(fs * 15, (W - fs * 2) / 2 - 6);
    const cols = W >= colW * 2 + fs * 3 && rows.length > 5 ? 2 : 1;
    const perCol = Math.ceil(rows.length / cols);
    const panelW = cols * colW + (cols + 1) * 6 + fs;
    const panelH = perCol * rowH + fs * 3.2;
    const cx = W / 2, top = (H - panelH) / 2;
    const add = (o) => { this.items.push(o); return o; };

    // Full-screen dimmer swallows taps so nothing leaks to the controls underneath.
    add(this.scene.add.rectangle(W / 2, H / 2, W, H, 0x000000, 0.5).setDepth(2000).setInteractive());
    add(this.scene.add.rectangle(cx, H / 2, panelW, panelH, 0x14201a, 0.96)
      .setStrokeStyle(2, 0xffffff, 0.4).setDepth(2001));
    add(this.scene.add.text(cx, top + fs * 0.6, 'MENU', {
      fontFamily: 'monospace', fontStyle: 'bold', fontSize: fs + 'px', color: '#e8f5c8',
    }).setOrigin(0.5, 0).setDepth(2002));

    rows.forEach(([label, fn], i) => {
      const col = Math.floor(i / perCol), r = i % perCol;
      const x = cx - panelW / 2 + fs / 2 + 6 + col * (colW + 6) + colW / 2;
      const y = top + fs * 2.5 + r * rowH + rowH / 2;
      const bg = add(this.scene.add.rectangle(x, y, colW, rowH - 6, 0x2d4a36, 1)
        .setDepth(2002).setInteractive({ useHandCursor: true }));
      bg.on('pointerover', () => bg.setFillStyle(0x3d6648));
      bg.on('pointerout', () => bg.setFillStyle(0x2d4a36));
      bg.on('pointerdown', fn);
      add(this.scene.add.text(x, y, label, {
        fontFamily: 'monospace', fontSize: Math.round(fs * 0.8) + 'px', color: '#ffffff',
      }).setOrigin(0.5).setDepth(2003));
    });
  }
}
