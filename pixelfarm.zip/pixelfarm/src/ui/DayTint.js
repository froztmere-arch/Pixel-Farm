import Phaser from 'phaser';

// [minute of day, colour]. The screen is multiplied by this colour (white = no change).
const KEYS = [
  [360, 0x7078b0], [450, 0xffd8b0], [540, 0xffffff], [1020, 0xffffff],
  [1140, 0xffb480], [1230, 0x6c72a8], [1320, 0x464e84], [1560, 0x343a70],
];
const WEATHER = { sunny: 0xffffff, rain: 0xb4bccc, snow: 0xd8dcee };

const lerp = (a, b, t) => Math.round(a + (b - a) * t);
function mix(c1, c2, t) {
  return (lerp(c1 >> 16, c2 >> 16, t) << 16) | (lerp((c1 >> 8) & 255, (c2 >> 8) & 255, t) << 8) | lerp(c1 & 255, c2 & 255, t);
}
function mul(c1, c2) {
  return (((c1 >> 16) * (c2 >> 16) / 255) << 16) | ((((c1 >> 8) & 255) * ((c2 >> 8) & 255) / 255) << 8) | (((c1 & 255) * (c2 & 255) / 255) | 0);
}

export function tintFor(minutes, weather) {
  let c = KEYS[KEYS.length - 1][1];
  if (minutes <= KEYS[0][0]) c = KEYS[0][1];
  else {
    for (let i = 1; i < KEYS.length; i++) {
      if (minutes <= KEYS[i][0]) {
        const [m0, c0] = KEYS[i - 1], [m1, c1] = KEYS[i];
        c = mix(c0, c1, (minutes - m0) / (m1 - m0));
        break;
      }
    }
  }
  return mul(c, WEATHER[weather] || 0xffffff) >>> 0;
}

/**
 * Time-of-day + weather tint: one full-screen multiply rectangle (cheap, no shaders).
 * The AtmosphereManager of Phase 7 will take this over and blend moods on top of it.
 */
export class DayTint {
  constructor(scene) {
    this.rect = scene.add.rectangle(0, 0, 10, 10, 0xffffff, 1)
      .setOrigin(0, 0).setDepth(100).setBlendMode(Phaser.BlendModes.MULTIPLY).setVisible(false);
    this.last = -1;
  }

  layout(W, H) { this.rect.setSize(W, H); }

  update(clock, weather) {
    const c = tintFor(clock.minutes, weather);
    if (c === this.last) return;
    this.last = c;
    this.rect.setFillStyle(c, 1).setVisible(c !== 0xffffff);
  }
}
