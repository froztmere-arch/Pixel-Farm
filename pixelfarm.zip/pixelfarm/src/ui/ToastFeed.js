import { ItemDB } from '../core/ItemDB.js';

const QUALITY = ['', 'Silver', 'Gold'];
const MAX = 5;
const LIFE = 2.4;
const FADE_AT = 1.7;

/** Small message list on the left: "+3 Wood", "You need an axe for that". Pooled text objects. */
export class ToastFeed {
  constructor(scene) {
    this.scene = scene;
    this.lines = [];  // newest last
    this.pool = [];
    this.x = 10;
    this.y = 80;
    this.size = 14;
  }

  layout(W, H) {
    this.x = 10;
    this.y = Math.round(H * 0.2);
    this.size = Math.round(Math.max(12, Math.min(18, Math.min(W, H) * 0.04)));
  }

  acquire() {
    const t = this.pool.pop() || this.scene.add.text(0, 0, '', {
      fontFamily: 'monospace', fontStyle: 'bold', fontSize: '14px', color: '#fff6d0', stroke: '#000000', strokeThickness: 3,
    }).setDepth(1500);
    return t.setVisible(true).setAlpha(1);
  }

  pickup(id, n, q = 0) {
    const key = id + '|' + q;
    const name = ItemDB.get(id).name + (q ? ' (' + QUALITY[q] + ')' : '');
    const last = this.lines[this.lines.length - 1];
    if (last && last.key === key && last.age < 1) {
      last.n += n;
      last.age = 0;
      last.text.setText('+' + last.n + ' ' + name).setAlpha(1);
      return;
    }
    this.push('+' + n + ' ' + name, key, n);
  }

  message(text) { this.push(text, null, 0); }

  push(label, key, n) {
    if (this.lines.length >= MAX) this.drop(0);
    const text = this.acquire().setText(label);
    this.lines.push({ text, key, n, age: 0 });
  }

  drop(i) {
    const l = this.lines[i];
    l.text.setVisible(false);
    this.pool.push(l.text);
    this.lines.splice(i, 1);
  }

  update(dt) {
    for (let i = this.lines.length - 1; i >= 0; i--) {
      const l = this.lines[i];
      l.age += dt;
      if (l.age >= LIFE) { this.drop(i); continue; }
      l.text.setAlpha(l.age > FADE_AT ? 1 - (l.age - FADE_AT) / (LIFE - FADE_AT) : 1);
    }
    this.lines.forEach((l, i) => {
      l.text.setFontSize(this.size);
      l.text.setPosition(this.x, this.y + i * (this.size + 6));
    });
  }
}
