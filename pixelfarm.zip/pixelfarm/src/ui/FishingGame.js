import { bus, services } from '../core/services.js';
import { FishingBar } from '../core/Fishing.js';

const clamp = (v, a, b) => Math.max(a, Math.min(b, v));

/** The reeling bar. Hold USE (touch), Space / E / left click (desktop) to lift the green bar over the fish. */
export class FishingGame {
  constructor(scene) {
    this.scene = scene;
    this.active = false;
    this.bar = null;
    this.objs = [];
    this.onStart = (d) => this.start(d);
    bus.on('fishing:start', this.onStart);
  }

  destroy() {
    bus.off('fishing:start', this.onStart);
    this.clear();
  }

  start({ def, icon }) {
    this.clear();
    this.bar = new FishingBar(def.difficulty);
    this.active = true;
    const sc = this.scene;
    const { width: W, height: H } = sc.scale;
    this.h = Math.round(Math.min(H * 0.66, 300));
    this.w = 28;
    this.x = W - 80;
    this.y = Math.round((H - this.h) / 2);
    const add = (o) => { this.objs.push(o); return o; };
    add(sc.add.rectangle(this.x + this.w / 2, this.y + this.h / 2, this.w + 8, this.h + 8, 0x1a1208, 0.92).setStrokeStyle(2, 0x8a6a3b, 1).setDepth(2500));
    this.catchGfx = add(sc.add.rectangle(0, 0, this.w, 10, 0x6ad04a, 0.85).setOrigin(0.5, 0).setDepth(2501));
    this.fishImg = add(sc.add.image(0, 0, 'items', icon).setScale(1.5).setDepth(2502));
    add(sc.add.rectangle(this.x - 18, this.y + this.h / 2, 10, this.h + 8, 0x1a1208, 0.92).setStrokeStyle(2, 0x8a6a3b, 1).setDepth(2500));
    this.progGfx = add(sc.add.rectangle(this.x - 18, this.y + this.h + 4, 6, 1, 0xffd24a, 1).setOrigin(0.5, 1).setDepth(2501));
    add(sc.add.text(this.x + this.w / 2, this.y - 22, 'Hold USE to reel!', {
      fontFamily: 'monospace', fontStyle: 'bold', fontSize: '13px', color: '#fff6d0', stroke: '#000000', strokeThickness: 3,
    }).setOrigin(0.5).setDepth(2502));
    this.draw();
  }

  clear() {
    for (const o of this.objs) o.destroy();
    this.objs = [];
    this.active = false;
  }

  draw() {
    const b = this.bar;
    const barH = b.size * this.h;
    this.catchGfx.setSize(this.w, barH);
    this.catchGfx.setPosition(this.x + this.w / 2, this.y + this.h - (b.bar + b.size) * this.h);
    this.catchGfx.setFillStyle(b.inside ? 0x6ad04a : 0xd0a04a, 0.85);
    this.fishImg.setPosition(this.x + this.w / 2, this.y + this.h - b.fish * this.h);
    this.progGfx.setSize(6, Math.max(1, b.progress * this.h));
  }

  update(dt) {
    if (!this.active) return;
    const input = services.input;
    this.bar.update(Math.min(dt, 0.05), input.isDown('tool') || input.isDown('interact'));
    this.draw();
    if (this.bar.result) {
      const res = { win: this.bar.result === 'win', perfect: this.bar.perfect };
      this.clear();
      bus.emit('fishing:result', res);
    }
  }
}
