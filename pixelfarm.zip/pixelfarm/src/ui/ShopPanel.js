import { bus, services } from '../core/services.js';
import { ItemDB } from '../core/ItemDB.js';
import { buyPrice, sellPrice, shopStock, festivalToday } from '../core/Economy.js';
import shops from '../data/shops.json';
import crops from '../data/crops.json';
import events from '../data/events.json';

const clamp = (v, a, b) => Math.max(a, Math.min(b, v));
const QUALITY = ['', ' (Silver)', ' (Gold)'];

/** Buy / Sell screen. Stock and prices change every day (Economy.js). */
export class ShopPanel {
  constructor(scene) {
    this.scene = scene;
    this.open = false;
    this.objs = [];
    this.tab = 'buy';
    this.page = 0;
  }

  show(shopId) {
    this.shop = shops[shopId];
    this.tab = 'buy';
    this.page = 0;
    this.open = true;
    this.build();
  }

  close() {
    for (const o of this.objs) o.destroy();
    this.objs = [];
    this.open = false;
  }

  rows() {
    const st = services.state, c = st.clock;
    const fest = festivalToday(events, c);
    if (this.tab === 'buy') {
      return shopStock(this.shop, st.seed, c.day).map((id) => {
        const item = ItemDB.get(id);
        return { id, q: 0, price: buyPrice(id, item, st.seed, c.day, c.season, crops, fest), kind: 'buy' };
      });
    }
    const out = [];
    st.inventory.slots.forEach((s, slot) => {
      if (!s) return;
      const item = ItemDB.get(s.id);
      const price = sellPrice(item, s.q || 0, st.seed, c.day);
      if (price > 0) out.push({ id: s.id, q: s.q || 0, price, kind: 'sell', slot, count: s.count });
    });
    return out;
  }

  buy(row, n) {
    const st = services.state;
    const item = ItemDB.get(row.id);
    const max = item.type === 'tool' ? 1 : n;
    let bought = 0;
    for (let i = 0; i < max; i++) {
      if (st.gold < row.price) { bus.emit('ui:toast', 'Not enough gold'); break; }
      if (!st.inventory.canAdd(row.id, 1)) { bus.emit('ui:toast', 'Backpack is full'); break; }
      st.inventory.add(row.id, 1);
      st.gold -= row.price;
      bought++;
    }
    if (bought) bus.emit('ui:toast', 'Bought ' + bought + ' ' + item.name);
    this.build();
  }

  sell(row, all) {
    const st = services.state;
    const stack = st.inventory.slots[row.slot];
    if (!stack || stack.id !== row.id) { this.build(); return; }
    const n = all ? stack.count : 1;
    st.inventory.removeAt(row.slot, n);
    st.gold += row.price * n;
    bus.emit('ui:toast', 'Sold ' + n + ' ' + ItemDB.get(row.id).name + ': +' + row.price * n + ' gold');
    this.build();
  }

  build() {
    for (const o of this.objs) o.destroy();
    this.objs = [];
    const sc = this.scene, st = services.state;
    const { width: W, height: H } = sc.scale;
    const fs = Math.round(clamp(Math.min(W, H) * 0.045, 12, 22));
    const pw = Math.min(W * 0.96, fs * 40), ph = H * 0.94;
    const x0 = (W - pw) / 2, y0 = (H - ph) / 2, pad = Math.round(fs * 0.6);
    const add = (o) => { this.objs.push(o); return o; };
    const button = (label, x, y, color, fn, depth = 2203) => {
      const t = add(sc.add.text(x, y, label, {
        fontFamily: 'monospace', fontStyle: 'bold', fontSize: Math.round(fs * 0.9) + 'px', color: '#ffffff',
        backgroundColor: color, padding: { x: fs * 0.5, y: fs * 0.25 },
      }).setDepth(depth).setInteractive({ useHandCursor: true }));
      t.on('pointerdown', fn);
      return t;
    };

    add(sc.add.rectangle(W / 2, H / 2, W, H, 0x000000, 0.55).setDepth(2200).setInteractive());
    add(sc.add.rectangle(W / 2, H / 2, pw, ph, 0x241a10, 0.98).setStrokeStyle(2, 0x8a6a3b, 1).setDepth(2201));
    add(sc.add.text(x0 + pad, y0 + pad * 0.7, this.shop.name, { fontFamily: 'monospace', fontStyle: 'bold', fontSize: fs + 'px', color: '#ffe066' }).setDepth(2202));
    add(sc.add.text(x0 + pw - pad - fs * 7, y0 + pad * 0.7, 'Gold: ' + st.gold, { fontFamily: 'monospace', fontSize: fs + 'px', color: '#ffe9a8' }).setDepth(2202));
    const ty = y0 + pad + fs * 1.5;
    button('Buy', x0 + pad, ty, this.tab === 'buy' ? '#6a8a3a' : '#4a4a3a', () => { this.tab = 'buy'; this.page = 0; this.build(); });
    button('Sell', x0 + pad + fs * 4.5, ty, this.tab === 'sell' ? '#6a8a3a' : '#4a4a3a', () => { this.tab = 'sell'; this.page = 0; this.build(); });
    button('Close', x0 + pw - pad - fs * 5, ty, '#7a3a3a', () => this.close());

    const rows = this.rows();
    const rowH = Math.round(fs * 2.5);
    const top = ty + fs * 2.4;
    const per = clamp(Math.floor((y0 + ph - top - fs * 2.4) / rowH), 2, 8);
    const pages = Math.max(1, Math.ceil(rows.length / per));
    this.page = clamp(this.page, 0, pages - 1);
    if (!rows.length) add(sc.add.text(x0 + pad, top, this.tab === 'sell' ? 'Nothing to sell.' : 'Sold out.', { fontFamily: 'monospace', fontSize: fs + 'px', color: '#c9b98a' }).setDepth(2202));

    rows.slice(this.page * per, this.page * per + per).forEach((r, i) => {
      const y = top + i * rowH;
      const item = ItemDB.get(r.id);
      add(sc.add.rectangle(x0 + pw / 2, y + rowH / 2 - 2, pw - pad * 2, rowH - 4, 0x34261a, 1).setDepth(2202));
      add(sc.add.image(x0 + pad + 16, y + rowH / 2 - 2, 'items', item.icon).setScale(Math.max(1, Math.floor((rowH - 8) / 16))).setDepth(2203));
      const label = item.name + QUALITY[r.q] + (r.kind === 'sell' ? '  x' + r.count : '');
      add(sc.add.text(x0 + pad + rowH + 4, y + 3, label, { fontFamily: 'monospace', fontSize: Math.round(fs * 0.9) + 'px', color: '#f3e3b8' }).setDepth(2203));
      add(sc.add.text(x0 + pad + rowH + 4, y + fs * 1.2, r.price + ' g each', { fontFamily: 'monospace', fontSize: Math.round(fs * 0.8) + 'px', color: '#ffd24a' }).setDepth(2203));
      const bx = x0 + pw - pad - fs * 10;
      if (r.kind === 'buy') {
        button('Buy', bx, y + 3, '#4a6a3a', () => this.buy(r, 1));
        if (item.type !== 'tool') button('x5', bx + fs * 4.2, y + 3, '#4a6a3a', () => this.buy(r, 5));
      } else {
        button('Sell', bx, y + 3, '#6a5a2a', () => this.sell(r, false));
        if (r.count > 1) button('All', bx + fs * 4.6, y + 3, '#6a5a2a', () => this.sell(r, true));
      }
    });

    if (pages > 1) {
      const py = y0 + ph - fs * 2;
      button('<', x0 + pw / 2 - fs * 4, py, '#4a4a3a', () => { this.page = Math.max(0, this.page - 1); this.build(); });
      add(sc.add.text(x0 + pw / 2 - fs, py + 2, (this.page + 1) + '/' + pages, { fontFamily: 'monospace', fontSize: fs + 'px', color: '#c9b98a' }).setDepth(2203));
      button('>', x0 + pw / 2 + fs * 2.5, py, '#4a4a3a', () => { this.page = Math.min(pages - 1, this.page + 1); this.build(); });
    }
  }
}
