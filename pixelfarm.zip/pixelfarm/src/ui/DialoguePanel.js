import { bus, services } from '../core/services.js';
import { evalCond, pickGreeting, visibleChoices } from '../core/Dialogue.js';
import npcDefs from '../data/npcs.json';
import questDefs from '../data/quests.json';

const clamp = (v, a, b) => Math.max(a, Math.min(b, v));

/** Dialogue box at the bottom: typewriter text, tap to skip/continue, choice buttons. Trees live in npcs.json. */
export class DialoguePanel {
  constructor(scene) {
    this.scene = scene;
    this.open = false;
    this.objs = [];
    this.typing = null;
  }

  get social() { return services.social; }

  start(npcId) {
    this.id = npcId;
    this.def = npcDefs[npcId];
    const ctx = this.social.ctx(npcId);
    const first = pickGreeting(this.def, ctx);
    this.social.talk(npcId);   // marks as met + daily friendship, after the greeting was chosen
    this.open = true;
    this.goto(first);
  }

  close() {
    this.clear();
    this.open = false;
  }

  clear() {
    if (this.typing) { this.typing.remove(false); this.typing = null; }
    for (const o of this.objs) o.destroy();
    this.objs = [];
  }

  goto(nodeId) {
    if (nodeId == null) { this.close(); return; }
    this.node = this.def.nodes[nodeId];
    this.render(this.node.text, this.node);
  }

  /** Plain text that returns to the menu when tapped. */
  say(text, back = 'menu') { this.render(text, { next: back }); }

  render(text, node) {
    this.clear();
    const sc = this.scene;
    const { width: W, height: H } = sc.scale;
    const ctx = this.social.ctx(this.id);
    if (text === '...') text = 'Friendship: ' + ctx.hearts + '/10 hearts';
    const choices = visibleChoices(node, ctx);
    const fs = Math.round(clamp(Math.min(W, H) * 0.048, 13, 24));
    const bw = Math.min(W * 0.96, fs * 38), pad = Math.round(fs * 0.6);
    const btnH = Math.round(fs * 1.9);
    const textH = fs * 1.3 * 3;
    const h = pad * 2 + fs * 1.6 + textH + (choices.length ? choices.length * (btnH + 4) : fs * 1.4);
    const x0 = (W - bw) / 2, y0 = H - h - 6;
    const add = (o) => { this.objs.push(o); return o; };

    const hit = add(sc.add.rectangle(W / 2, H / 2, W, H, 0x000000, 0.35).setDepth(2100).setInteractive());
    add(sc.add.rectangle(W / 2, y0 + h / 2, bw, h, 0x241a10, 0.97).setStrokeStyle(2, 0x8a6a3b, 1).setDepth(2101));
    add(sc.add.text(x0 + pad, y0 + pad * 0.6, this.def.name, {
      fontFamily: 'monospace', fontStyle: 'bold', fontSize: fs + 'px', color: '#ffe066',
    }).setDepth(2102));
    const body = add(sc.add.text(x0 + pad, y0 + pad + fs * 1.5, '', {
      fontFamily: 'monospace', fontSize: Math.round(fs * 0.95) + 'px', color: '#f3e3b8', wordWrap: { width: bw - pad * 2 }, lineSpacing: 3,
    }).setDepth(2102));

    let i = 0;
    const full = text;
    const finish = () => { if (this.typing) { this.typing.remove(false); this.typing = null; } body.setText(full); };
    this.typing = sc.time.addEvent({
      delay: 22, repeat: full.length,
      callback: () => { i++; body.setText(full.slice(0, i)); if (i >= full.length) this.typing = null; },
    });

    if (choices.length) {
      choices.forEach((c, k) => {
        const y = y0 + pad + fs * 1.5 + textH + k * (btnH + 4);
        const b = add(sc.add.rectangle(x0 + bw / 2, y + btnH / 2, bw - pad * 2, btnH, 0x3d5a2e, 1)
          .setDepth(2102).setInteractive({ useHandCursor: true }));
        b.on('pointerover', () => b.setFillStyle(0x4f7a3c));
        b.on('pointerout', () => b.setFillStyle(0x3d5a2e));
        b.on('pointerdown', () => { finish(); this.choose(c); });
        add(sc.add.text(x0 + bw / 2, y + btnH / 2, c.text, {
          fontFamily: 'monospace', fontSize: Math.round(fs * 0.9) + 'px', color: '#ffffff',
        }).setOrigin(0.5).setDepth(2103));
      });
      hit.on('pointerdown', finish);
    } else {
      add(sc.add.text(x0 + bw - pad, y0 + h - pad * 0.6, 'tap to continue', {
        fontFamily: 'monospace', fontSize: Math.round(fs * 0.8) + 'px', color: '#9fc27a',
      }).setOrigin(1, 1).setDepth(2102));
      hit.on('pointerdown', () => {
        if (this.typing) { finish(); return; }
        this.goto(node.next);
      });
    }
  }

  choose(c) {
    const s = this.social;
    if (c.action === 'shop') { this.close(); bus.emit('ui:openShop', this.def.shop); return; }
    if (c.action === 'gift') {
      const r = s.gift(this.id);
      this.say(r.err ? r.err : r.line + '  (' + (r.delta >= 0 ? '+' : '') + r.delta + ' friendship)');
      return;
    }
    if (c.action === 'acceptQuest') {
      s.acceptQuest(c.quest);
      this.say('Great! ' + questDefs[c.quest].hint);
      bus.emit('ui:toast', 'New quest: ' + questDefs[c.quest].title);
      return;
    }
    if (c.action === 'turnIn') {
      const r = s.turnIn(c.quest);
      this.say(r.text);
      if (r.ok) bus.emit('ui:toast', 'Quest complete: ' + questDefs[c.quest].title);
      return;
    }
    this.goto(c.next);
  }
}
