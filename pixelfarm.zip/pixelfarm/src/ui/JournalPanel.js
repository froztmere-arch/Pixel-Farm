import { services } from '../core/services.js';
import { ItemDB } from '../core/ItemDB.js';
import { heartsOf } from '../core/Friendship.js';
import npcDefs from '../data/npcs.json';
import questDefs from '../data/quests.json';
import fishDefs from '../data/fish.json';

const clamp = (v, a, b) => Math.max(a, Math.min(b, v));
const TABS = ['Quests', 'Friends', 'Aquarium'];

/** Journal: quests, friendship hearts, and the aquarium (every fish you have caught). */
export class JournalPanel {
  constructor(scene) {
    this.scene = scene;
    this.open = false;
    this.objs = [];
    this.tab = 0;
  }

  show() { this.open = true; this.build(); }

  close() {
    for (const o of this.objs) o.destroy();
    this.objs = [];
    this.open = false;
  }

  build() {
    for (const o of this.objs) o.destroy();
    this.objs = [];
    const sc = this.scene, st = services.state, social = services.social;
    const { width: W, height: H } = sc.scale;
    const fs = Math.round(clamp(Math.min(W, H) * 0.045, 12, 22));
    const pw = Math.min(W * 0.96, fs * 40), ph = H * 0.94;
    const x0 = (W - pw) / 2, y0 = (H - ph) / 2, pad = Math.round(fs * 0.7);
    const add = (o) => { this.objs.push(o); return o; };
    const txt = (x, y, s, color = '#f3e3b8', size = fs) =>
      add(sc.add.text(x, y, s, { fontFamily: 'monospace', fontSize: size + 'px', color, wordWrap: { width: pw - pad * 2 } }).setDepth(2302));

    add(sc.add.rectangle(W / 2, H / 2, W, H, 0x000000, 0.55).setDepth(2300).setInteractive());
    add(sc.add.rectangle(W / 2, H / 2, pw, ph, 0x241a10, 0.98).setStrokeStyle(2, 0x8a6a3b, 1).setDepth(2301));
    let x = x0 + pad;
    TABS.forEach((t, i) => {
      const b = add(sc.add.text(x, y0 + pad * 0.7, t, {
        fontFamily: 'monospace', fontStyle: 'bold', fontSize: fs + 'px', color: '#ffffff',
        backgroundColor: i === this.tab ? '#6a8a3a' : '#4a4a3a', padding: { x: fs * 0.6, y: fs * 0.3 },
      }).setDepth(2302).setInteractive({ useHandCursor: true }));
      b.on('pointerdown', () => { this.tab = i; this.build(); });
      x += b.width + 6;
    });
    const close = add(sc.add.text(x0 + pw - pad, y0 + pad * 0.7, 'Close', {
      fontFamily: 'monospace', fontStyle: 'bold', fontSize: fs + 'px', color: '#ffffff', backgroundColor: '#7a3a3a', padding: { x: fs * 0.6, y: fs * 0.3 },
    }).setOrigin(1, 0).setDepth(2302).setInteractive({ useHandCursor: true }));
    close.on('pointerdown', () => this.close());

    let y = y0 + pad + fs * 2.6;
    if (this.tab === 0) {
      const active = Object.keys(questDefs).filter((q) => social.questState(q) === 'active');
      const done = Object.keys(questDefs).filter((q) => social.questState(q) === 'done');
      if (!active.length) txt(x0 + pad, y, 'No active quests. Talk to the villagers!', '#c9b98a');
      for (const q of active) {
        const p = social.progress(q), d = questDefs[q];
        y += txt(x0 + pad, y, d.title + '  (' + p.have + '/' + p.need + ')  - ' + npcDefs[d.giver].name, '#ffe066').height;
        y += txt(x0 + pad, y, d.hint + '  Reward: ' + d.reward.gold + ' gold', '#f3e3b8', Math.round(fs * 0.85)).height + 6;
      }
      if (done.length) txt(x0 + pad, y + 6, 'Completed: ' + done.map((q) => questDefs[q].title).join(', '), '#9fc27a', Math.round(fs * 0.85));
    } else if (this.tab === 1) {
      for (const [id, d] of Object.entries(npcDefs)) {
        const r = st.npc[id] || { pts: 0, met: false };
        const h = heartsOf(r.pts);
        txt(x0 + pad, y, d.name + (r.met ? '' : '  (not met yet)'), '#ffe066');
        txt(x0 + pad + fs * 14, y, '#'.repeat(h) + '-'.repeat(10 - h) + '  ' + h + '/10', '#ff8a9a');
        y += fs * 1.8;
      }
    } else {
      const ids = Object.keys(fishDefs);
      const cell = Math.round(clamp((pw - pad * 2) / 6, 40, 80));
      ids.forEach((id, i) => {
        const f = fishDefs[id], c = st.stats.caught[id];
        const cx = x0 + pad + (i % 6) * cell, cy = y + Math.floor(i / 6) * (cell + fs * 2.4);
        const img = add(sc.add.image(cx + cell / 2, cy + cell / 2, 'items', ItemDB.get(f.item).icon).setScale(Math.max(1, Math.floor((cell - 8) / 16))).setDepth(2302));
        if (!c) img.setTint(0x111111);
        txt(cx, cy + cell, c ? f.name : '???', c ? '#f3e3b8' : '#6a5a40', Math.round(fs * 0.75));
        if (c) txt(cx, cy + cell + fs * 0.9, 'x' + c.n + (c.best ? (c.best === 2 ? ' gold' : ' silver') : ''), '#9fc27a', Math.round(fs * 0.7));
      });
      txt(x0 + pad, y0 + ph - fs * 2, 'Caught ' + Object.keys(st.stats.caught).length + '/' + ids.length + ' species', '#ffe9a8');
    }
  }
}
