
// Default layout: x,y = centre as a fraction of the screen, s = size multiplier.
export const TOUCH_DEFS = {
  joystick: { x: 0.14, y: 0.7, s: 1 },
  use: { x: 0.9, y: 0.68, s: 1.15, label: 'USE', actions: ['interact', 'tool'] },
  dodge: { x: 0.76, y: 0.82, s: 1.0, label: 'DODGE', actions: ['dodge'] },
  swap: { x: 0.93, y: 0.44, s: 0.8, label: 'SWAP', actions: ['swap'] },
  bag: { x: 0.94, y: 0.24, s: 0.55, label: 'BAG', actions: ['inventory'] },
  menu: { x: 0.94, y: 0.08, s: 0.5, label: 'MENU', actions: ['menu'] },
};
const BUTTONS = ['use', 'dodge', 'swap', 'bag', 'menu'];
const clamp = (v, a, b) => Math.max(a, Math.min(b, v));

/**
 * Large semi-transparent on-screen controls: floating-style joystick + buttons.
 * Multi-touch safe: every control remembers the pointer that grabbed it.
 * Layout is stored as screen fractions, so it survives resolution/rotation changes.
 */
export class TouchControls {
  constructor(scene, source, settings) {
    this.scene = scene;
    this.source = source;
    this.settings = settings;
    this.visible = true;
    this.enabled = true;
    this.editing = false;
    this.selected = 'use';
    this.drag = null;
    this.controls = {};
    this.toolbar = [];

    for (const name of Object.keys(TOUCH_DEFS)) {
      const def = TOUCH_DEFS[name];
      const c = { name, def, pointer: null, cx: 0, cy: 0, r: 40, kx: 0, ky: 0 };
      c.g = scene.add.graphics().setDepth(900);
      if (name === 'joystick') c.knob = scene.add.graphics().setDepth(901);
      else c.label = scene.add.text(0, 0, def.label, {
        fontFamily: 'monospace', fontStyle: 'bold', fontSize: '14px', color: '#ffffff',
      }).setOrigin(0.5).setAlpha(0.85).setDepth(901);
      this.controls[name] = c;
    }

    scene.input.on('pointerdown', this.onDown, this);
    scene.input.on('pointermove', this.onMove, this);
    scene.input.on('pointerup', this.onUp, this);
    this.layout();
  }

  destroy() {
    this.scene.input.off('pointerdown', this.onDown, this);
    this.scene.input.off('pointermove', this.onMove, this);
    this.scene.input.off('pointerup', this.onUp, this);
    this.source.clear();
  }

  // ---- layout / drawing -------------------------------------------------------------------

  layout() {
    const W = this.scene.scale.width, H = this.scene.scale.height;
    const baseR = clamp(Math.min(W, H) * 0.12, 34, 70);
    for (const name of Object.keys(this.controls)) {
      const c = this.controls[name];
      const l = this.settings.getLayout(name, c.def);
      c.r = baseR * l.s * (name === 'joystick' ? 1.5 : 1);
      c.cx = clamp(l.x * W, c.r, W - c.r);
      c.cy = clamp(l.y * H, c.r, H - c.r);
      this.draw(c);
    }
    if (this.editing) this.buildToolbar();
  }

  draw(c) {
    const selected = this.editing && this.selected === c.name;
    c.g.clear();
    c.g.setPosition(c.cx, c.cy);
    c.g.fillStyle(0xffffff, c.pointer ? 0.34 : 0.14).fillCircle(0, 0, c.r);
    c.g.lineStyle(3, selected ? 0xffe066 : 0xffffff, selected ? 0.95 : 0.45).strokeCircle(0, 0, c.r);
    if (c.label) {
      c.label.setPosition(c.cx, c.cy);
      c.label.setFontSize(Math.max(9, Math.round(c.r * 0.34)));
    }
    if (c.knob) {
      c.knob.clear();
      c.knob.setPosition(c.cx + c.kx, c.cy + c.ky);
      c.knob.fillStyle(0xffffff, c.pointer ? 0.5 : 0.28).fillCircle(0, 0, c.r * 0.42);
      c.knob.lineStyle(2, 0xffffff, 0.55).strokeCircle(0, 0, c.r * 0.42);
    }
  }

  setVisible(v) {
    this.visible = v;
    for (const c of Object.values(this.controls)) {
      c.g.setVisible(v);
      if (c.knob) c.knob.setVisible(v);
      if (c.label) c.label.setVisible(v);
    }
    if (!v) this.releaseAll();
  }

  /** Disabled while a menu is open: controls stay visible but ignore touches. */
  setEnabled(v) {
    if (this.enabled === v) return;
    this.enabled = v;
    if (!v) this.releaseAll();
  }

  // ---- pointer handling -------------------------------------------------------------------

  dist(c, p) { return Math.hypot(p.x - c.cx, p.y - c.cy); }

  onDown(p) {
    if (!this.visible || !this.enabled) return;
    if (this.editing) return this.editDown(p);
    if (this.scene.input.hitTestPointer(p).length > 0) return; // finger landed on the hotbar or a menu

    for (const name of BUTTONS) {
      const c = this.controls[name];
      if (c.pointer || this.dist(c, p) > c.r * 1.15) continue;
      c.pointer = p;
      for (const a of c.def.actions) this.source.press(a);
      this.draw(c);
      return;
    }
    const j = this.controls.joystick;
    if (!j.pointer && this.dist(j, p) <= j.r * 1.6) {
      j.pointer = p;
      this.moveStick(p);
    }
  }

  onMove(p) {
    if (!this.visible || !this.enabled) return;
    if (this.editing) return this.editMove(p);
    const j = this.controls.joystick;
    if (j.pointer && j.pointer.id === p.id) this.moveStick(p);
  }

  onUp(p) {
    if (this.editing) return this.editUp(p);
    for (const c of Object.values(this.controls)) {
      if (c.pointer && c.pointer.id === p.id) this.releaseControl(c);
    }
  }

  moveStick(p) {
    const j = this.controls.joystick;
    const dx = p.x - j.cx, dy = p.y - j.cy;
    const d = Math.hypot(dx, dy);
    const k = d > j.r ? j.r / d : 1;
    j.kx = dx * k;
    j.ky = dy * k;
    const strength = Math.min(1, d / j.r);
    const dead = 0.15;
    if (strength < dead || d === 0) {
      this.source.x = 0;
      this.source.y = 0;
    } else {
      const s = (strength - dead) / (1 - dead);
      this.source.x = (dx / d) * s;
      this.source.y = (dy / d) * s;
    }
    this.draw(j);
  }

  releaseControl(c) {
    c.pointer = null;
    if (c.name === 'joystick') {
      c.kx = 0;
      c.ky = 0;
      this.source.x = 0;
      this.source.y = 0;
    } else {
      for (const a of c.def.actions) this.source.release(a);
    }
    this.draw(c);
  }

  releaseAll() {
    for (const c of Object.values(this.controls)) if (c.pointer) this.releaseControl(c);
    this.source.x = 0;
    this.source.y = 0;
  }

  /** Called every frame: drops controls whose finger vanished without an 'up' event. */
  update() {
    for (const c of Object.values(this.controls)) {
      if (c.pointer && !c.pointer.isDown) this.releaseControl(c);
    }
  }

  // ---- layout editor ----------------------------------------------------------------------

  beginEdit() {
    this.editing = true;
    this.releaseAll();
    this.setVisible(true);
    this.enabled = true;
    this.buildToolbar();
    for (const c of Object.values(this.controls)) this.draw(c);
  }

  endEdit() {
    this.editing = false;
    this.drag = null;
    this.clearToolbar();
    this.settings.save();
    for (const c of Object.values(this.controls)) this.draw(c);
  }

  clearToolbar() {
    for (const o of this.toolbar) o.destroy();
    this.toolbar = [];
  }

  buildToolbar() {
    this.clearToolbar();
    const W = this.scene.scale.width;
    const fs = Math.round(clamp(Math.min(W, this.scene.scale.height) * 0.05, 14, 24));
    const style = {
      fontFamily: 'monospace', fontStyle: 'bold', fontSize: fs + 'px', color: '#ffffff',
      backgroundColor: '#2d4a36', padding: { x: fs * 0.6, y: fs * 0.4 },
    };
    const hint = this.scene.add.text(W / 2, 6, 'Drag a control to move it', {
      fontFamily: 'monospace', fontSize: Math.round(fs * 0.85) + 'px', color: '#ffe066',
    }).setOrigin(0.5, 0).setDepth(2100);
    this.toolbar.push(hint);

    const items = [
      ['Smaller', () => this.resize(1 / 1.12)],
      ['Bigger', () => this.resize(1.12)],
      ['Reset', () => { this.settings.resetLayout(); this.layout(); }],
      ['Done', () => this.endEdit()],
    ];
    const gap = fs * 0.6;
    const texts = items.map(([label, fn]) => {
      const t = this.scene.add.text(0, 0, label, style).setDepth(2100).setInteractive({ useHandCursor: true });
      t.on('pointerdown', fn);
      return t;
    });
    const total = texts.reduce((s, t) => s + t.width, 0) + gap * (texts.length - 1);
    let x = (W - total) / 2;
    const y = hint.y + hint.height + 6;
    for (const t of texts) { t.setPosition(x, y); x += t.width + gap; this.toolbar.push(t); }
  }

  resize(factor) {
    const c = this.controls[this.selected];
    const l = this.settings.getLayout(c.name, c.def);
    l.s = clamp(l.s * factor, 0.5, 2.2);
    this.settings.setLayout(c.name, l);
    this.layout();
  }

  editDown(p) {
    if (this.scene.input.hitTestPointer(p).length > 0) return; // toolbar button was hit
    let best = null, bestD = Infinity;
    for (const c of Object.values(this.controls)) {
      const d = this.dist(c, p);
      if (d <= c.r * 1.1 && d < bestD) { best = c; bestD = d; }
    }
    if (!best) return;
    this.selected = best.name;
    this.drag = { name: best.name, dx: best.cx - p.x, dy: best.cy - p.y, id: p.id };
    for (const c of Object.values(this.controls)) this.draw(c);
  }

  editMove(p) {
    if (!this.drag || this.drag.id !== p.id) return;
    const W = this.scene.scale.width, H = this.scene.scale.height;
    const c = this.controls[this.drag.name];
    const l = this.settings.getLayout(c.name, c.def);
    l.x = (p.x + this.drag.dx) / W;
    l.y = (p.y + this.drag.dy) / H;
    this.settings.setLayout(c.name, l, false);
    this.layout();
  }

  editUp(p) {
    if (this.drag && this.drag.id === p.id) {
      this.drag = null;
      this.settings.save();
    }
  }
}
