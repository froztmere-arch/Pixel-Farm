import { HOTBAR_SIZE } from '../core/GameState.js';
import { ItemDB } from '../core/ItemDB.js';
import { bus } from '../core/services.js';

const clamp = (v, a, b) => Math.max(a, Math.min(b, v));

/** The 9-slot hotbar: tap/click a slot, press 1-9, scroll the wheel, or use the SWAP button. */
export class Hotbar {
  constructor(scene, state) {
    this.scene = scene;
    this.state = state;
    this.objs = [];
    this.icons = [];
    this.counts = [];
    this.lastVersion = -1;
    this.lastSel = -1;
    this.atTop = true;
    this.g = scene.add.graphics().setDepth(1000);
    this.g2 = scene.add.graphics().setDepth(1002); // quality markers, above the icons
    this.nameText = scene.add.text(0, 0, '', {
      fontFamily: 'monospace', fontSize: '14px', color: '#fff6d0', stroke: '#000000', strokeThickness: 3,
    }).setOrigin(0.5, 0).setDepth(1002).setAlpha(0);
    for (let i = 0; i < HOTBAR_SIZE; i++) {
      this.icons.push(scene.add.image(0, 0, 'items').setDepth(1001).setVisible(false));
      this.counts.push(scene.add.text(0, 0, '', {
        fontFamily: 'monospace', fontStyle: 'bold', fontSize: '12px', color: '#ffffff', stroke: '#000000', strokeThickness: 3,
      }).setOrigin(1, 1).setDepth(1002));
    }
    this.zones = [];
    for (let i = 0; i < HOTBAR_SIZE; i++) {
      const z = scene.add.zone(0, 0, 10, 10).setOrigin(0, 0).setInteractive().setDepth(1003);
      z.on('pointerdown', () => this.select(i));
      this.zones.push(z);
    }
    bus.on('hotbar:select', this.flashName, this);
  }

  destroy() {
    bus.off('hotbar:select', this.flashName, this);
  }

  select(i) {
    this.state.select(i);
    bus.emit('hotbar:select');
  }

  /** atTop: on phones the bar sits at the top so the thumbs' controls stay free. */
  layout(W, H, atTop) {
    this.atTop = atTop;
    let s = clamp(Math.round(Math.min(W, H) / 170), 2, 5);
    while (s > 1 && HOTBAR_SIZE * (16 * s + 10) > W * 0.6) s--;
    this.s = s;
    this.cell = 16 * s + 10;
    this.left = Math.round((W - HOTBAR_SIZE * this.cell) / 2);
    this.top = atTop ? 6 : H - this.cell - 8;
    for (let i = 0; i < HOTBAR_SIZE; i++) {
      this.zones[i].setPosition(this.left + i * this.cell, this.top).setSize(this.cell, this.cell);
      this.zones[i].input.hitArea.setSize(this.cell, this.cell);
      this.icons[i].setScale(s);
      this.counts[i].setFontSize(Math.round(3.5 * s + 5));
    }
    this.nameText.setPosition(W / 2, atTop ? this.top + this.cell + 3 : this.top - 20);
    this.nameText.setOrigin(0.5, atTop ? 0 : 1);
    this.nameText.setFontSize(Math.round(clamp(Math.min(W, H) * 0.04, 12, 20)));
    this.lastVersion = -1;
    this.refresh();
  }

  refresh() {
    const inv = this.state.inventory, c = this.cell;
    this.g.clear();
    this.g2.clear();
    for (let i = 0; i < HOTBAR_SIZE; i++) {
      const x = this.left + i * c, y = this.top;
      const sel = i === this.state.selected;
      this.g.fillStyle(sel ? 0x5a4126 : 0x2e2114, 0.88).fillRect(x + 1, y + 1, c - 2, c - 2);
      this.g.lineStyle(sel ? 3 : 2, sel ? 0xffe066 : 0x8a6a3b, 1).strokeRect(x + 1, y + 1, c - 2, c - 2);
      const st = inv.slots[i];
      const icon = this.icons[i], cnt = this.counts[i];
      if (st) {
        icon.setFrame(ItemDB.get(st.id).icon).setPosition(x + c / 2, y + c / 2).setVisible(true);
        const label = st.id === 'watering_can' ? String(this.state.water) : st.count > 1 ? String(st.count) : '';
        cnt.setPosition(x + c - 3, y + c - 2).setText(label);
        if (st.q) this.g2.fillStyle(st.q === 2 ? 0xffd24a : 0xcfd8e6, 1).fillRect(x + 4, y + 4, 3 * this.s, 3 * this.s)
          .lineStyle(1, 0x000000, 0.7).strokeRect(x + 4, y + 4, 3 * this.s, 3 * this.s);
      } else {
        icon.setVisible(false);
        cnt.setText('');
      }
    }
    this.lastVersion = inv.version;
    this.lastSel = this.state.selected;
  }

  flashName() {
    const st = this.state.selectedStack();
    if (!st) { this.nameText.setAlpha(0); return; }
    this.nameText.setText(ItemDB.get(st.id).name + (st.q ? ' (' + (st.q === 2 ? 'Gold' : 'Silver') + ')' : '')).setAlpha(1);
    this.scene.tweens.killTweensOf(this.nameText);
    this.scene.tweens.add({ targets: this.nameText, alpha: 0, delay: 1100, duration: 500 });
  }

  update() {
    if (this.state.inventory.version !== this.lastVersion || this.state.selected !== this.lastSel) this.refresh();
  }
}
