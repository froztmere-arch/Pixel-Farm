import Phaser from 'phaser';

// Global event bus: scenes and systems talk through this, never directly.
export const bus = new Phaser.Events.EventEmitter();

// Shared singletons, filled in by BootScene.
export const services = {
  input: null,     // InputManager
  settings: null,  // Settings
  save: null,      // SaveManager
  mouse: null,     // MouseSource (aim position)
  state: null,     // GameState (inventory, hotbar, chests)
  touch: null,     // TouchSource (written by the UI scene's on-screen controls)
  uiHover: false,  // true while the pointer is over a UI widget (clicks there must not swing tools)
  debug: { pos: '', chunks: 0 },
};
