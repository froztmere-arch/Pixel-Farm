/** Item definitions live in src/data/items.json. Call ItemDB.init(json) once at boot. */
export const ItemDB = {
  items: {},
  init(data) { this.items = data; },
  has(id) { return !!this.items[id]; },
  get(id) {
    const it = this.items[id];
    if (!it) throw new Error('Unknown item id: ' + id);
    return it;
  },
};
