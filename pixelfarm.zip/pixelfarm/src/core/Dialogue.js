/**
 * Dialogue trees are plain data (npcs.json). ctx = {hearts, met, season, quests: {id: 'none'|'active'|'done'}}.
 * A condition is an object; every key must hold:
 *   hearts: n (at least n hearts) | met: bool | season: name | quest: id + state: 'none'|'active'|'done'
 */
export function evalCond(cond, ctx) {
  if (!cond) return true;
  if (cond.hearts != null && ctx.hearts < cond.hearts) return false;
  if (cond.met != null && !!cond.met !== !!ctx.met) return false;
  if (cond.season && cond.season !== ctx.season) return false;
  if (cond.quest && (ctx.quests[cond.quest] || 'none') !== (cond.state || 'active')) return false;
  return true;
}

export function pickGreeting(npc, ctx) {
  for (const g of npc.greet) if (evalCond(g.cond, ctx)) return g.node;
  return Object.keys(npc.nodes)[0];
}

export function visibleChoices(node, ctx) {
  return (node.choices || []).filter((c) => evalCond(c.cond, ctx));
}
