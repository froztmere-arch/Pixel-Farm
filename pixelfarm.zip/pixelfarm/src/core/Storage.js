/** Key-value storage. IndexedDB when available (big, fast, async), localStorage as a fallback. Values are strings. */
export class IDBStorage {
  constructor(name = 'pixelfarm', store = 'kv') {
    this.name = name;
    this.store = store;
    this.dbp = null;
  }

  db() {
    if (!this.dbp) {
      this.dbp = new Promise((resolve, reject) => {
        const r = indexedDB.open(this.name, 1);
        r.onupgradeneeded = () => r.result.createObjectStore(this.store);
        r.onsuccess = () => resolve(r.result);
        r.onerror = () => reject(r.error);
      });
    }
    return this.dbp;
  }

  async run(mode, fn) {
    const db = await this.db();
    return new Promise((resolve, reject) => {
      const t = db.transaction(this.store, mode);
      const req = fn(t.objectStore(this.store));
      t.oncomplete = () => resolve(req ? req.result : undefined);
      t.onerror = () => reject(t.error);
      t.onabort = () => reject(t.error);
    });
  }

  async get(key) {
    const v = await this.run('readonly', (s) => s.get(key));
    return v === undefined ? null : v;
  }
  set(key, value) { return this.run('readwrite', (s) => s.put(value, key)); }
  del(key) { return this.run('readwrite', (s) => s.delete(key)); }
}

export class LocalStorageStorage {
  async get(key) { return localStorage.getItem('pixelfarm.save.' + key); }
  async set(key, value) { localStorage.setItem('pixelfarm.save.' + key, value); }
  async del(key) { localStorage.removeItem('pixelfarm.save.' + key); }
}

export class MemoryStorage {
  constructor() { this.m = new Map(); this.writes = []; }
  async get(key) { return this.m.has(key) ? this.m.get(key) : null; }
  async set(key, value) { this.m.set(key, value); this.writes.push(key); }
  async del(key) { this.m.delete(key); }
}

export async function createStorage() {
  try {
    if (typeof indexedDB === 'undefined') throw new Error('no indexedDB');
    const s = new IDBStorage();
    await s.db();
    return s;
  } catch (e) {
    return new LocalStorageStorage();
  }
}
