export const RECORDS = ['meta', 'inventory', 'containers', 'mods', 'farm', 'progress'];
const FORMAT = 1;

/**
 * Delta saves: the game is split into small records. Each record is flagged "dirty" when it changes
 * and only dirty records are written. The world itself is never saved - it is re-generated from the
 * seed - only the player's changes to it (mods, farm) are.
 */
export class SaveManager {
  constructor(storage) {
    this.storage = storage;
    this.dirty = new Set();
  }

  mark(...names) { for (const n of names) this.dirty.add(n); }

  async hasSave() {
    try { return (await this.storage.get('meta')) != null; } catch (e) { return false; }
  }

  async load() {
    const out = {};
    for (const k of RECORDS) {
      const raw = await this.storage.get(k);
      out[k] = raw == null ? null : JSON.parse(raw);
    }
    return out.meta ? out : null;
  }

  /** build: {record: () => data}. Writes dirty records only (or everything when all=true). */
  async flush(build, all = false) {
    const names = all ? [...RECORDS] : RECORDS.filter((k) => this.dirty.has(k));
    for (const n of names) this.dirty.delete(n);
    for (const n of names) await this.storage.set(n, JSON.stringify(build[n]()));
    return names;
  }

  async wipe() {
    for (const k of RECORDS) await this.storage.del(k);
    this.dirty.clear();
  }

  async exportText() {
    const records = {};
    for (const k of RECORDS) {
      const raw = await this.storage.get(k);
      if (raw != null) records[k] = JSON.parse(raw);
    }
    return JSON.stringify({ game: 'pixelfarm', format: FORMAT, records });
  }

  /** Returns true if the text was a valid save and has been stored. */
  async importText(text) {
    let obj;
    try { obj = JSON.parse(text); } catch (e) { return false; }
    if (!obj || obj.game !== 'pixelfarm' || !obj.records || !obj.records.meta || typeof obj.records.meta.seed !== 'number') return false;
    await this.wipe();
    for (const k of RECORDS) if (obj.records[k] != null) await this.storage.set(k, JSON.stringify(obj.records[k]));
    return true;
  }
}
