export const POINTS_PER_HEART = 250;
export const MAX_HEARTS = 10;
export const MAX_POINTS = POINTS_PER_HEART * MAX_HEARTS;
export const GIFT_POINTS = { love: 80, like: 45, neutral: 20, dislike: -20, hate: -40 };
export const TALK_POINTS = 20;

export const heartsOf = (pts) => Math.min(MAX_HEARTS, Math.floor(pts / POINTS_PER_HEART));

export function giftReaction(npc, itemId) {
  if ((npc.loves || []).includes(itemId)) return 'love';
  if ((npc.likes || []).includes(itemId)) return 'like';
  if ((npc.hates || []).includes(itemId)) return 'hate';
  if ((npc.dislikes || []).includes(itemId)) return 'dislike';
  return 'neutral';
}
