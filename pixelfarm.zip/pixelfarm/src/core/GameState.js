import { Inventory } from '../entities/Inventory.js';
import { ItemDB } from './ItemDB.js';
import { Clock } from './Clock.js';

export const HOTBAR_SIZE = 9;
export const BACKPACK_SIZE = 36; // slots 0-8 are the hotbar
export const WATER_MAX = 40;

/** Everything about the current game that gets saved (see SaveManager for how it is split up). */
export class GameState {
  constructor() {
    this.inventory = new Inventory(BACKPACK_SIZE);
    this.selected = 0;
    this.water = WATER_MAX;             // watering can level
    this.containers = new Map();        // "tx,ty" -> Inventory (chests)
    this.clock = new Clock();
    this.weather = 'sunny';
    this.gold = 500;
    this.npc = {};                      // id -> {pts, talked: day, gifted: day, met: true}
    this.quests = {};                   // id -> {state: 'active'|'done', base: stats.fish when accepted}
    this.stats = { fish: 0, caught: {} };  // caught: fish species id -> {n, best}
    this.progressVersion = 0;
    for (const id of ['axe', 'pickaxe', 'hoe', 'watering_can']) this.inventory.add(id);
    this.inventory.add('wheat_seeds', 10);
    this.inventory.add('beet_seeds', 5);
  }

  /** Rebuilds a GameState from the records written by SaveManager. */
  static fromSave(rec) {
    const s = new GameState();
    s.inventory = rec.inventory ? Inventory.fromJSON(rec.inventory) : s.inventory;
    s.selected = rec.meta.selected || 0;
    s.water = rec.meta.water == null ? WATER_MAX : rec.meta.water;
    s.clock = new Clock(rec.meta.day, rec.meta.minutes);
    s.gold = rec.meta.gold == null ? 500 : rec.meta.gold;
    if (rec.progress) { s.npc = rec.progress.npc || {}; s.quests = rec.progress.quests || {}; s.stats = rec.progress.stats || s.stats; }
    s.containers = new Map((rec.containers || []).map(([k, arr]) => [k, Inventory.fromJSON(arr)]));
    return s;
  }

  selectedStack() { return this.inventory.slots[this.selected]; }

  selectedItem() {
    const s = this.selectedStack();
    return s ? ItemDB.get(s.id) : null;
  }

  select(i) { this.selected = ((i % HOTBAR_SIZE) + HOTBAR_SIZE) % HOTBAR_SIZE; }

  container(key, size = 27, starter = null) {
    let c = this.containers.get(key);
    if (!c) {
      c = new Inventory(size);
      if (starter) for (const [id, n] of starter) c.add(id, n);
      this.containers.set(key, c);
    }
    return c;
  }

  containerVersion() {
    let v = 0;
    for (const c of this.containers.values()) v += c.version;
    return v;
  }
}
