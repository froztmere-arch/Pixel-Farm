/**
 * Tiny state machine used by the player now, and by NPCs and bosses later.
 * states: { name: { enter(owner, ...args), update(owner, dt, fsm), exit(owner) } }
 */
export class StateMachine {
  constructor(owner, states, initial) {
    this.owner = owner;
    this.states = states;
    this.current = null;
    this.previous = null;
    this.set(initial);
  }

  set(name, ...args) {
    if (name === this.current) return;
    const prev = this.states[this.current];
    if (prev && prev.exit) prev.exit(this.owner);
    this.previous = this.current;
    this.current = name;
    const next = this.states[name];
    if (next && next.enter) next.enter(this.owner, ...args);
  }

  update(dt) {
    const s = this.states[this.current];
    if (s && s.update) s.update(this.owner, dt, this);
  }
}
