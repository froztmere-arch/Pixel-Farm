import { bus } from './services.js';

const KEY = 'pixelfarm.settings.v1';

/** Small persistent settings store (localStorage). */
export class Settings {
  constructor() {
    this.data = { controlMode: 'auto', showDebug: false, seed: null, layout: {} };
    try {
      const raw = localStorage.getItem(KEY);
      if (raw) Object.assign(this.data, JSON.parse(raw));
    } catch (e) { /* corrupted or unavailable storage: keep defaults */ }
    if (this.data.seed == null) {
      this.data.seed = Math.floor(Math.random() * 0x7fffffff);
      this.save();
    }
  }

  save() {
    try { localStorage.setItem(KEY, JSON.stringify(this.data)); } catch (e) { /* ignore */ }
  }

  get(key) { return this.data[key]; }

  set(key, value) {
    this.data[key] = value;
    this.save();
    bus.emit('settings:changed', key, value);
  }

  /** Touch button layout: {x,y} are screen fractions (0-1) of the button centre, s is a size multiplier. */
  getLayout(name, def) {
    const l = this.data.layout[name];
    return l ? { x: l.x, y: l.y, s: l.s } : { ...def };
  }

  setLayout(name, value, save = true) {
    this.data.layout[name] = { x: value.x, y: value.y, s: value.s };
    if (save) this.save();
  }

  resetLayout() {
    this.data.layout = {};
    this.save();
    bus.emit('settings:changed', 'layout', null);
  }
}
