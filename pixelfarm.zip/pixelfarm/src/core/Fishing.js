const clamp = (v, a, b) => Math.max(a, Math.min(b, v));

/** Fish that can bite right now. cond = {season, hour (0-26), weather, location}. */
export function eligibleFish(defs, cond, caughtLegendary = new Set()) {
  const out = [];
  for (const [id, f] of Object.entries(defs)) {
    if (f.legendary && caughtLegendary.has(id)) continue;
    if (!f.seasons.includes(cond.season)) continue;
    if (cond.hour < f.hours[0] || cond.hour >= f.hours[1]) continue;
    if (!f.weather.includes(cond.weather)) continue;
    if (!f.locations.includes(cond.location)) continue;
    out.push([id, f]);
  }
  return out;
}

export function pickFish(defs, cond, rng = Math.random, caughtLegendary = new Set()) {
  const list = eligibleFish(defs, cond, caughtLegendary);
  if (!list.length) return null;
  let t = rng() * list.reduce((s, [, f]) => s + f.weight, 0);
  for (const [id, f] of list) { t -= f.weight; if (t < 0) return id; }
  return list[list.length - 1][0];
}

/** Quality of a caught fish: a flawless reel gives silver/gold more often. */
export function fishQuality(perfect, rng = Math.random) {
  const r = rng();
  if (perfect) return r < 0.35 ? 2 : r < 0.8 ? 1 : 0;
  return r < 0.05 ? 2 : r < 0.25 ? 1 : 0;
}

/**
 * The reeling mini-game (Stardew style). Positions are 0 (bottom) to 1 (top).
 * Hold = the catch bar rises, release = it sinks. Keep the fish inside the bar to fill the meter.
 */
export class FishingBar {
  constructor(difficulty, rng = Math.random) {
    this.d = difficulty;
    this.rng = rng;
    this.size = Math.max(0.18, 0.34 - difficulty * 0.016);
    this.bar = 0.1;       // bottom edge of the bar
    this.vel = 0;
    this.fish = 0.5;
    this.target = 0.5;
    this.timer = 0;
    this.progress = 0.3;
    this.perfect = true;
    this.result = null;   // null | 'win' | 'lose'
  }

  get inside() { return this.fish >= this.bar && this.fish <= this.bar + this.size; }

  update(dt, hold) {
    if (this.result) return;
    this.vel = clamp(this.vel + (hold ? 1.7 : -1.4) * dt, -1.1, 1.1);
    this.bar += this.vel * dt;
    if (this.bar < 0) { this.bar = 0; this.vel = Math.abs(this.vel) * 0.25; }
    if (this.bar > 1 - this.size) { this.bar = 1 - this.size; this.vel = 0; }

    this.timer -= dt;
    if (this.timer <= 0) {
      this.target = this.rng();
      this.timer = 0.4 + this.rng() * Math.max(0.3, 1.5 - this.d * 0.1);
    }
    const speed = 0.3 + this.d * 0.06;
    this.fish += clamp(this.target - this.fish, -speed * dt, speed * dt);

    const inside = this.inside;
    this.progress += (inside ? 0.3 - this.d * 0.01 : -0.14) * dt;
    if (!inside) this.perfect = false;
    if (this.progress >= 1) { this.progress = 1; this.result = 'win'; }
    else if (this.progress <= 0) { this.progress = 0; this.result = 'lose'; }
  }
}
