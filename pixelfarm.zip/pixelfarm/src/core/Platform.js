// Detects what we are running on. Gameplay code never reads this - only the input/UI layer does.
const w = typeof window !== 'undefined' ? window : {};
const nav = typeof navigator !== 'undefined' ? navigator : { userAgent: '', maxTouchPoints: 0 };

export const Platform = {
  isCapacitor: !!(w.Capacitor && typeof w.Capacitor.isNativePlatform === 'function' && w.Capacitor.isNativePlatform()),
  isElectron: /electron/i.test(nav.userAgent || ''),
  hasTouch: (nav.maxTouchPoints || 0) > 0 || 'ontouchstart' in w,
  coarsePointer: !!(w.matchMedia && w.matchMedia('(pointer: coarse)').matches),
};

/** mode: 'auto' | 'touch' | 'keyboard' */
export function wantsTouchUI(mode) {
  if (mode === 'touch') return true;
  if (mode === 'keyboard') return false;
  if (Platform.isCapacitor) return true;
  if (Platform.isElectron) return false;
  return Platform.hasTouch && Platform.coarsePointer;
}
