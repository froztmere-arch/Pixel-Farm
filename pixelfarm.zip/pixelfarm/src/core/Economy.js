import { hash } from '../world/WorldGen.js';

export const QUALITY_MULT = [1, 1.25, 1.5];
const TYPES = ['crop', 'fish', 'forage', 'food', 'material'];

export function strHash(s) {
  let h = 2166136261;
  for (let i = 0; i < s.length; i++) h = Math.imul(h ^ s.charCodeAt(i), 16777619);
  return h | 0;
}

/** Daily market swing per item type: 0.85x - 1.25x of the base sell price. Same seed + day = same prices. */
export function marketMultiplier(seed, day, type) {
  const t = Math.max(0, TYPES.indexOf(type));
  return 0.85 + hash(seed, day, t, 401) * 0.4;
}

export function sellPrice(item, q, seed, day) {
  if (!item.sell) return 0;
  return Math.max(1, Math.round(item.sell * (QUALITY_MULT[q || 0] || 1) * marketMultiplier(seed, day, item.type)));
}

/** Shop price: small daily wobble, cheaper seeds in season, festival discount. */
export function buyPrice(id, item, seed, day, season, crops, festival) {
  if (!item.buy) return 0;
  let m = 0.92 + hash(seed, day, strHash(id), 402) * 0.2;
  if (item.type === 'seed' && crops[item.plants] && crops[item.plants].seasons.includes(season)) m *= 0.9;
  if (festival) m *= 1 - (festival.discount || 0);
  return Math.max(1, Math.round(item.buy * m));
}

/** Stock = the "always" list + a few items picked from the rotating pool, different every day. */
export function shopStock(shop, seed, day) {
  const pool = [...shop.rotating.pool];
  const out = [...shop.always];
  for (let i = 0; i < shop.rotating.count && pool.length; i++) {
    const k = Math.floor(hash(seed, day, i, 403) * pool.length);
    out.push(pool.splice(k, 1)[0]);
  }
  return out;
}

export function festivalToday(events, clock) {
  return events.find((e) => e.season === clock.season && e.day === clock.dayOfSeason) || null;
}
