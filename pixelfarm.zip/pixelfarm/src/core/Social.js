import { ItemDB } from './ItemDB.js';
import { heartsOf, giftReaction, GIFT_POINTS, TALK_POINTS, MAX_POINTS } from './Friendship.js';

/** Friendship, gifts and quests. Works on GameState + the JSON definitions, no Phaser needed. */
export class Social {
  constructor(state, npcDefs, questDefs) {
    this.state = state;
    this.npcs = npcDefs;
    this.quests = questDefs;
  }

  rec(id) {
    if (!this.state.npc[id]) this.state.npc[id] = { pts: 0, talked: 0, gifted: 0, met: false };
    return this.state.npc[id];
  }

  touch() { this.state.progressVersion++; }
  points(id) { return this.rec(id).pts; }
  hearts(id) { return heartsOf(this.rec(id).pts); }
  addPoints(id, n) { const r = this.rec(id); r.pts = Math.max(0, Math.min(MAX_POINTS, r.pts + n)); this.touch(); }

  questState(qid) { return this.state.quests[qid] ? this.state.quests[qid].state : 'none'; }

  /** Context for evaluating dialogue conditions. */
  ctx(id) {
    const quests = {};
    for (const q of Object.keys(this.quests)) quests[q] = this.questState(q);
    return { hearts: this.hearts(id), met: this.rec(id).met, season: this.state.clock.season, quests };
  }

  /** Called when a conversation starts: marks as met, and the first chat of the day gives a little friendship. */
  talk(id) {
    const r = this.rec(id);
    r.met = true;
    if (r.talked !== this.state.clock.day) { r.talked = this.state.clock.day; this.addPoints(id, TALK_POINTS); }
    this.touch();
  }

  /** Gives the selected hotbar item. Returns {err} or {reaction, delta, line}. */
  gift(id) {
    const st = this.state, r = this.rec(id);
    const stack = st.selectedStack();
    if (!stack) return { err: 'Select the item you want to give first (hotbar).' };
    const item = ItemDB.get(stack.id);
    if (item.type === 'tool') return { err: 'You cannot give away your tools.' };
    if (r.gifted === st.clock.day) return { err: 'You already gave a gift today.' };
    const reaction = giftReaction(this.npcs[id], stack.id);
    const delta = GIFT_POINTS[reaction];
    st.inventory.removeAt(st.selected, 1);
    r.gifted = st.clock.day;
    this.addPoints(id, delta);
    return { reaction, delta, line: this.npcs[id].gifts[reaction] };
  }

  acceptQuest(qid) {
    if (this.questState(qid) !== 'none') return false;
    this.state.quests[qid] = { state: 'active', base: this.state.stats.fish };
    this.touch();
    return true;
  }

  /** How far along an active quest is: {have, need}. */
  progress(qid) {
    const q = this.quests[qid], st = this.state;
    if (q.type === 'catch') return { have: Math.min(q.count, st.stats.fish - (st.quests[qid] ? st.quests[qid].base : 0)), need: q.count };
    return { have: Math.min(q.count, q.items.reduce((n, id) => n + st.inventory.countOf(id), 0)), need: q.count };
  }

  /** Turns a quest in. Returns {ok, text}. */
  turnIn(qid) {
    const q = this.quests[qid], st = this.state;
    if (this.questState(qid) !== 'active') return { ok: false, text: 'Nothing to hand in.' };
    const p = this.progress(qid);
    if (p.have < p.need) return { ok: false, text: 'Not yet! (' + p.have + '/' + p.need + ') ' + q.hint };
    if (q.type === 'deliver') {
      let left = q.count;
      for (const id of q.items) left -= st.inventory.remove(id, left);
    }
    st.quests[qid].state = 'done';
    st.gold += q.reward.gold || 0;
    this.addPoints(q.giver, q.reward.friend || 0);
    return { ok: true, text: 'Thank you! Here is ' + (q.reward.gold || 0) + ' gold.' };
  }

  /** Called whenever a fish is caught. */
  recordCatch(speciesId, q) {
    const c = this.state.stats.caught;
    const isNew = !c[speciesId];
    if (isNew) c[speciesId] = { n: 0, best: 0 };
    c[speciesId].n++;
    c[speciesId].best = Math.max(c[speciesId].best, q);
    this.state.stats.fish++;
    this.touch();
    return isNew;
  }
}
