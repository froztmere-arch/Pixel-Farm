import { hash } from '../world/WorldGen.js';
import { strHash } from './Economy.js';

/**
 * Where an NPC wants to be. slots: [{from, to, at:{x,y} | wander:{x,y,r} | shore:true}] (hours, up to 31).
 * festival: today's festival or null (everyone gathers there while it runs).
 * Wandering is deterministic per 20-minute block, so the simulation needs no random state.
 */
export function scheduleTarget(npcId, npc, minutes, ctx) {
  const hour = minutes / 60;
  const f = ctx.festival;
  if (f && hour >= f.from && hour < f.to) {
    const o = npcId.length % 3;
    return { x: f.place.x + o - 1, y: f.place.y };
  }
  const slot = npc.schedule.find((s) => hour >= s.from && hour < s.to) || npc.schedule[npc.schedule.length - 1];
  if (slot.shore) return ctx.shore;
  if (slot.at) return slot.at;
  const w = slot.wander;
  const block = Math.floor(minutes / 20);
  for (let i = 0; i < 8; i++) {
    const x = w.x + Math.round((hash(ctx.seed, block, strHash(npcId), 500 + i) * 2 - 1) * w.r);
    const y = w.y + Math.round((hash(ctx.seed, block, strHash(npcId), 600 + i) * 2 - 1) * w.r);
    if (!ctx.isBlocked(x, y)) return { x, y };
  }
  return { x: w.x, y: w.y };
}

/** A land tile next to water, for fishermen. Scans outward from the origin. */
export function findShore(isBlocked, isWater, maxR = 60) {
  for (let r = 6; r <= maxR; r++) {
    for (let x = -r; x <= r; x++) {
      for (const y of [-r, r]) { const t = shoreAt(isBlocked, isWater, x, y); if (t) return t; }
    }
    for (let y = -r + 1; y < r; y++) {
      for (const x of [-r, r]) { const t = shoreAt(isBlocked, isWater, x, y); if (t) return t; }
    }
  }
  return { x: 6, y: 6 };
}

function shoreAt(isBlocked, isWater, x, y) {
  if (isBlocked(x, y)) return null;
  const near = isWater(x + 1, y) || isWater(x - 1, y) || isWater(x, y + 1) || isWater(x, y - 1);
  return near ? { x, y } : null;
}
