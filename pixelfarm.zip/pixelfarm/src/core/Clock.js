import { hash } from '../world/WorldGen.js';

export const SEASONS = ['spring', 'summer', 'fall', 'winter'];
export const DAYS_PER_SEASON = 28;
export const DAY_START = 6 * 60;      // 6:00 AM
export const DAY_END = 26 * 60;       // 2:00 AM next morning: you pass out
export const GAME_MIN_PER_SEC = 1.5;  // a full day is 800 real seconds (~13 min)
const WEEKDAYS = ['Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat', 'Sun'];
const WEATHER_CHANCE = { spring: [0.22, 0], summer: [0.12, 0], fall: [0.24, 0], winter: [0, 0.25] }; // [rain, snow]

/** Same seed + day always gives the same weather. Day 1 is always sunny. */
export function weatherFor(seed, day, season) {
  if (day === 1) return 'sunny';
  const [rain, snow] = WEATHER_CHANCE[season];
  const h = hash(seed, day, 7, 301);
  return h < rain ? 'rain' : h < rain + snow ? 'snow' : 'sunny';
}

export class Clock {
  constructor(day = 1, minutes = DAY_START) {
    this.day = day;
    this.minutes = minutes;
  }

  get season() { return SEASONS[Math.floor((this.day - 1) / DAYS_PER_SEASON) % 4]; }
  get dayOfSeason() { return ((this.day - 1) % DAYS_PER_SEASON) + 1; }
  get year() { return Math.floor((this.day - 1) / (DAYS_PER_SEASON * 4)) + 1; }
  get weekday() { return WEEKDAYS[(this.day - 1) % 7]; }

  /** Advances time. Returns true when the day is over (2 AM). */
  tick(dtSeconds) {
    this.minutes += GAME_MIN_PER_SEC * dtSeconds;
    return this.minutes >= DAY_END;
  }

  nextDay() {
    this.day++;
    this.minutes = DAY_START;
  }

  timeString() {
    const m = Math.floor(this.minutes);
    const h = Math.floor(m / 60) % 24;
    const mm = m % 60;
    return ((h % 12) || 12) + ':' + (mm < 10 ? '0' : '') + mm + (h >= 12 ? ' PM' : ' AM');
  }

  dateString() {
    const s = this.season;
    return this.weekday + ' ' + s[0].toUpperCase() + s.slice(1) + ' ' + this.dayOfSeason + ', Year ' + this.year;
  }
}
