# Pixel Farm (Phaser 3 + Vite) - Phase 4

Offline-first top-down sandbox.
Phase 1 = project setup, input abstraction + joystick, movement, camera, streamed world, APK pipeline.
Phase 2 = inventory, hotbar, tools, drops, interaction system, chest.
Phase 4 = NPCs (schedules, dialogue trees, hearts, gifts, quests, festivals), shop + shipping bin economy, fishing.
Phase 3 = farming, day/night, seasons, weather, delta saves (autosave + export/import), title screen.

Art: Sprout Lands by Cup Nooble (credit required, non-commercial; keep this repo private or add the
credit + license note if you make it public. Do not redistribute the original pack itself).

## Run on a computer
    npm install
    npm run dev          # http://localhost:5173
    npm run test:gen     # pure-logic tests (world generator + input manager)
    npm run build        # output in dist/

## Build the APK on GitHub (no local Android tools)
1. Create a new GitHub repo and upload **everything in this folder** (keep `.github/workflows/build.yml`).
2. Open the repo > **Actions** tab > "Build" > **Run workflow** (it also runs on every push to main).
3. When it turns green (about 5-8 min the first time), open the run > **Artifacts** > `pixelfarm-debug-apk`.
4. Unzip, copy `app-debug.apk` to the phone, install (allow "unknown sources").
If a step fails, send me the red step's log text.

## What to test (Phase 4)
- Start gold 500 (HUD, under the clock). Three villagers walk around by schedule: Mara (shop, ~7 right / 4 up of spawn), Finn (fishes at the nearest shore), Pip (wanders).
  Face one and interact (E / right-click / USE). Talk once a day for friendship. "Give a gift" gives the SELECTED hotbar item (once per day).
- Mara > "Let's trade": Buy/Sell tabs, stock and prices change every day. Buy a Fishing Rod (150 g).
- Shipping bin (blue chest, 1 left / 5 up of spawn): put items in, they sell when you sleep at that day's market prices.
- Fishing: select the rod, face water (up to 3 tiles away), use. Wait for the bite, then HOLD USE (or Space / E / click) to keep the green bar over the fish.
  Shift/DODGE cancels while waiting. What bites depends on season, hour, weather and shallow vs deep water. Journal (menu, or L) > Aquarium lists your catches.
- Quests: ask each villager "anything I can help with?". Journal > Quests. Festivals: spring 13 and fall 16 (villagers gather at the plaza, shop 20% off).
- The legendary Moonscale only bites in DEEP water on RAIN nights (10 PM - 2 AM) and can be caught once.

## What to test (Phase 3)
- Title screen: New Game / Continue. A second tap on New Game is needed to erase an existing save.
- HUD (top-left): date, clock, weather. Time only runs while no menu is open. A day is ~13 real minutes; at 2:00 AM you pass out.
- Farming: Hoe (slot 3) on grass = tilled soil (clear trees/flowers first). Select Wheat Seeds (slot 5) and "use" on soil to plant.
  Watering Can (slot 4): use on tilled soil; use it on a lake to refill (number on the slot = water left).
- Sleep: interact with the green bed (3 left, 2 up from spawn) > Yes. Crops grow overnight ONLY if watered that day (or it rained).
  Wheat takes 5 watered days, beet 4. Ripe crop: E / right-click / USE to harvest (silver/gold quality shows as a coloured square).
- Seasons: 28 days each. Wheat: spring/summer/fall. Beet: spring/fall. Out-of-season crops wither at dawn.
- Saving: autosave every 45 s, on sleeping, and when the app goes to the background. Menu > Save game / Export save / Import save / Save and quit.
  Close the app and reopen: Continue should restore position, items, farm, felled trees, chest contents.

## What to test (Phase 2)
- Hotbar starts with Axe, Pickaxe, Watering Can. Select with 1-9, mouse wheel, tapping a slot, or SWAP (touch).
- Face a tree and swing (Space / left click / USE): 3 hits fell it, wood + branches pop out and fly to you; a stump stays.
  Stumps and logs take the axe too. Rocks need the pickaxe. Wrong tool = a message on the left.
- Flowers and mushrooms: E / right click / USE picks them up.
- The chest 3 tiles right and 2 up from spawn: interact to open. Tap a stack, then tap where it goes (move / merge / swap).
  Sort tidies the backpack, Close (or I / Esc / BAG) closes it.
- Desktop: the yellow tile outline follows the mouse (within reach). Touch/keyboard: the tile in front of you.
- Menu > Debug overlay still shows fps/chunks. Felling trees and breaking rocks must not drop the frame rate.

## Phase 1 checks (still valid)
- Desktop: WASD/arrows move, Shift = dodge dash, Esc = menu. Menu > Debug overlay shows fps/tile/chunks.
- Phone: the joystick (left) and USE / DODGE / SWAP / MENU buttons appear; hold the stick and tap DODGE
  at the same time (multi-touch). Menu > Edit touch layout: drag buttons, Smaller/Bigger, Reset, Done.
- Walk far in one direction: new chunks stream in, old ones are recycled (watch the chunks count stay small).
- Lakes block you, tree trunks/rocks/stumps block you, flowers and mushrooms do not.

## Tweaking without code
- `src/data/npcs.json`: villagers: schedule, gift tastes, whole dialogue tree (nodes, choices, conditions, actions).
- `src/data/quests.json`, `shops.json`, `fish.json`, `events.json`: quests, shop stock, fish rules, festival calendar.
- `src/data/items.json`: items. For tools, `anim` is the first row (0, 4 or 8) of that tool's swing in actions.png.
  If a tool shows the wrong swing, just change the number (0, 4 or 8).
- `src/data/crops.json`: crops (seed, harvest item, growth days per stage, seasons, farm.png row).
- `src/data/objects.json`: what each world object needs (tool, hit points, drops, what it leaves behind).

## Structure
    src/core      services (event bus), settings, platform, state machine, Clock (time/season/weather), Storage + SaveManager
    src/input     InputManager + Keyboard/Mouse/Gamepad/Touch sources (gameplay only talks to InputManager)
    src/world     seeded generator (pure), chunk streaming + pooling, Farm (soil/crops), drops, interaction
    src/entities  Player (state machine: idle / walk / dodge)
    src/scenes    Boot, Preload, MainMenu, World, UI (runs parallel)
    src/ui        TouchControls (+ layout editor), SettingsPanel, Hotbar, InventoryPanel, ToastFeed, DialoguePanel, ShopPanel, JournalPanel, FishingGame
    src/data      decor.json (what spawns in the world - add content here without code)
    tools         build_atlas.py (re-slice Sprout Lands), patch-android.mjs (CI), test-worldgen.mjs
