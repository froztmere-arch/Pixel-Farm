"""
Rebuilds public/assets from your Sprout Lands pack.
Usage:  python3 tools/build_atlas.py "/path/to/Sprout Lands - Sprites - Basic pack"
Needs:  pip install pillow
(The processed assets are already included, so you only need this if you want to change the atlas.)
"""
import json
import shutil
import sys
from pathlib import Path
from PIL import Image

pack = Path(sys.argv[1])
# Optional 2nd argument: the "Pixel Items 16x16" pack folder (fish, coin, bread, rod icons). Skipped if absent.
items_pack = Path(sys.argv[2]) if len(sys.argv) > 2 else None
import colorsys
out = Path(__file__).resolve().parent.parent / "public" / "assets"
out.mkdir(parents=True, exist_ok=True)

shutil.copy(pack / "Tilesets" / "Grass.png", out / "grass.png")                  # 11x7 tiles of 16px
shutil.copy(pack / "Tilesets" / "Water.png", out / "water.png")                  # 4 frames of 16px
shutil.copy(pack / "Characters" / "Basic Charakter Spritesheet.png", out / "player.png")  # 4x4 cells of 48px
shutil.copy(pack / "Characters" / "Basic Charakter Actions.png", out / "actions.png")      # 2 cols x 12 rows of 48px

src = Image.open(pack / "Objects" / "Basic_Grass_Biom_things.png").convert("RGBA")
rects = {
    "tree_tall": (1, 0, 14, 29), "tree_round": (20, 1, 24, 31), "tree_fruit": (52, 1, 24, 31),
    "mushroom_red_pair": (82, 2, 13, 13), "mushroom_purple": (115, 3, 7, 8),
    "mushroom_purple_pair": (129, 3, 14, 12), "mushroom_red": (100, 4, 10, 11),
    "rock_small": (114, 18, 10, 8), "rock_big": (128, 18, 16, 12), "log": (80, 35, 16, 10),
    "stump_small": (52, 36, 8, 10), "stump": (67, 36, 10, 10),
    "flower_yellow": (114, 37, 11, 9), "flower_blue": (83, 50, 11, 12), "flower_pink": (114, 52, 11, 9),
    "bush_berry_pair": (0, 48, 32, 16), "bush_stump_large": (36, 64, 32, 16), "bush_stump_long": (2, 68, 30, 12),
}

# Chest (240x96 sheet of 16px cells): closed = cell (1,1), open = cell (7,1). Trimmed to their pixels.
chest_sheet = Image.open(pack / "Objects" / "Chest.png").convert("RGBA")
extra = {}
for name, (cx, cy) in {"chest_closed": (1, 1), "chest_open": (7, 1)}.items():
    cell = chest_sheet.crop((cx * 16, cy * 16, cx * 16 + 16, cy * 16 + 16))
    bb = cell.getbbox()
    extra[name] = cell.crop(bb)

def recolor(img, hue_shift, sat_mul=1.0, val_mul=1.0, keep_dark=False):
    out = img.copy()
    px = out.load()
    for yy in range(out.height):
        for xx in range(out.width):
            r, g, b, a = px[xx, yy]
            if not a:
                continue
            h, sv, v = colorsys.rgb_to_hsv(r / 255, g / 255, b / 255)
            h = (h + hue_shift) % 1.0
            r2, g2, b2 = colorsys.hsv_to_rgb(h, min(1, sv * sat_mul), min(1, v * val_mul))
            px[xx, yy] = (int(r2 * 255), int(g2 * 255), int(b2 * 255), a)
    return out

# PLACEHOLDER: shipping bin = blue recolour of the chest (the pack has no bin)
extra["bin_closed"] = recolor(extra["chest_closed"], 0.52, 0.9)
extra["bin_open"] = recolor(extra["chest_open"], 0.52, 0.9)

furn = Image.open(pack / "Objects" / "Basic_Furniture.png").convert("RGBA")
extra["bed_green"] = furn.crop((0, 24, 16, 50)).crop(furn.crop((0, 24, 16, 50)).getbbox())

sheet_w = 128
x = y = row_h = 0
placed = []
crops = {n: src.crop((rx, ry, rx + rw, ry + rh)) for n, (rx, ry, rw, rh) in rects.items()}
crops.update(extra)
for name, img in crops.items():
    rw, rh = img.size
    if x + rw + 2 > sheet_w:
        x, y, row_h = 0, y + row_h + 2, 0
    placed.append((name, 0, 0, rw, rh, x, y))
    x += rw + 2
    row_h = max(row_h, rh)
sheet_h = y + row_h + 2

atlas = Image.new("RGBA", (sheet_w, sheet_h), (0, 0, 0, 0))
frames = {}
for name, rx, ry, rw, rh, px, py in placed:
    atlas.paste(crops[name], (px, py))
    frames[name] = {
        "frame": {"x": px, "y": py, "w": rw, "h": rh}, "rotated": False, "trimmed": False,
        "spriteSourceSize": {"x": 0, "y": 0, "w": rw, "h": rh}, "sourceSize": {"w": rw, "h": rh},
    }
atlas.save(out / "objects.png")
json.dump({"frames": frames, "meta": {"image": "objects.png", "size": {"w": sheet_w, "h": sheet_h}, "scale": "1"}},
          open(out / "objects.json", "w"), indent=1)
print("done:", len(frames), "object frames")


# ---- Item icons atlas: every icon centred in a 16x16 cell, so the UI can scale them all the same ----
mats = Image.open(pack / "Objects" / "Basic_tools_and_meterials.png").convert("RGBA")  # 3x2 cells
icon_src = {
    "watering_can": mats.crop((0, 0, 16, 16)), "axe": mats.crop((16, 0, 32, 16)),
    "stone": mats.crop((0, 16, 16, 32)), "branch": mats.crop((16, 16, 32, 32)), "wood": mats.crop((32, 16, 48, 32)),
    "apple": src.crop((33, 33, 46, 47)),
}
for n in ("flower_yellow", "flower_blue", "flower_pink", "mushroom_red", "mushroom_purple"):
    icon_src[n] = crops[n]

# The 3rd tool icon in the pack is a HOE. The pack has no pickaxe, so the pickaxe is a bluish
# recolour of it (outline kept) - PLACEHOLDER until a real pickaxe icon exists.
hoe = mats.crop((32, 0, 48, 16))
pick = hoe.copy()
px_ = pick.load()
for yy in range(16):
    for xx in range(16):
        r, g, b, a = px_[xx, yy]
        if a and not (r > 225 and g > 225 and b > 200):
            px_[xx, yy] = (int(r * 0.7), int(g * 0.85), min(255, int(b * 1.2) + 10), a)
icon_src["hoe"] = hoe
icon_src["pickaxe"] = pick
plants_sheet = Image.open(pack / "Objects" / "Basic_Plants.png").convert("RGBA")   # 6x2 cells of 16px
icon_src["wheat_seeds"] = plants_sheet.crop((0, 0, 16, 16))
icon_src["beet_seeds"] = plants_sheet.crop((0, 16, 16, 32))
icon_src["wheat"] = plants_sheet.crop((80, 0, 96, 16))
icon_src["beet"] = plants_sheet.crop((80, 16, 96, 32))
if items_pack is not None:
    ip = Image.open(items_pack / "items.png").convert("RGBA")
    def tile(c, r): return ip.crop((c * 16, r * 16, c * 16 + 16, r * 16 + 16))
    fa, fb, fc = tile(4, 6), tile(5, 6), tile(6, 6)
    icon_src.update({
        "coin": tile(9, 14), "fishing_rod": tile(20, 1),
        "bread": tile(1, 8), "cheese": tile(11, 6), "honey": tile(10, 6), "egg": tile(7, 6), "cookie": tile(3, 9),
        "fish_minnow": fa, "fish_perch": fb, "fish_trout": fc,
        "fish_catfish": recolor(fa, 0.07, 0.9, 0.85), "fish_koi": recolor(fb, 0.55, 1.6, 1.1),
        "fish_glacier": recolor(fc, 0.48, 1.4, 1.1), "fish_moonscale": recolor(fb, 0.15, 2.2, 1.15),
    })
cols = 8
rows_n = (len(icon_src) + cols - 1) // cols
icons = Image.new("RGBA", (cols * 16, rows_n * 16), (0, 0, 0, 0))
icon_frames = {}
for i, (name, img) in enumerate(icon_src.items()):
    bb = img.getbbox()
    img = img.crop(bb)
    cx, cy = (i % cols) * 16, (i // cols) * 16
    icons.paste(img, (cx + (16 - img.width) // 2, cy + (16 - img.height) // 2))
    icon_frames[name] = {"frame": {"x": cx, "y": cy, "w": 16, "h": 16}, "rotated": False, "trimmed": False,
                         "spriteSourceSize": {"x": 0, "y": 0, "w": 16, "h": 16}, "sourceSize": {"w": 16, "h": 16}}
icons.save(out / "items.png")
json.dump({"frames": icon_frames, "meta": {"image": "items.png", "size": {"w": icons.width, "h": icons.height}, "scale": "1"}},
          open(out / "items.json", "w"), indent=1)
print("items:", len(icon_frames), "icons")


# ---- Farm tileset (6 cols x 5 rows of 16px) ----
# row 0: dry soil, wet soil | rows 1-2: crop stages on dry soil | rows 3-4: the same on wet soil
dirt = Image.open(pack / "Tilesets" / "Tilled_Dirt.png").convert("RGBA")
best = None
for ty in (5, 6):
    for tx in range(0, 5):
        t = dirt.crop((tx * 16, ty * 16, tx * 16 + 16, ty * 16 + 16))
        if min(t.getchannel("A").getdata()) == 0:
            continue
        n = len(set(t.getdata()))
        if best is None or n < best[0]:
            best = (n, t)
base = best[1].copy()
# furrows: darken two horizontal lines so it reads as tilled soil
dry = base.copy()
dp = dry.load()
for fy in (4, 10):
    for fx in range(1, 15):
        r, g, b, a = dp[fx, fy]
        dp[fx, fy] = (int(r * 0.82), int(g * 0.78), int(b * 0.72), a)
wet = dry.copy()
wp = wet.load()
for fy in range(16):
    for fx in range(16):
        r, g, b, a = wp[fx, fy]
        wp[fx, fy] = (int(r * 0.66), int(g * 0.62), int(b * 0.62), a)
farm = Image.new("RGBA", (96, 80), (0, 0, 0, 0))
farm.paste(dry, (0, 0))
farm.paste(wet, (16, 0))
for prow in range(2):
    for col in range(6):
        cell = plants_sheet.crop((col * 16, prow * 16, col * 16 + 16, prow * 16 + 16))
        for wet_flag, soil in ((0, dry), (1, wet)):
            tile = soil.copy()
            tile.alpha_composite(cell)
            farm.paste(tile, (col * 16, (1 + prow + wet_flag * 2) * 16))
farm.save(out / "farm.png")
print("farm tileset written")


# ---- NPC sheets: PLACEHOLDER recolours of the player sprite (hue/saturation shifts) ----
player = Image.open(out / "player.png").convert("RGBA")
for name, hue, sat, val in (("mara", 0.92, 1.4, 1.0), ("finn", 0.55, 1.3, 0.95), ("pip", 0.28, 1.5, 1.05)):
    recolor(player, hue, sat, val).save(out / f"npc_{name}.png")
print("npc placeholder sheets written")
