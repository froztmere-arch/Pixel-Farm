// Quick sanity tests for the pure logic (no Phaser, no browser):  npm run test:gen
import fs from 'node:fs';
import { WorldGen } from '../src/world/WorldGen.js';
import { InputManager } from '../src/input/InputManager.js';
import { TouchSource } from '../src/input/TouchSource.js';
import { CHUNK } from '../src/world/constants.js';
import { ItemDB } from '../src/core/ItemDB.js';
import { Inventory } from '../src/entities/Inventory.js';
import { GameState } from '../src/core/GameState.js';
import { Clock, weatherFor, DAYS_PER_SEASON, DAY_END } from '../src/core/Clock.js';
import { Farm } from '../src/world/Farm.js';
import { SaveManager, RECORDS } from '../src/core/SaveManager.js';
import { MemoryStorage } from '../src/core/Storage.js';
import { marketMultiplier, sellPrice, buyPrice, shopStock, festivalToday } from '../src/core/Economy.js';
import { heartsOf, giftReaction } from '../src/core/Friendship.js';
import { evalCond, pickGreeting, visibleChoices } from '../src/core/Dialogue.js';
import { eligibleFish, pickFish, FishingBar, fishQuality } from '../src/core/Fishing.js';
import { findPath } from '../src/world/Pathfinding.js';
import { scheduleTarget, findShore } from '../src/core/Schedule.js';
import { Social } from '../src/core/Social.js';

const decor = JSON.parse(fs.readFileSync(new URL('../src/data/decor.json', import.meta.url), 'utf8'));
let failed = 0;
const ok = (cond, msg) => { console.log((cond ? 'PASS ' : 'FAIL ') + msg); if (!cond) failed++; };

// --- world generation ---
const a = new WorldGen(12345, decor), b = new WorldGen(12345, decor), c = new WorldGen(999, decor);
const ca = a.generateChunk(3, -2), cb = b.generateChunk(3, -2);
ok(JSON.stringify([...ca.tiles]) === JSON.stringify([...cb.tiles]), 'same seed -> identical chunk');
ok(JSON.stringify([...ca.tiles]) !== JSON.stringify([...c.generateChunk(3, -2).tiles]), 'different seed -> different chunk');

let water = 0, total = 0, blockedMismatch = 0;
for (let cy = -4; cy <= 4; cy++) for (let cx = -4; cx <= 4; cx++) {
  const ch = a.generateChunk(cx, cy);
  for (let i = 0; i < CHUNK * CHUNK; i++) {
    total++; if (ch.tiles[i] === -1) water++;
    const x = cx * CHUNK + (i % CHUNK), y = cy * CHUNK + Math.floor(i / CHUNK);
    if ((ch.blocked[i] === 1) !== a.isBlockedAt(x, y)) blockedMismatch++;
  }
}
const frac = water / total;
ok(frac > 0.05 && frac < 0.45, 'water fraction sane: ' + (frac * 100).toFixed(1) + '%');
ok(blockedMismatch === 0, 'chunk blocked grid matches isBlockedAt everywhere (' + blockedMismatch + ' mismatches)');
ok(!a.isBlockedAt(0, 0) && !a.isBlockedAt(2, 2) && !a.isBlockedAt(-3, 1), 'spawn area is walkable');

// seeds: spawn must be dry for many seeds
let badSpawn = 0;
for (let s = 1; s <= 300; s++) if (new WorldGen(s * 7919, decor).isBlockedAt(0, 0)) badSpawn++;
ok(badSpawn === 0, 'spawn tile free for 300 seeds');

// frames used by the generator must exist in the atlas
const atlas = JSON.parse(fs.readFileSync(new URL('../public/assets/objects.json', import.meta.url), 'utf8'));
const used = new Set();
for (const k of ['trees', 'blockers', 'meadow', 'woodland']) decor[k].forEach((e) => used.add(e.frame));
ok([...used].every((f) => atlas.frames[f]), 'all decor frames exist in objects atlas');

// ASCII preview around spawn
let out = '';
for (let y = -20; y <= 20; y++) {
  for (let x = -50; x <= 50; x++) {
    if (a.isWater(x, y)) { out += '~'; continue; }
    const o = a.objectOnLand(x, y);
    out += x === 0 && y === 0 ? '@' : !o ? '.' : o.kind === 'tree' ? 'T' : o.kind === 'blocker' ? 'o' : '*';
  }
  out += '\n';
}
console.log(out);

// --- Phase 2: items, inventory, object definitions, world changes ---
const items = JSON.parse(fs.readFileSync(new URL('../src/data/items.json', import.meta.url), 'utf8'));
const defs = JSON.parse(fs.readFileSync(new URL('../src/data/objects.json', import.meta.url), 'utf8'));
const icons = JSON.parse(fs.readFileSync(new URL('../public/assets/items.json', import.meta.url), 'utf8'));
ItemDB.init(items);
ok(Object.values(items).every((i) => icons.frames[i.icon]), 'every item icon exists in items atlas');
ok(Object.keys(defs).every((f) => atlas.frames[f]), 'every objects.json frame exists in objects atlas');
ok(Object.values(defs).every((d) => (d.drops || []).every((x) => items[x.item]) && (!d.gather || items[d.gather]) && (!d.leaves || atlas.frames[d.leaves])),
  'drops, gather items and leaves frames all exist');
ok(Object.values(items).filter((i) => i.type === 'tool').every((i) => Number.isInteger(i.anim) && i.anim >= 0 && i.anim <= 8), 'tool swing rows are in range');

const iv = new Inventory(3);
const left = iv.add('wood', 250);
ok(left === 0 && iv.slots[0].count === 99 && iv.slots[1].count === 99 && iv.slots[2].count === 52, 'stacks split at 99');
ok(iv.add('stone', 5) === 5, 'full inventory returns everything as leftover');
ok(iv.remove('wood', 60) === 60 && iv.countOf('wood') === 190, 'remove takes from the back');
const invA = new Inventory(3), invB = new Inventory(3);
invA.add('apple', 5); invB.add('apple', 4); invB.add('stone', 1);
invA.move(0, invB, 0);
ok(invB.slots[0].count === 9 && invA.slots[0] === null, 'move merges same item across inventories');
invA.add('wood', 2); invA.move(0, invB, 1);
ok(invB.slots[1].id === 'wood' && invA.slots[0].id === 'stone', 'move swaps different items');
const s2 = new Inventory(6); s2.add('stone', 5); s2.add('apple', 2); s2.add('stone', 5); s2.sort(0);
ok(s2.countOf('stone') === 10 && s2.slots.filter(Boolean).length === 2, 'sort merges stacks');
const rt = Inventory.fromJSON(JSON.parse(JSON.stringify(s2.toJSON())));
ok(rt.countOf('apple') === 2 && rt.size === 6, 'inventory survives JSON round trip');
const gs = new GameState();
ok(gs.selectedItem().tool === 'axe' && gs.inventory.slots[3].id === 'watering_can' && gs.inventory.countOf('wheat_seeds') === 10, 'new game starts with tools and seeds');
gs.select(-1); ok(gs.selected === 8, 'hotbar selection wraps');

const w = new WorldGen(777, decor);
let tree = null;
for (let y = -80; y < 80 && !tree; y++) for (let x = -80; x < 80 && !tree; x++) {
  if (!w.isWater(x, y)) { const o = w.objectOnLand(x, y); if (o && o.kind === 'tree') tree = { x, y }; }
}
ok(!!tree && w.isBlockedAt(tree.x, tree.y), 'found a blocking tree');
w.setObject(tree.x, tree.y, null);
ok(!w.isBlockedAt(tree.x, tree.y), 'felled tree no longer blocks');
w.setObject(tree.x, tree.y, { frame: 'stump', blocks: true, kind: 'blocker' });
ok(w.isBlockedAt(tree.x, tree.y) && w.objectOnLand(tree.x, tree.y).frame === 'stump', 'stump replaces the tree');
const w2 = new WorldGen(777, decor); w2.importMods(JSON.parse(JSON.stringify(w.exportMods())));
ok(w2.objectOnLand(tree.x, tree.y).frame === 'stump', 'world changes survive export/import (delta save)');
const cc = w2.generateChunk(Math.floor(tree.x / CHUNK), Math.floor(tree.y / CHUNK));
ok(cc.objects.some((o) => o.frame === 'stump'), 'regenerated chunk contains the change');


// --- input manager ---
const mgr = new InputManager(null);
const touch = mgr.addSource(new TouchSource());
touch.press('tool'); touch.release('tool');           // tap shorter than a frame
mgr.update();
ok(mgr.justPressed('tool'), 'latched tap registers as justPressed');
mgr.update();
ok(!mgr.isDown('tool') && !mgr.justPressed('tool'), 'tap is released next frame');
touch.x = 3; touch.y = 4;
mgr.update();
ok(Math.abs(Math.hypot(mgr.getMove().x, mgr.getMove().y) - 1) < 1e-9, 'move vector clamped to length 1');
touch.press('dodge'); mgr.setBlocked(true); mgr.update();
ok(!mgr.isDown('dodge') && mgr.getMove().x === 0, 'blocked input hides actions and movement');
touch.clear(); touch.press('menu'); mgr.update();
ok(mgr.justPressed('menu'), 'menu still works while blocked');

// --- Phase 3: crops, clock, farm, quality, saves ---
const crops = JSON.parse(fs.readFileSync(new URL('../src/data/crops.json', import.meta.url), 'utf8'));
ok(Object.values(crops).every((c) => items[c.seed] && items[c.item] && items[c.seed].plants && c.stageDays.length === 3 && c.row <= 1),
  'crop definitions reference real items');
ok(Object.keys(items).every((k) => items[k].type !== 'seed' || crops[items[k].plants]), 'every seed points at a crop');

const clk = new Clock();
ok(clk.season === 'spring' && clk.dayOfSeason === 1 && clk.timeString() === '6:00 AM', 'clock starts spring 1, 6:00 AM');
clk.day = DAYS_PER_SEASON + 1; ok(clk.season === 'summer' && clk.dayOfSeason === 1, 'season rolls over after 28 days');
clk.day = DAYS_PER_SEASON * 4 + 1; ok(clk.season === 'spring' && clk.year === 2, 'year rolls over');
const clk2 = new Clock(); let over = false, secs = 0;
while (!over && secs < 5000) { over = clk2.tick(1); secs++; }
ok(over && secs > 600 && secs < 1000 && clk2.minutes >= DAY_END, 'a day lasts about 13 real minutes (' + secs + 's)');
clk2.minutes = 12 * 60 + 5; ok(clk2.timeString() === '12:05 PM', 'noon formats as 12:05 PM');
clk2.minutes = 25 * 60 + 30; ok(clk2.timeString() === '1:30 AM', 'after midnight formats as AM');
ok(weatherFor(5, 1, 'spring') === 'sunny', 'day 1 is sunny');
ok(weatherFor(5, 40, 'summer') === weatherFor(5, 40, 'summer'), 'weather is deterministic');
let rainy = 0; for (let d = 2; d < 400; d++) if (weatherFor(9, d, 'winter') === 'rain') rainy++;
ok(rainy === 0, 'no rain in winter');

const farm = new Farm(crops);
ok(farm.till(5, 5) && !farm.till(5, 5), 'till once only');
ok(farm.tileIndex(5, 5) === 0 && farm.tileIndex(9, 9) === -1, 'dry soil index 0, untilled -1');
farm.water(5, 5); ok(farm.tileIndex(5, 5) === 1, 'wet soil index 1');
ok(farm.plant(5, 5, 'wheat') && !farm.plant(5, 5, 'wheat'), 'plant once per tile');
ok(farm.tileIndex(5, 5) === (1 + 0 + 2) * 6 + 1, 'sprout on wet soil index');
farm.advanceDay('spring', false);                         // watered yesterday: grows
ok(farm.get(5, 5).c.d === 1 && farm.get(5, 5).w === 0, 'watered crop grows, soil dries');
farm.advanceDay('spring', false);                         // not watered: no growth
ok(farm.get(5, 5).c.d === 1, 'unwatered crop does not grow');
for (let i = 0; i < 6; i++) farm.advanceDay('summer', true);   // rain waters every day
ok(farm.isRipe(5, 5) && farm.harvest(5, 5) === 'wheat' && !farm.isRipe(5, 5), 'wheat ripens (5 growth days) and harvests once');
farm.plant(5, 5, 'beet'); farm.water(5, 5);
const res = farm.advanceDay('winter', false);
ok(res.withered === 1 && farm.get(5, 5).c === null, 'out-of-season crops wither');
const farm2 = Farm.fromJSON(JSON.parse(JSON.stringify(farm.toJSON())), crops);
ok(farm2.isTilled(5, 5) && farm2.tilesInChunk(0, 0).size === 1, 'farm survives JSON round trip with chunk index');

const qi = new Inventory(4);
qi.add('wheat', 3, 0); qi.add('wheat', 2, 2);
ok(qi.slots[0].count === 3 && qi.slots[1].q === 2, 'different qualities use different stacks');
ok(qi.add('wheat', 1, 0) === 0 && qi.slots[0].count === 4, 'same quality merges');
qi.move(1, qi, 0); ok(qi.slots[0].q === 2 && qi.slots[1].count === 4, 'move swaps different qualities');
const qj = Inventory.fromJSON(JSON.parse(JSON.stringify(qi.toJSON())));
ok(qj.slots[0].q === 2 && qj.slots[1].q === undefined, 'quality survives JSON round trip');
qi.sort(0); ok(qi.slots[0].q === 2, 'sort puts higher quality first');
const rm = new Inventory(2); rm.add('stone', 5); ok(rm.removeAt(0, 2) === 2 && rm.slots[0].count === 3, 'removeAt');

const mem = new MemoryStorage();
const sm = new SaveManager(mem);
const rec = { meta: { seed: 42, day: 3 }, inventory: [null], containers: [], mods: [], farm: [] };
const build = Object.fromEntries(RECORDS.map((k) => [k, () => rec[k]]));
ok(!(await sm.hasSave()), 'no save at first');
await sm.flush(build, true);
ok(await sm.hasSave() && mem.writes.length === RECORDS.length, 'full save writes every record');
mem.writes.length = 0;
sm.mark('farm', 'meta'); await sm.flush(build);
ok(mem.writes.join() === 'meta,farm' || mem.writes.slice().sort().join() === 'farm,meta', 'delta save writes only dirty records');
mem.writes.length = 0; await sm.flush(build);
ok(mem.writes.length === 0, 'nothing dirty = nothing written');
const loaded = await sm.load(); ok(loaded.meta.seed === 42 && loaded.farm.length === 0, 'load returns the records');
const text = await sm.exportText();
await sm.wipe(); ok(!(await sm.hasSave()), 'wipe removes the save');
ok(!(await sm.importText('not json')) && !(await sm.importText('{"game":"other"}')), 'invalid imports are rejected');
ok((await sm.importText(text)) && (await sm.load()).meta.seed === 42, 'export then import restores the save');
const full = GameState.fromSave({ meta: { selected: 2, water: 7, day: 9, minutes: 800 }, inventory: new GameState().inventory.toJSON(), containers: [['1,1', new Inventory(27).toJSON()]] });
ok(full.selected === 2 && full.water === 7 && full.clock.day === 9 && full.containers.has('1,1'), 'GameState restores from save records');

// --- Phase 4: economy, NPCs, dialogue, fishing ---
const rd = (f) => JSON.parse(fs.readFileSync(new URL(f, import.meta.url), 'utf8'));
const npcs = rd('../src/data/npcs.json'), quests = rd('../src/data/quests.json'), fishD = rd('../src/data/fish.json');
const shops = rd('../src/data/shops.json'), events = rd('../src/data/events.json');
const exists = (f) => fs.existsSync(new URL('../public/assets/' + f, import.meta.url));

ok(Object.values(fishD).every((f) => items[f.item] && items[f.item].type === 'fish' && items[f.item].sell && f.hours[0] < f.hours[1]), 'fish definitions reference real fish items');
ok(Object.values(shops).every((sh) => [...sh.always, ...sh.rotating.pool].every((id) => items[id] && items[id].buy)), 'every shop item exists and has a buy price');
ok(Object.values(npcs).every((n) => exists(n.sheet + '.png')), 'every NPC sprite sheet exists');
const refs = [];
for (const [id, n] of Object.entries(npcs)) {
  for (const g of n.greet) refs.push(g.node);
  for (const node of Object.values(n.nodes)) {
    if (node.next) refs.push(node.next);
    for (const c of node.choices || []) { if (c.next) refs.push(c.next); if (c.quest && !quests[c.quest]) refs.push('BAD QUEST ' + c.quest); }
  }
  refs.forEach((r) => { if (r !== undefined && !n.nodes[r]) failed++, console.log('FAIL dialogue of ' + id + ' references missing node ' + r); });
  refs.length = 0;
}
ok(Object.values(quests).every((q) => npcs[q.giver] && (q.type === 'catch' || q.items.every((i) => items[i]))), 'quests reference real NPCs and items');
ok(Object.values(npcs).every((n) => [...n.loves, ...n.likes, ...n.dislikes].every((i) => items[i])), 'gift tastes reference real items');

ok(marketMultiplier(1, 5, 'crop') === marketMultiplier(1, 5, 'crop') && marketMultiplier(1, 5, 'crop') >= 0.85 && marketMultiplier(1, 5, 'crop') <= 1.25, 'market multiplier is deterministic and bounded');
let diffDays = 0; for (let d = 1; d < 30; d++) if (marketMultiplier(3, d, 'fish') !== marketMultiplier(3, d + 1, 'fish')) diffDays++;
ok(diffDays > 20, 'prices fluctuate from day to day');
const fish1 = items.fish_koi;
ok(sellPrice(fish1, 2, 3, 4) > sellPrice(fish1, 0, 3, 4), 'gold quality sells for more');
const sp = items.wheat_seeds, cr = rd('../src/data/crops.json');
ok(buyPrice('wheat_seeds', sp, 3, 4, 'spring', cr, null) < buyPrice('wheat_seeds', sp, 3, 4, 'winter', cr, null), 'in-season seeds are cheaper');
ok(buyPrice('bread', items.bread, 3, 4, 'spring', cr, { discount: 0.2 }) < buyPrice('bread', items.bread, 3, 4, 'spring', cr, null), 'festival discount applies');
const sa = shopStock(shops.general, 3, 4), sb = shopStock(shops.general, 3, 5);
ok(sa.length === 3 + 4 && new Set(sa).size === sa.length && JSON.stringify(sa) !== JSON.stringify(sb), 'shop stock rotates daily without duplicates');
const fc = new Clock(13); ok(festivalToday(events, fc) && festivalToday(events, fc).id === 'bloom' && !festivalToday(events, new Clock(14)), 'festival calendar');

ok(heartsOf(0) === 0 && heartsOf(499) === 1 && heartsOf(5000) === 10, 'hearts from points');
ok(giftReaction(npcs.mara, 'cheese') === 'love' && giftReaction(npcs.mara, 'stone') === 'dislike' && giftReaction(npcs.mara, 'axe') === 'neutral', 'gift reactions');
const dctx = { hearts: 2, met: true, season: 'spring', quests: { q1: 'active' } };
ok(evalCond({ hearts: 2 }, dctx) && !evalCond({ hearts: 3 }, dctx) && evalCond({ quest: 'q1', state: 'active' }, dctx) && !evalCond({ quest: 'q1', state: 'none' }, dctx) && evalCond({ met: true }, dctx), 'dialogue conditions');
ok(pickGreeting(npcs.mara, { ...dctx, met: false }) === 'first' && pickGreeting(npcs.mara, { ...dctx, hearts: 4 }) === 'warm' && pickGreeting(npcs.mara, dctx) === 'hello', 'greeting depends on whether you met and on hearts');
ok(visibleChoices(npcs.mara.nodes.menu, { ...dctx, quests: { q_wheat: 'none' } }).some((c) => c.next === 'offer'), 'quest offer choice appears');

// fishing
const winter = { season: 'winter', hour: 12, weather: 'snow', location: 'deep' };
ok(eligibleFish(fishD, winter).map(([id]) => id).sort().join() === 'glacier,minnow', 'winter snow day: glacier fish and minnow only');
ok(eligibleFish(fishD, { season: 'spring', hour: 23, weather: 'rain', location: 'deep' }).some(([id]) => id === 'moonscale'), 'legendary can bite on rainy nights in deep water');
ok(!eligibleFish(fishD, { season: 'spring', hour: 23, weather: 'rain', location: 'shore' }).some(([id]) => id === 'moonscale'), 'legendary never bites from shallow water');
ok(!eligibleFish(fishD, { season: 'spring', hour: 23, weather: 'rain', location: 'deep' }, new Set(['moonscale'])).some(([id]) => id === 'moonscale'), 'legendary can only be caught once');
ok(pickFish(fishD, winter, () => 0) !== null && pickFish(fishD, { season: 'winter', hour: 3, weather: 'rain', location: 'deep' }) === null, 'pickFish returns null when nothing qualifies');
ok(fishQuality(true, () => 0.1) === 2 && fishQuality(false, () => 0.5) === 0, 'perfect reels give better quality');
function play(bar, skill) {
  for (let i = 0; i < 6000 && !bar.result; i++) {
    const center = bar.bar + bar.size / 2;
    bar.update(1 / 60, skill ? center + bar.vel * 0.18 < bar.fish : false);
  }
  return bar.result;
}
let seq = 0; const rng = () => ((seq = (seq * 9301 + 49297) % 233280) / 233280);
ok(play(new FishingBar(2, rng), true) === 'win', 'a skilled player wins against an easy fish');
ok(play(new FishingBar(2, rng), false) === 'lose', 'doing nothing loses');
let wins = 0; for (let i = 0; i < 200; i++) if (play(new FishingBar(9, Math.random), true) === 'win') wins++;
ok(wins >= 20 && wins <= 160, 'the legendary is hard but beatable (' + wins + '/200 with a simple bot)');

// pathfinding + schedules
const grid = (x, y) => y === 0 && x >= 1 && x <= 3;             // a wall in the way
const path = findPath(grid, 0, 0, 5, 0);
ok(path && path.length > 5 && path[path.length - 1].x === 5, 'BFS walks around obstacles');
ok(findPath((x, y) => x === 2, 0, 0, 5, 0, 200) === null, 'unreachable target returns null');
const wg = new WorldGen(2024, decor);
const shore = findShore((x, y) => wg.isBlockedAt(x, y), (x, y) => wg.isWater(x, y));
ok(!wg.isBlockedAt(shore.x, shore.y) && [[1, 0], [-1, 0], [0, 1], [0, -1]].some(([dx, dy]) => wg.isWater(shore.x + dx, shore.y + dy)), 'findShore returns land touching water');
const sctx = { seed: 7, shore, isBlocked: (x, y) => wg.isBlockedAt(x, y), festival: null };
ok(JSON.stringify(scheduleTarget('pip', npcs.pip, 700, sctx)) === JSON.stringify(scheduleTarget('pip', npcs.pip, 700, sctx)), 'wandering is deterministic');
ok(scheduleTarget('mara', npcs.mara, 10 * 60, sctx).x === 7 && scheduleTarget('mara', npcs.mara, 23 * 60, sctx).x === 8, 'Mara is at the shop by day and home at night');
ok(scheduleTarget('finn', npcs.finn, 7 * 60, sctx).x === shore.x, 'Finn fishes at the shore in the morning');
const fest = events[0];
ok(scheduleTarget('mara', npcs.mara, 11 * 60, { ...sctx, festival: fest }).y === fest.place.y, 'everyone gathers at the festival');
let walls = 0; for (const n of Object.values(npcs)) for (const sl of n.schedule) if (sl.at && wg.isBlockedAt(sl.at.x, sl.at.y)) walls++;
ok(walls === 0, 'scheduled spots are walkable in a sample world');
let blockedSpots = 0;
for (let sd = 1; sd <= 100; sd++) { const g = new WorldGen(sd * 31, decor); for (const n of Object.values(npcs)) for (const sl of n.schedule) if (sl.at && g.isBlockedAt(sl.at.x, sl.at.y)) blockedSpots++; }
ok(blockedSpots === 0, 'scheduled spots are walkable for 100 seeds');

// social: gifts and quests
const gst = new GameState();
const soc = new Social(gst, npcs, quests);
ok(soc.gift('mara').err, 'gifting with a tool selected is refused');
gst.inventory.add('cheese', 2); gst.select(6);
ok(gst.selectedStack().id === 'cheese', 'cheese is in the selected slot (slot 6)');
const g1 = soc.gift('mara');
ok(g1.reaction === 'love' && soc.points('mara') === 80 && gst.inventory.countOf('cheese') === 1, 'loved gift: +80 points, item consumed');
ok(soc.gift('mara').err, 'only one gift per day');
gst.clock.nextDay(); ok(soc.gift('mara').reaction === 'love', 'a new day allows another gift');
soc.talk('pip'); soc.talk('pip'); ok(soc.points('pip') === 20 && soc.rec('pip').met, 'talking gives points once per day and marks as met');
ok(soc.acceptQuest('q_wheat') && !soc.acceptQuest('q_wheat') && soc.questState('q_wheat') === 'active', 'quest can be accepted once');
ok(!soc.turnIn('q_wheat').ok, 'cannot turn in without the items');
gst.inventory.add('wheat', 3, 0); gst.inventory.add('wheat', 2, 1);
const goldBefore = gst.gold, ptsBefore = soc.points('mara');
const tr = soc.turnIn('q_wheat');
ok(tr.ok && gst.gold === goldBefore + 250 && soc.points('mara') === ptsBefore + 100 && gst.inventory.countOf('wheat') === 0 && soc.questState('q_wheat') === 'done', 'quest turn-in takes items and pays gold + friendship');
soc.acceptQuest('q_fish'); ok(soc.progress('q_fish').have === 0, 'catch quest starts at 0');
soc.recordCatch('minnow', 0); soc.recordCatch('minnow', 1); const isNew = soc.recordCatch('perch', 0);
ok(isNew && soc.progress('q_fish').have === 3 && soc.turnIn('q_fish').ok, 'catch quest counts catches since it was accepted');
ok(gst.stats.caught.minnow.n === 2 && gst.stats.caught.minnow.best === 1, 'aquarium records count and best quality');
const sv = { meta: { gold: 321, selected: 0, water: 5, day: 2, minutes: 400 }, inventory: gst.inventory.toJSON(), containers: [], progress: JSON.parse(JSON.stringify({ npc: gst.npc, quests: gst.quests, stats: gst.stats })) };
const back = GameState.fromSave(sv);
ok(back.gold === 321 && back.stats.caught.perch.n === 1 && back.quests.q_wheat.state === 'done' && back.npc.mara.pts === gst.npc.mara.pts, 'gold, friendship, quests and aquarium survive save/load');

console.log(failed ? '\n' + failed + ' FAILED' : '\nall passed');
process.exit(failed ? 1 : 0);
