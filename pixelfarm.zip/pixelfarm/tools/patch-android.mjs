// Runs in CI right after `npx cap add android`.
// 1) Locks the activity to landscape  2) Makes the app fullscreen/immersive  3) Keeps the screen on.
import fs from 'node:fs';
import path from 'node:path';

const appId = JSON.parse(fs.readFileSync('capacitor.config.json', 'utf8')).appId;
const androidDir = 'android/app/src/main';

// --- AndroidManifest: landscape lock -------------------------------------------------------
const manifestPath = path.join(androidDir, 'AndroidManifest.xml');
let manifest = fs.readFileSync(manifestPath, 'utf8');
if (!manifest.includes('android:screenOrientation')) {
  manifest = manifest.replace('<activity', '<activity\n            android:screenOrientation="sensorLandscape"');
}
fs.writeFileSync(manifestPath, manifest);

// --- MainActivity: immersive sticky fullscreen ---------------------------------------------
const javaDir = path.join(androidDir, 'java', ...appId.split('.'));
fs.mkdirSync(javaDir, { recursive: true });
const java = `package ${appId};

import android.os.Bundle;
import android.view.View;
import android.view.WindowManager;
import com.getcapacitor.BridgeActivity;

public class MainActivity extends BridgeActivity {
    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
        hideSystemBars();
    }

    @Override
    public void onWindowFocusChanged(boolean hasFocus) {
        super.onWindowFocusChanged(hasFocus);
        if (hasFocus) hideSystemBars();
    }

    private void hideSystemBars() {
        getWindow().getDecorView().setSystemUiVisibility(
            View.SYSTEM_UI_FLAG_LAYOUT_STABLE
            | View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION
            | View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN
            | View.SYSTEM_UI_FLAG_HIDE_NAVIGATION
            | View.SYSTEM_UI_FLAG_FULLSCREEN
            | View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY);
    }
}
`;
fs.writeFileSync(path.join(javaDir, 'MainActivity.java'), java);

console.log('Android project patched for', appId);
