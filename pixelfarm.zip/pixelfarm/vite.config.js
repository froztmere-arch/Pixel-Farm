import { defineConfig } from 'vite';

// base './' = relative URLs, required for Capacitor (https://localhost) and Electron (file://).
export default defineConfig({
  base: './',
  build: {
    outDir: 'dist',
    // Vite's own bundles go to dist/bundle so they never collide with public/assets (the game art).
    assetsDir: 'bundle',
    target: 'es2019',
    assetsInlineLimit: 0,
    chunkSizeWarningLimit: 2000,
    rollupOptions: {
      output: { manualChunks: { phaser: ['phaser'] } },
    },
  },
  server: { port: 5173 },
});
